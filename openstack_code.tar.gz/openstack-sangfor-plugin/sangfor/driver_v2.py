import sangforlbaasdriver
from sangforlbaasdriver.v2.ad.driver_v2 import SangforDriverV2
from oslo_log import log as logging
from neutron_lbaas.drivers import driver_base
VERSION = "0.1.1"
LOG = logging.getLogger(__name__)

class UndefinedEnvironment(Exception):
    pass

class SangforLBaaSV2Driver(driver_base.LoadBalancerBaseDriver):

    def __init__(self, plugin, env='Project'):
        super(SangforLBaaSV2Driver, self).__init__(plugin)

        self.load_balancer = LoadBalancerManager(self)
        self.listener = ListenerManager(self)
        self.pool = PoolManager(self)
        self.member = MemberManager(self)
        self.health_monitor = HealthMonitorManager(self)

        if not env:
            msg = "SangforLBaaSV2Driver cannot be intialized because the environment"\
                " is not defined. To set the environment, edit "\
                "neutron_lbaas.conf and append the environment name to the "\
                "service_provider class name."
            LOG.debug(msg)
            raise UndefinedEnvironment(msg)
        pass

        LOG.debug("SangforLBaaSV2Driver: initializing, version=%s, impl=%s, env=%s"
                  % (VERSION, sangforlbaasdriver.__version__, env))
        self.sangfor = SangforDriverV2(plugin, env)

class SangforLBaaSV2DriverTest(SangforLBaaSV2Driver):

    def __init__(self, plugin, env="Test"):
        super(SangforLBaaSV2DriverTest, self).__init__(plugin, env)

        LOG.debug("SangforLBaaSV2DriverTest: initializing, version=%s, sangfor=%s, \
                env=%s" % (VERSION, sangforlbaasdriver.__version__, env))

        pass
    pass

class SangforLBaaSV2DriverProject(SangforLBaaSV2Driver):

    def __init__(self, plugin, env='Project'):
        super(SangforLBaaSV2DriverProject, self).__init__(plugin, env)
        LOG.debug("SangforLBaaSV2DriverProject: initializing, version=%s, sangfor=%s, \
                env=%s" % (VERSION, sangforlbaasdriver.__version__, env))
        pass
    pass

class LoadBalancerManager(driver_base.BaseLoadBalancerManager):

    def create(self, context, lb):
        self.driver.sangfor.loadbalancer.create(context, lb)
        pass

    def update(self, context, old_lb, lb):
        self.driver.sangfor.loadbalancer.update(context, old_lb, lb)
        pass

    def delete(self, context, lb):
        self.driver.sangfor.loadbalancer.delete(context, lb)
        pass

    def refresh(self, context, lb):
        self.driver.sangfor.loadbalancer.refresh(context, lb)
        pass

    def stats(self, context, lb):
        return self.driver.sangfor.loadbalancer.stats(context, lb)

class ListenerManager(driver_base.BaseListenerManager):
    def create(self, context, listener):
        self.driver.sangfor.listener.create(context, listener)

    def update(self, context, old_listener, listener):
        self.driver.sangfor.listener.update(context, old_listener, listener)

    def delete(self, context, listener):
        self.driver.sangfor.listener.delete(context, listener)

class PoolManager(driver_base.BasePoolManager):

    def create(self, context, pool):
        self.driver.sangfor.pool.create(context, pool)

    def update(self, context, old_pool, pool):
        self.driver.sangfor.pool.update(context, old_pool, pool)

    def delete(self, context, pool):
        self.driver.sangfor.pool.delete(context, pool)


class MemberManager(driver_base.BaseMemberManager):

    def create(self, context, member):
        self.driver.sangfor.member.create(context, member)

    def update(self, context, old_member, member):
        self.driver.sangfor.member.update(context, old_member, member)

    def delete(self, context, member):
        self.driver.sangfor.member.delete(context, member)


class HealthMonitorManager(driver_base.BaseHealthMonitorManager):

    def create(self, context, health_monitor):
        self.driver.sangfor.healthmonitor.create(context, health_monitor)

    def update(self, context, old_health_monitor, health_monitor):
        self.driver.sangfor.healthmonitor.update(context, old_health_monitor,
                                   health_monitor)

    def delete(self, context, health_monitor):
        self.driver.sangfor.healthmonitor.delete(context, health_monitor)

"""
class L7PolicyManager(driver_base.BaseL7PolicyManager):

    def create(self, context, l7policy):
        self.driver.sangfor.l7policy.create(context, l7policy)

    def update(self, context, old_l7policy, l7policy):
        self.driver.sangfor.l7policy.update(context, old_l7policy, l7policy)

    def delete(self, context, l7policy):
        self.driver.sangfor.l7policy.delete(context, l7policy)

class L7RuleManager(driver_base.BaseL7RuleManager):

    def create(self, context, l7rule):
        self.driver.sangfor.l7rule.create(context, l7rule)

    def update(self, context, old_l7rule, l7rule):
        self.driver.sangfor.l7rule.update(context, old_l7rule, l7rule)

    def delete(self, context, l7rule):
        self.driver.sangfor.l7rule.delete(context, l7rule)
"""
