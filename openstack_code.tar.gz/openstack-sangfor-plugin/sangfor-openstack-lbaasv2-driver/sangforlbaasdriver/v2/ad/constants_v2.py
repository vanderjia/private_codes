# coding=utf-8

# SangforEnvironmentDriver provider name
SANGFORENVDRIVER_PROVIDER_NAME = 'sangforenv'

# RPC channel names
TOPIC_PROCESS_ON_HOST_V2 = 'sangfor-lbaasv2-process-on-controller'
TOPIC_LOADBALANCER_AGENT_V2 = 'sangfor-lbaasv2-process-on-agent'

BASE_RPC_API_VERSION = '1.0'
RPC_API_NAMESPACE = None

# service builder constants
VIF_TYPE = 'sangfor'
NET_CACHE_SECONDS = 1800

# SUPPORTED PROVIDERNET TUNNEL NETWORK TYPES
TUNNEL_TYPES = ['vxlan']
