# coding=utf-8

from neutron.common import exceptions as q_exc


class SangforLBaaSv2DriverException(q_exc.NeutronException):

    message = "SangforLBaaSv2DriverException"


class SangforMismatchedTenants(SangforLBaaSv2DriverException):
    """The loadbalancer tenant is not the same as the network tenant."""

    message = "Tenant Id of network and loadbalancer mismatched"
