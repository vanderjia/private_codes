# Service resync interval
RESYNC_INTERVAL = 300

# Topic for tunnel notifications between the plugin and agent
TUNNEL = 'tunnel'

# Values for network_type
TYPE_FLAT = 'flat'
TYPE_VLAN = 'vlan'
#TYPE_GRE = 'gre'
TYPE_LOCAL = 'local'
TYPE_VXLAN = 'vxlan'
VXLAN_UDP_PORT = 4789
VTEP_SELFIP_NAME = 'vtep'

AGENT_BINARY_NAME = 'sangfor-oslbaasv1-agent'

DEFAULT_PARTITION = 'Common'
DEFAULT_ROUTE_DOMAIN_ID = 0

# RPC channel names
TOPIC_PROCESS_ON_HOST_V1 = 'sangfor-lbaasv1-process-on-controller'
TOPIC_LOADBALANCER_AGENT_V1 = 'sangfor-lbaasv1-process-on-agent'

RPC_API_VERSION = '1.0'
# RPC_API_NAMESPACE = ""

FDB_POPULATE_STATIC_ARP = True
# for test only
MIN_EXTRA_MB = 0
# MIN_EXTRA_MB = 500

MIN_TMOS_MAJOR_VERSION = 11
MIN_TMOS_MINOR_VERSION = 0

DEVICE_DEFAULT_DOMAIN = ".local"
DEVICE_HEALTH_SCORE_CPU_WEIGHT = 1
DEVICE_HEALTH_SCORE_MEM_WEIGHT = 1
DEVICE_HEALTH_SCORE_CPS_WEIGHT = 1
DEVICE_HEALTH_SCORE_CPS_PERIOD = 5
DEVICE_HEALTH_SCORE_CPS_MAX = 100
