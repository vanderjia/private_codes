# coding=utf-8

import sys

import eventlet
eventlet.monkey_patch()

from neutron.agent.common import config
from neutron.agent.linux import interface
from neutron.common import config as common_config
from neutron.common import rpc as n_rpc
from neutron.common import topics
from neutron.openstack.common import service
from oslo_config import cfg
import sangfor_openstack_agent_v1.lbaasv1.drivers.ad.agent_manager as manager
import sangfor_openstack_agent_v1.lbaasv1.drivers.ad.constants_v1 as sangforconstants




OPTS = [
    cfg.IntOpt(
        'periodic_interval',
        default=20,
        help='Seconds between periodic task runs'
    )
]

class SangforAgentService(n_rpc.Service):

    def start(self):
        super(SangforAgentService, self).start()
        self.tg.add_timer(cfg.CONF.periodic_interval,
                self.manager.run_periodic_tasks, None, None)
        pass


def main():
    cfg.CONF.register_opts(OPTS)
    cfg.CONF.register_opts(manager.OPTS)
    cfg.CONF.register_opts(interface.OPTS)

    config.register_agent_state_opts_helper(cfg.CONF)
    config.register_root_helper(cfg.CONF)

    common_config.init(sys.argv[1:])
    config.setup_logging()

    mgr = manager.LbaasAgentManager(cfg.CONF)

    print(mgr.agent_host)
    svc = SangforAgentService(
        host=mgr.agent_host,
        topic=sangforconstants.TOPIC_LOADBALANCER_AGENT_V1,
        manager=mgr
    )
    service.launch(svc).wait()

if __name__ == '__main__':
    main()
