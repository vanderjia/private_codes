import datetime
import hashlib
import logging as std_logging
import urllib2
import uuid

import sys
from eventlet import greenthread
from time import time
import commands

from neutron.common import constants as q_const
from neutron.common.exceptions import InvalidConfigurationOption
from neutron.common.exceptions import NeutronException
from neutron.plugins.common import constants as plugin_const
from neutron_lbaas.services.loadbalancer import constants as lb_const

from oslo_config import cfg
from oslo_log import helpers as log_helpers
from oslo_log import log as logging
from oslo_utils import importutils
from sangfor_openstack_agent.lbaasv2.drivers.ad.vadCache import MADcache as MAD 
from sangfor_openstack_agent.lbaasv2.drivers.ad.vadCache import VADcache as VAD 

from sangfor_openstack_agent.lbaasv2.drivers.ad.lbaas_driver import LBaaSBaseDriver 
from sangfor_openstack_agent.lbaasv2.drivers.ad import constants_v2 as sangforconst


_DEFAULT_POOL = 'openstack-default-pool'
_MONITOR_RETRIES = 255
_MONITOR_MAX_DELAY = 255
_MONTTOR_MAX_TIMEOUT = 255
_MONITOR_TYPE_MAP = {
    'TCP':'MONITOR_CONNECT_TCP',
    'PING':'MONITOR_ICMPV4',
    'HTTP':'MONITOR_CONNECT_HTTP',
    'HTTPS':'MONITOR_CONNECT_HTTPS'
}

LOG = logging.getLogger(__name__)
__VERSION__ = '0.1.1'

OPTS = [
    cfg.StrOpt(
        'server_host',
        default='200.200.144.196',
        help='connect to AD server_address'
    ),
    cfg.IntOpt(
        'server_port',
        default=443,
        help='connect to AD server_port',
    ),
    cfg.IntOpt(
        'vxlan_local_port',
        default=0,
        help='vxlan local port',
    ),

    cfg.IntOpt(
        'vxlan_remote_port',
        default=4789,
        help='vxlan remote port',
    ),
    cfg.StrOpt(
        'server_admin',
        default='admin',
        help='username to login'
    ),
    cfg.StrOpt(
        'server_password',
        default='root1234',
        help='password to login'
    ),

    cfg.ListOpt(
        'advertised_tunnel_types', default=['vlan'],
        help='tunnel types which are advertised to other VTEPs'
    ),
    cfg.ListOpt(
        'vad_manager_info_mapping', default=['eth1:200.200.144.113:22'],
        help='vad manager info'
    ),
    cfg.ListOpt(
        'external_physical_mappings', default=['default:eth1:True'],
        help='Mapping between Neutron physical_network to interfaces'
    ),

    cfg.ListOpt(
        'local_interface_ip', default=['eth1:200.200.1.2:24'],
        help='Mapping between Neutron physical_network to interfaces'
    ),
]

class ADDriver(LBaaSBaseDriver):

    def __init__(self, conf, registerOpts=True):

        super(ADDriver, self).__init__(conf)
        self.conf = conf

        if registerOpts:
            self.conf.register_opts(OPTS)
        self.plugin_rpc = None
        self.agent_configurations = {}
        self.agent_configurations["tunnel_types"] = self.conf.advertised_tunnel_types
        self.agent_configurations['common_networks']={}
        self.username = self.conf.server_admin
        self.password = self.conf.server_password
        self.mad = MAD(self.username, self.password, self.conf.server_host, self.conf.server_port)
        self.loadbalancer = {}
        self.interface_mapping={}
        self.local_interface_ip = {}
        self.tagging_mapping={}
        self.vad_manager_info={}
        if self.conf.environment_prefix:
            self.agent_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, self.conf.environment_prefix + '.' + self.conf.server_host))
        else:
            self.agent_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, self.conf.server_host))

        for maps in self.conf.external_physical_mappings:
            intmap = maps.split(':')
            net_key = str(intmap[0]).strip()
            self.interface_mapping[net_key] = str(intmap[1]).strip()
            self.tagging_mapping[net_key] = str(intmap[2]).strip()
            LOG.debug('physical_network %s = interface %s, tagged %s'
                      % (net_key, intmap[1], intmap[2]))
        for maps in self.conf.vad_manager_info_mapping:
            intmap = maps.split(':')
            net_key = str(intmap[0]).strip()
            self.vad_manager_info[net_key] = {
                    'manager_ip': intmap[1],
                    'manager_mask':intmap[2], 
                    'password': 'root1234'
                    }
            pass

        for maps in self.conf.local_interface_ip:
            intmap = maps.split(':')
            net_key = str(intmap[0].strip())
            self.local_interface_ip[net_key]=[intmap[1].strip(), int(intmap[2].strip())]
            pass
        vadList = self.mad.getVADList()
        try:
            for vad in vadList:
                if vad.started():
                    vad.resetConfig()
        except Exception as e:
            LOG.error("resetConfig failed")
            return
        """
        self.reset = True
        """
        self.reset = False

    def _getnetwork_from_service(self, service, network_id):
        if 'networks' in service:
            return service['networks'][network_id]

    def _get_subnets_to_from_service(self, service, subnet_id):
        if 'subnets' in service:
            return service['subnets'][subnet_id]
    def set_tunnel_rpc(self, tunnel_rpc):
       self._tunnel_rpc = tunnel_rpc

    def set_l2pop_rpc(self, l2_pop_rpc):
       self._l2pop_rpc = l2_pop_rpc

    def _get_subnets_to_assure(self, service):
        networks = dict()
        loadbalancer = service['loadbalancer']
        lb_status = loadbalancer['provisioning_status']

        if lb_status != plugin_const.PENDING_DELETE:
            if 'network_id' in loadbalancer:
                network = self._getnetwork_from_service(service, loadbalancer['network_id'])
                subnet = self._get_subnets_to_from_service(service, loadbalancer['vip_subnet_id'])
                networks[network['id']] = {'network': network,
                        'subnet': subnet,
                        'is_for_member': False}
                pass
            pass
        return networks.values()
            
    def set_plugin_rpc(self, plugin_rpc):
       self.plugin_rpc = plugin_rpc

    def _assure_network(self, network,service):
        if not network:
            LOG.error(' assure_network: '
                      'Attempted to assure a network with no id..skipping.')
            return

        if network['provider:network_type'] == 'vlan':
            return self._assure_network_vlan(network, service)
        elif network['provider:network_type'] == 'vxlan':
            return self._assure_network_vxlan(network, service)
        else:
            error_message = 'Unsupported network type %s.' \
                            % network['provider:network_type'] + \
                            ' Cannot setup network.'
            LOG.error(error_message)
            raise Exception()
        return ['flat','']
        pass

    def _get_tunnel_name(self, network):
        tunnel_type = network['provider:network_type']
        tunnel_id = network['provider:segmentation_id']
        return 'tunnel-' + str(tunnel_type) + '-' + str(tunnel_id)

    def _get_vxlan_vteps(self, service):
        vxlan=[]
        if 'loadbalancer' in service and 'vxlan_vteps' in service['loadbalancer']:
            vxlan = service['loadbalancer']['vxlan_vteps']
        return vxlan

    def _assure_network_vxlan(self, network, service):
        
        tunnel_name = self._get_tunnel_name(network)

        self.mad.createVxlan(tunnel_name, network['provider:segmentation_id'],
                self._get_vxlan_vteps(service), self.conf.vxlan_remote_port)
        local_ip = self._get_vxlan_local_ip(network)
        fdb_entry = { network['id']: { 'ports':{local_ip:[q_const.FLOODING_ENTRY]},
            'network_type':network['provider:network_type'],
            'segmentation_id':network['provider:segmentation_id']}}
        self._l2pop_rpc.add_fdb_entries(self._context, fdb_entry)
        return ['vxlan', tunnel_name]

    def _get_interface(self, network):

        interface = self.interface_mapping['default']
        net_key = network['provider:physical_network']

        if net_key in self.interface_mapping:
            interface = self.interface_mapping[net_key]
        else:
            interface = self.interface_mapping['default']

        return interface

    def _get_vxlan_local_ip(self, network):
        return self.local_interface_ip[self._get_interface(network)][0]

    def _assure_network_vlan(self, network, service):

        interface = self.interface_mapping['default']
        tagged = self.tagging_mapping['default']

        net_key = network['provider:physical_network']
        if net_key in self.interface_mapping:
            interface = self.interface_mapping[net_key]
            tagged = self.tagging_mapping[net_key]
        else:
            interface = self.interface_mapping['default']
            tagged = self.tagging_mapping['default']

        if tagged:
            vlanid = network['provider:segmentation_id']
        else:
            vlanid = 0
        vlan_name = 'vlan-'+str(interface)+'-'+str(vlanid)
        if len(vlan_name) > 15:
            vlan_name = 'vlan-tr' + str(vlanid) 

        try:
            self.mad.createVlan(vlan_name, vlanid, interface)
        except APIException as ex:
            LOG.error(u"Create Vlan error %s " % str(ex))
            pass
        return ['vlan', 'vlan_name']

    def set_context(self, context):
        self._context = context
        pass
        
    def post_init(self):
        pass


    def _get_loadbalancer_name(self, service):
        return "openstack-" + service['loadbalancer']['network_id']

    def create_loadbalancer(self, loadbalancer, service):
        try:
            self._common_service_handler(service)
        except Exception as e:
            service['loadbalancer']['provisioning_status'] = plugin_const.ERROR
            self._update_service_status(service)
            LOG.error(u'create vad error %s' % str(e))

    def update_loadbalancer(self, old_lb ,lb, service):
        try:
            self._common_service_handler(service)
        except Exception as e:
            service['loadbalancer']['provisioning_status'] = plugin_const.ERROR
            self._update_service_status(service)
            LOG.error("getVAD error")
            return
        pass

    def delete_loadbalancer(self, lb, service):
        name = self._get_loadbalancer_name(service)
        try:
            self._common_service_handler(service)
        except Exception as e:
            service['loadbalancer']['provisioning_status'] = plugin_const.ERROR
            self._update_service_status(service)
            LOG.error("delete vad %s failed", str(e))
        pass

    @log_helpers.log_method_call
    def _createDefaultPool(self, vad, name):
        create = True
        pooList = vad.getPoolList()
        for pool in pooList:
            if pool.name == name:
                create = False
                break
        if create:
            vad.createPool(name)

    def create_listener(self, listener, service):

        try:
            self._common_service_handler(service)
        except Exception as e:
            LOG.error("createServ error(%s)" % e)
            service['loadbalancer']['provisioning_status'] = plugin_const.ERROR
            self._update_service_status(service)
            return
        pass

    def update_listener(self, old_listener, listener, service):
        lbname = self._get_loadbalancer_name(service)
        vsname = 'openstack-'+listener['id']
        try:
            self._common_service_handler(service)
        except Exception as e:
            LOG.error("update listener error")
            service['loadbalancer']['provisioning_status'] = plugin_const.ERROR
            self._update_service_status(service)
            return

        self._update_service_status(service)
        pass

    def delete_listener(self, listener, service):
        lbname = self._get_loadbalancer_name(service)
        vsname = 'openstack-'+listener['id']
        try:
            self._common_service_handler(service)
        except Exception as e:
            LOG.error("delet listener failed")
            service['loadbalancer']['provisioning_status'] = plugin_const.ERROR
            self._update_service_status(service)
            return

    def create_pool(self, pool, service):
        try:
            self._common_service_handler(service)
        except Exception as e:
            LOG.error("create_pool failed")
            service['loadbalancer']['provisioning_status'] = plugin_const.ERROR
            self._update_service_status(service)
            return


    def _getSchedMethod(self, pool):
        method = 'NODE_LB_HASH'
        schedMap = {
                'ROUND_ROBIN': 'NODE_LB_RR',
                'LEAST_CONNECTIONS':'NODE_LB_LEAST_CONN'
                }
        if pool['lb_algorithm'] in schedMap:
            method = schedMap[pool['lb_algorithm']]
        return method

    def update_pool(self, oldpool, pool, service):
        try:
            self._common_service_handler(service)
        except Exception as e :
            service['loadbalancer']['provisioning_status'] = plugin_const.ERROR
            self._update_service_status(service)
            LOG.error("update pool %s" % e)
        pass

    def delete_pool(self, pool, service):
        lbname = self._get_loadbalancer_name(service)
        try:
            self._common_service_handler(service)
        except Exception as e:
            service['loadbalancer']['provisioning_status'] = plugin_const.ERROR
            self._update_service_status(service)
            LOG.error("error  %s" % e)
        pass

    def create_member(self, member, service):
        try:
            self._common_service_handler(service)
        except Exception as e:
            service['loadbalancer']['provisioning_status'] = plugin_const.ERROR
            self._update_service_status(service)
            LOG.error("createMember err %s" % e)
        pass
    def update_member(self, old_member, member, service):
        try:
            self._common_service_handler(service)
        except Exception as e:
            service['loadbalancer']['provisioning_status'] = plugin_const.ERROR
            self._update_service_status(service)
            LOG.error("error %s" % e) 
        pass

    def delete_member(self, member, service):
        try:
            self._common_service_handler(service)
        except Exception as e:
            service['loadbalancer']['provisioning_status'] = plugin_const.ERROR
            self._update_service_status(service)
            LOG.error("deleteMember eror %s" % e)
        pass    

    @log_helpers.log_method_call
    def create_health_monitor(self, health_monitor, service):
        try:
            self._common_service_handler(service)
        except Exception as e:
            LOG.error("error %s " % e)
            service['loadbalancer']['provisioning_status'] = plugin_const.ERROR
            self._update_service_status(service)
        pass

    @log_helpers.log_method_call
    def update_health_monitor(self, old, health_monitor, service):
        try:
            self._common_service_handler(service)
        except Exception as e:
            LOG.error("error %s " % e)
            service['loadbalancer']['provisioning_status'] = plugin_const.ERROR
            self._update_service_status(service)
        pass

    @log_helpers.log_method_call
    def delete_health_monitor(self, health_monitor, service):
        try:
            self._common_service_handler(service)
        except Exception as e:
            LOG.error("deleteMonitor error %s ", e)
            service['loadbalancer']['provisioning_status'] = plugin_const.ERROR
            self._update_service_status(service)
        pass

    def tunnel_update(self, **kargs):
        pass

    def add_fdb_entries(self, fdb):
        pass

    def remove_fdb_entries(self, fdb):
        pass

    def update_fdb_entries(self, fdb):
        pass

    def _update_service_status(self, service):
        """Update status of objects in OpenStack """
        if not self.plugin_rpc:
            LOG.error("Cannot update status in Neutron without "
                      "RPC handler.")
            return

        if 'members' in service:
            # Call update_members_status
            self._update_member_status(service['members'])
        if 'healthmonitors' in service:
            # Call update_monitor_status
            self._update_health_monitor_status(
                service['healthmonitors']
            )
        if 'pools' in service:
            # Call update_pool_status
            self._update_pool_status(
                service['pools']
            )
        if 'listeners' in service:
            # Call update_listener_status
            self._update_listener_status(
                service['listeners']
            )
        self._update_loadbalancer_status(
            service['loadbalancer']
        )

    def _update_member_status(self, members):
        """Update member status in OpenStack """
        for member in members:
            if 'provisioning_status' in member:
                provisioning_status = member['provisioning_status']
                if (provisioning_status == plugin_const.PENDING_CREATE or
                        provisioning_status == plugin_const.PENDING_UPDATE):
                        self.plugin_rpc.update_member_status(
                            member['id'],
                            plugin_const.ACTIVE,
                            lb_const.ONLINE
                        )
                elif provisioning_status == plugin_const.PENDING_DELETE:
                    self.plugin_rpc.member_destroyed(
                        member['id'])

    def _update_health_monitor_status(self, health_monitors):
        """Update pool monitor status in OpenStack """
        for health_monitor in health_monitors:
            if 'provisioning_status' in health_monitor:
                provisioning_status = health_monitor['provisioning_status']
                if (provisioning_status == plugin_const.PENDING_CREATE or
                        provisioning_status == plugin_const.PENDING_UPDATE):
                        self.plugin_rpc.update_health_monitor_status(
                            health_monitor['id'],
                            plugin_const.ACTIVE,
                            lb_const.ONLINE
                        )
                elif provisioning_status == plugin_const.PENDING_DELETE:
                    self.plugin_rpc.health_monitor_destroyed(
                        health_monitor['id'])

    @log_helpers.log_method_call
    def _update_pool_status(self, pools):
        """Update pool status in OpenStack """
        for pool in pools:
            if 'provisioning_status' in pool:
                provisioning_status = pool['provisioning_status']
                if (provisioning_status == plugin_const.PENDING_CREATE or
                        provisioning_status == plugin_const.PENDING_UPDATE):
                        self.plugin_rpc.update_pool_status(
                            pool['id'],
                            plugin_const.ACTIVE,
                            lb_const.ONLINE
                        )
                elif provisioning_status == plugin_const.PENDING_DELETE:
                    self.plugin_rpc.pool_destroyed(
                        pool['id'])

    @log_helpers.log_method_call
    def _update_listener_status(self, listeners):
        """Update listener status in OpenStack """
        for listener in listeners:
            if 'provisioning_status' in listener:
                provisioning_status = listener['provisioning_status']
                if (provisioning_status == plugin_const.PENDING_CREATE or
                        provisioning_status == plugin_const.PENDING_UPDATE):
                        self.plugin_rpc.update_listener_status(
                            listener['id'],
                            plugin_const.ACTIVE,
                            lb_const.ONLINE
                        )
                elif provisioning_status == plugin_const.PENDING_DELETE:
                    self.plugin_rpc.listener_destroyed(
                        listener['id'])

    @log_helpers.log_method_call
    def _update_loadbalancer_status(self, loadbalancer):
        """Update loadbalancer status in OpenStack """
        provisioning_status = loadbalancer['provisioning_status']

        if (provisioning_status == plugin_const.PENDING_CREATE or
                provisioning_status == plugin_const.PENDING_UPDATE):
            self.plugin_rpc.update_loadbalancer_status(
                loadbalancer['id'],
                plugin_const.ACTIVE,
                lb_const.ONLINE)
        elif provisioning_status == plugin_const.PENDING_DELETE:
            self.plugin_rpc.loadbalancer_destroyed(
                loadbalancer['id'])
        elif provisioning_status == plugin_const.ERROR:
            self.plugin_rpc.update_loadbalancer_status(
                loadbalancer['id'])
        else:
            LOG.error('Loadbalancer provisioning status is invalid')

    def sync(self, service):
        if self.plugin_rpc:
            service = self.plugin_rpc.get_service_by_loadbalancer_id(service['loadbalancer']['id'])
        if service['loadbalancer']:
            self._common_service_handler(service)
        else:
            LOG.debug("Attempted sync of deleted pool")

    @log_helpers.log_method_call
    def _common_service_handler(self, service):
        self._assure_loadbalancer(service)
        self._assure_listeners(service)
        self._assure_pools(service)
        self._assure_members(service)
        self._assure_monitors(service)
        self._update_service_status(service)

    @log_helpers.log_method_call
    def _assure_loadbalancer(self, service):
        if 'loadbalancer' not in service:
            return
        name = self._get_loadbalancer_name(service)
        lb = service['loadbalancer']
        if lb['provisioning_status'] == plugin_const.PENDING_DELETE:
            LOG.debug("delete lb(%s) ok" % name)
            return
        elif lb['provisioning_status'] == plugin_const.PENDING_CREATE:
            try:
                subnetsinfo = self._get_subnets_to_assure(service)
                bridge = self._assure_network(subnetsinfo[0]['network'], service)
                interface = self._get_interface(subnetsinfo[0]['network'])
                if bridge[0] == 'flat':
                    bridge[1] = interface

                if interface in self.vad_manager_info:
                    vadinfo = self.vad_manager_info[interface]
                else:
                    vadinfo = self.vad_manager_info['eth1']
                try:
                    self.mad.getVAD(name)
                    return
                except:
                    pass
                kargs = dict(mirror=self.mad.getmirrorList()[0], ip=vadinfo['manager_ip'],
                        mask=vadinfo['manager_mask'], password=vadinfo['password'],
                        interface=[interface], bri_type=bridge[0], bri_name=bridge[1], vad=None)
                vad = self.mad.createVAD(name, kargs)
                vad.start()
                greenthread.sleep(5)
            except Exception as e:
                raise(e)
        else:
            pass

    @log_helpers.log_method_call
    def _createListener(self, loadbalancer, listener, vad, service):
        self._createDefaultPool(vad, _DEFAULT_POOL)
        name = 'openstack-'+listener['id'] 
        srvtype = 'SRV_HTTP' if listener['protocol'] == 'HTTP' else 'SRV_TCP'
        enable = 'true' if listener['admin_state_up'] and loadbalancer['admin_state_up'] else 'false'
        mode = 'VS_MODE_L7' if listener['protocol'] == 'HTTP' else 'VS_MODE_L4'
        subnetsinfo = self._get_subnets_to_assure(service)
        vad.createIPGroup(name, [service['loadbalancer']['vip_address']],\
                {'mask':int(subnetsinfo[0]['subnet']['cidr'].split('/')[1]), \
                'gatewayIP':subnetsinfo[0]['subnet']['gateway_ip'], 'wan':self._get_loadbalancer_name(service)})
        vad.createServ(name, srvtype, [int(listener['protocol_port'])])
        vad.createVS(name, {'poolName': _DEFAULT_POOL, "ipgName":name, 'serviceName':name, 'enable':enable, 'mode':mode})


    @log_helpers.log_method_call
    def _updateListener(self, loadbalancer, listener, vad, service):
        vsname = 'openstack-'+listener['id']
        enable =  'true ' if listener['admin_state_up'] and service['loadbalancer']['admin_state_up'] else 'false'
        vad.updateVS(vsname, {'enable': enable})

    @log_helpers.log_method_call
    def _deleteListener(self, loadbalancer, listener, vad, service):
        vsname = 'openstack-' + listener['id']
        vad.deleteVS(vsname)
        vad.deleteServ(vsname)
        args = dict(wan=self._get_loadbalancer_name(service), ip=[loadbalancer['vip_address']])
        vad.deleteIPGroup(vsname, args)
        lbname = self._get_loadbalancer_name(service)

    @log_helpers.log_method_call
    def _assure_listeners(self, service):
        if 'listeners' not in service:
            return
        
        listeners = service['listeners']
        loadbalancer = service['loadbalancer']
        try:
            vad = self.mad.getVAD(self._get_loadbalancer_name(service))
            LOG.debug("getVAD failed maybe deleted")
        except:
            return
        for listener in listeners:
            if listener['provisioning_status'] == plugin_const.PENDING_CREATE:
                self._createListener(loadbalancer, listener, vad, service)
            elif listener['provisioning_status'] == plugin_const.PENDING_UPDATE:
                self._updateListener(loadbalancer, listener, vad, service)
            elif listener['provisioning_status'] == plugin_const.PENDING_DELETE:
                self._deleteListener(loadbalancer, listener, vad, service)
            else:
                LOG.debug("Unkown listener state")

    @log_helpers.log_method_call
    def _createPool(self, loadbalancer, pool, vad, service):
        lbname = self._get_loadbalancer_name(service)
        poolname = 'openstack-' + pool['id']
        method = self._getSchedMethod(pool)
        relat = False if pool['protocol'] != 'HTTP' and \
                pool['sessionpersistence'] and \
                'type' in pool['sessionpersistence '] and \
                pool['sessionpersistence']['type'] != 'SOURCE_IP' else True
        if pool['sessionpersistence'] and relat:
            if pool[sessionpersistence]['type'] == 'SOURCE_IP':
                vad.createPersist('openstack-' + pool['id'], {'type': 'PERSIST_SOURCE_IP'})
            elif pool['sessionpersistence']['type'] == 'HTTP_COOKIE':
                vad.createPersist('openstack-'+pool['id'], \
                        {'type':'PERSIST_COOKIE', \
                        'cookie_type':'PERSIST_COOKIE_INSERT',\
                        'cookie_name':'openstack_cookie_insert'})
            else:
                vad.createPersist('openstack-'+pool['id'], \
                        {'type':'PERSIST_COOKIE', \
                        'cookie_type':'PERSIST_COOKIE_STUDY',\
                        'cookie_name':pool['sessionpersistence']['cookie_name']})
            vad.createPool(poolname, {'lbMethod':method, 'persist1Name':'openstack-'+pool['id']})
        else:
            vad.createPool(poolname, {'lbMethod':method})
        for listener in pool['listeners']:
            vad.updateVS('openstack-' + listener['id'], {'poolName' : poolname})

    @log_helpers.log_method_call
    def _updatePool(self, loadbalancer, pool, vad, service):
        lbname = self._get_loadbalancer_name(service)
        for listener in pool['listeners']:
            enable = 'true' if pool['admin_state_up'] and loadbalancer['admin_state_up'] else 'false'
            vad.updateVS('openstack-' + listener['id'], {'enable':enable})
        method = self._getSchedMethod(pool)
        relat = False if pool['protocol'] != 'HTTP' and \
                pool['sessionpersistence'] and \
                'type' in pool['sessionpersistence '] and \
                pool['sessionpersistence']['type'] != 'SOURCE_IP' else True
        if pool['sessionpersistence'] and relat:
            try:
                vad.deletePersist('openstack-' + pool['id'])
            except Exception as e:
                LOG.debug(e)
            if pool['sessionpersistence']['type'] == 'SOURCE_IP':
                vad.createPersist('openstack-' + pool['id'], {'type': 'PERSIST_SOURCE_IP'})
                vad.updatePool('openstack-' + pool['id'], {'persist1Name': 'openstack-' + pool['id'], 'lbMethod':method})
            elif pool['sessionpersistence']['type'] == 'HTTP_COOKIE':
                vad.createPersist('openstack-'+pool['id'], \
                        {'type':'PERSIST_COOKIE', \
                        'cookie_type':'PERSIST_COOKIE_INSERT',\
                        'cookie_name':'openstack_cookie_insert'})
                vad.updatePool('openstack-'+pool['id'], {'persist1Name':'openstack-'+pool['id'], 'lbMethod':method}) 
            else:
                vad.createPersist('openstack-'+pool['id'], \
                        {'type':'PERSIST_COOKIE', \
                        'cookie_type':'PERSIST_COOKIE_STUDY',\
                        'cookie_name':pool['sessionpersistence']['cookie_name']})
                vad.updatePool('openstack-'+pool['id'], \
                        {'persist1Name':'openstack-'+pool['id'], 'lbMethod':method}) 
        else:
            vad.updatePool('openstack-' + pool['id'], {'lbMethod':method})

    @log_helpers.log_method_call
    def _deletePool(self, loadbalancer, pool, vad, service):
        lbname = self._get_loadbalancer_name(service)
        for member in pool['members']:
            vad.deleteMember('openstack-'+pool['id'], member['address'], port=member['protocol_port'])
        if pool['sessionpersistence'] :
            vad.updatePool('openstack-'+pool['id'],  {'persist1Name':'None'})
            vad.deletePersist('openstack-'+pool['id'])
        if pool['healthmonitor_id']:
            vad.deleteMonitor('openstack-'+pool['healthmonitor_id'])
        for listener in pool['listeners']:
            vad.updateVS('openstack-' + listener['id'], {'enable':'false', 'poolName':_DEFAULT_POOL})
        vad.deletePool('openstack-' + pool['id'])

    @log_helpers.log_method_call
    def _assure_pools(self, service):
        if 'pools' not in service:
            return
        
        pools = service['pools']
        loadbalancer = service['loadbalancer']
        try:
            vad = self.mad.getVAD(self._get_loadbalancer_name(service))
        except:
            LOG.debug("getVAD failed maybe deleted")
            return
        for pool in pools:
            if pool['provisioning_status'] == plugin_const.PENDING_CREATE:
                self._createPool(loadbalancer, pool, vad, service)
            elif pool['provisioning_status'] == plugin_const.PENDING_UPDATE:
                self._updatePool(loadbalancer, pool, vad, service)
            elif pool['provisioning_status'] == plugin_const.PENDING_DELETE:
                self._deletePool(loadbalancer, pool, vad, service)
            else:
                LOG.debug("Unkown pool state")

    @log_helpers.log_method_call
    def _createMember(self, loadbalancer, member, vad, service):
        lbname = self._get_loadbalancer_name(service)
        vad.createMember('openstack-' + member['pool_id'], member['id'], member['address'], member['protocol_port'], {'ratio':member['weight']})
        pass

    @log_helpers.log_method_call
    def _updateMember(self, loadbalancer, member, vad, service):
        vad.updateMember('openstack-' + member['pool_id'], member['id'], member['address'], member['protocol_port'])
        pass

    @log_helpers.log_method_call
    def _deleteMember(self, loadbalancer, member, vad, service):
        vad.deleteMember('openstack-' + member['pool_id'], member['id'], member['address'], member['protocol_port'])
        pass

    @log_helpers.log_method_call
    def _createMonitor(self, loadbalancer, monitor, vad, service):
        name = 'openstack-'+monitor['id']
        mtype= "MONITOR_ICMPV4" if monitor['type'] not in _MONITOR_TYPE_MAP else _MONITOR_TYPE_MAP[monitor['type']]
        tryout = monitor['max_retries'] if int(monitor['max_retries'] ) < _MONITOR_RETRIES else _MONITOR_RETRIES
        timeout = monitor['timeout'] if int(monitor['timeout']) < _MONTTOR_MAX_TIMEOUT else _MONTTOR_MAX_TIMEOUT
        interval = monitor['delay'] if int(monitor['delay']) < _MONITOR_MAX_DELAY else _MONITOR_MAX_DELAY
        args={
                'interval':interval,
                'timeout':timeout,
                'tryout':tryout
            }
        if mtype == "MONITOR_CONNECT_TCP":
            vad.createMonitor(name, mtype, args)
        elif mtype == 'MONITOR_ICMPV4':
            vad.createMonitor(name,mtype, args)
        elif mtype == 'MONITOR_CONNECT_HTTP':
            args['resp_code']=monitor['expected_codes']
            args['url_msg']=monitor['url_path']
            vad.createMonitor(name, mtype, args)
        elif mtype == 'MONITOR_CONNECT_HTTPS': 
            LOG.error("Can`t support HTTPS montior")
            return
        for monitor in service['healthmonitors']:
            vad.addPoolMonitor('openstack-' + monitor['pool_id'], name)
        pass
    @log_helpers.log_method_call
    def _updateMonitor(self, loadbalancer, monitor, vad, service):
        name = 'openstack-'+health_monitor['id']
        interval = monitor['delay'] if int(monitor['delay']) < _MONITOR_MAX_DELAY else _MONITOR_MAX_DELAY
        tryout = monitor['max_retries'] if int(monitor['max_retries'] ) < _MONITOR_RETRIES else _MONITOR_RETRIES
        timeout = monitor['timeout'] if int(monitor['timeout']) < _MONTTOR_MAX_TIMEOUT else _MONTTOR_MAX_TIMEOUT
        mtype= "PING" if monitor['type'] not in _MONITOR_TYPE_MAP else _MONITOR_TYPE_MAP[monitor['type']]
        args={
                'type':mtype,
                'interval':interval,
                'timeout':timeout,
                'tryout':tryout
            }
        if mtype == "MONITOR_CONNECT_TCP":
            vad.updateMonitor(name, args)
        elif mtype == 'MONITOR_ICMPV4':
            vad.updateMonitor(name, args)
        elif mtype == 'MONITOR_CONNECT_HTTP':
            args['resp_code']=monitor['expected_codes']
            args['url_msg']=monitor['url_path']
            vad.updateMonitor(name, args)
        elif mtype == 'MONITOR_CONNECT_HTTPS': 
            args['resp_code']=monitor['expected_codes']
            args['url_msg']=monitor['url_path']
            vad.updateMonitor(name, args)  
        pass
    def _deleteMonitor(self, loadbalancer, monitor, vad, service):
        for monitor in service['healthmonitors']:
            vad.delPoolMonitor('openastack-' + monitor['pool_id'], 'openstack-' + monitor['id'])
        vad.deleteMonitor('openstack-'+health_monitor['id'])
        pass

    @log_helpers.log_method_call
    def _assure_members(self, service):
        if not (('pools' in service) and ('members' in service)):
            return
        members = service['members']
        loadbalancer = service['loadbalancer']
        try:
            vad = self.mad.getVAD(self._get_loadbalancer_name(service))
            LOG.debug("getVAD failed maybe deleted")
        except:
            return

        for member in members:
            if member['provisioning_status'] == plugin_const.PENDING_CREATE:
                self._createMember(loadbalancer, member, vad, service)
            elif member['provisioning_status'] == plugin_const.PENDING_UPDATE:
                self._updateMember(loadbalancer, member, vad, service)
            elif member['provisioning_status'] == plugin_const.PENDING_DELETE:
                self._deleteMember(loadbalancer, member, vad, service)
            else:
                LOG.debug("Unkown member state")

    @log_helpers.log_method_call
    def _assure_monitors(self, service):
        if not (('pools' in service) and ('healthmonitors' in service)):
            return
        monitors = service['healthmonitors']
        loadbalancer = service['loadbalancer']
        try:
            vad = self.mad.getVAD(self._get_loadbalancer_name(service))
            LOG.debug("getVAD failed maybe deleted")
        except:
            return

        for monitor in monitors:
            if monitor['provisioning_status'] == plugin_const.PENDING_CREATE:
                self._createMonitor(loadbalancer, monitor, vad, service)
            elif monitor['provisioning_status'] == plugin_const.PENDING_UPDATE:
                self._updateMonitor(loadbalancer, montior, vad, service)
            elif montior['provisioning_status'] == plugin_const.PENDING_DELETE:
                self._deleteMonitor(loadbalancer, monitor, vad, service)
            else:
                LOG.error("unknow montior stat")
    def remove_orphans(loadbalancer):
        pass
    def _resetProvisioningStatus(self, service):
        if service['loadbalancer']['provisioning_status'] == plugin_const.ERROR:
            service['loadbalancer']['provisioning_status'] == plugin_const.PENDING_CREATE

        if 'members' in service:
            for member in service['members']:
                if member['provisioning_status'] == plugin_const.ACTIVE or \
                        member['provisioning_status'] == plugin_const.PENDING_UPDATE or \
                        member['provisioning_status'] == plugin_const.ERROR:
                    member['provisioning_status'] = plugin_const.PENDING_CREATE
        if 'healthmonitors' in service:
            for monitor in service['healthmonitors']:
                if monitor['provisioning_status'] == plugin_const.ACTIVE or \
                        monitor['provisioning_status'] == plugin_const.PENDING_UPDATE or \
                        monitor['provisioning_status'] == plugin_const.ERROR:
                    monitor['provisioning_status'] = plugin_const.PENDING_CREATE
        if 'pools' in service:
            for pool in service['pools']:
                if pool['provisioning_status'] == plugin_const.ACTIVE or \
                        pool['provisioning_status'] == plugin_const.PENDING_UPDATE or \
                        pool['provisioning_status'] == plugin_const.ERROR:
                    pool['provisioning_status'] = plugin_const.PENDING_CREATE
        if 'listeners' in service:
            for listener in service['listeners']:
                if listener['provisioning_status'] == plugin_const.ACTIVE or \
                        monitor['provisioning_status'] == plugin_const.PENDING_UPDATE or \
                        monitor['provisioning_status'] == plugin_const.ERROR:
                    listener['provisioning_status'] = plugin_const.PENDING_CREATE
    def exists(self, service):
        if self.reset == True:
            self.reset = False
            self._resetProvisioningStatus(service)
            return False
        lb = self._get_loadbalancer_name(service)
        try:
           self.mad.getVAD(lb)
           return True
        except:
            return False
