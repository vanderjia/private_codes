#coding:utf-8
'''
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad import MADAPI as MAD
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api import APIException as APIException
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api.ErrorInfo import ErrInfo
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api.VlanInfo import VlanInfo, VlanInfoList
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api.VxlanInfo import VxlanInfo, VxlanList
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api.VADInfo import VADInfo, VADInfoList
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api.ImageInfo import ImageInfo, ImageInfoList
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api.ServInfo import ServInfo, ServInfoList, PortInfo
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api.IPGroup import IPGroup, IPGroupList, IPInfo
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api.PersistInfo import PersistInfo, PersistList
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api.MonitorInfo import MonitorInfo, MonitorList
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api.NodeInfo import NodeInfo, NodeList
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api.PoolInfo import PoolInfo, PoolList
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api.VSInfo import VSInfo, VSList, VSStatus
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api.WanInfo import WanInfo, WanList
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api.AclInfo import AclInfo, AclList
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api.SnatSet import SnatSet, SnatSetList
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api.AddrElement import AddrElement
'''
from adV2 import MADAPI as MAD
from adV2.api import APIException as APIException
from adV2.api.ErrorInfo import ErrInfo
from adV2.api.NetnsInfo import NetnsInfo #, NetnsInfoList
from adV2.api.MacvlanInfo import MacvlanInfo #, MacvlanInfoList
from adV2.api.VlanInfo import VlanInfo, VlanInfoList
from adV2.api.VxlanInfo import VxlanInfo, VxlanList
from adV2.api.VADInfo import VADInfo, VADInfoList
from adV2.api.ImageInfo import ImageInfo, ImageInfoList
from adV2.api.ServInfo import ServInfo, ServInfoList, PortInfo
from adV2.api.IPGroup import IPGroup, IPGroupList, IPInfo
from adV2.api.PersistInfo import PersistInfo, PersistList
from adV2.api.MonitorInfo import MonitorInfo, MonitorList
from adV2.api.NodeInfo import NodeInfo, NodeList
from adV2.api.PoolInfo import PoolInfo, PoolList
from adV2.api.VSInfo import VSInfo, VSList, VSStatus
from adV2.api.WanInfo import WanInfo, WanList
from adV2.api.AclInfo import AclInfo, AclList
from adV2.api.SnatSet import SnatSet, SnatSetList
from adV2.api.AddrElement import AddrElement
from oslo_log import log as logging
from oslo_log import helpers as log_helpers

MADAPI=MAD.MADAPI
ADAPI=MAD.ADAPI

#会话保持默认超时时间 单位：秒
DEFAULT_TIMEOUT = 86400
#节点默认最大权值
DEFAULT_WEIGHT_MAX = 100
#连接限制最大值
DEFAULT_CONN_LIMIT = 2147483647

LOG = logging.getLogger(__name__)

class ADHOST(object):
    '''
    AD主机操作类
    '''

    def __init__(self, username, password, host, port):
        self.adapi = ADAPI(username, password, host, port)

    def __configExist(self, code):
        if code == 105:
            return False
        else:
            return True

    @log_helpers.log_method_call
    def createNetns(self, name, tenant):
        """创建netns"""
        netnsInfo = NetnsInfo()
        netnsInfo.name = name
        netnsInfo.tenant = tenant
        try:
            ret = self.adapi.createNetns(netnsInfo)
            if ret.isFailed():
                # 创建失败时，查看一下netns是否已经存在，存在则不抛异常
                netns = self.adapi.getNetnsInfo(name)
                if netns.isFailed() == False:
                    return
                raise Exception('createNetns failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def deleteNetns(self, name):
        '''
        删除netns配置
        '''
        try:
            ret = self.adapi.deleteNetns(name)
            if ret.isFailed():
                raise Exception('deleteNetns failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def updateNetns(self, oldname, name, tenant):
        '''
        更新netns配置信息
        '''
        netnsInfo = NetnsInfo()
        netnsInfo.name = name
        netnsInfo.tenant = tenant
        try:
            ret = self.adapi.updateNetns(oldname, netnsInfo)
            if ret.isFailed():
                raise Exception('updateNetns failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def getNetnsInfo(self, name):
        '''
        获取netns配置信息
        '''
        netns = {}
        try:
            netnsInfo = self.adapi.getNetnsInfo(name)
            netns['name'] = netnsInfo.name
            netns['netnsId'] = netnsInfo.netnsId
            netns['tenant'] = netnsInfo.tenant
            if netnsInfo.isFailed():
                raise Exception('getNetnsinfo failed[%d, %s]' % (netnsInfo.getErrCode(),
                                                              netnsInfo.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)
        return netns

    @log_helpers.log_method_call
    def getNetnsId(self, name):
        netns = self.getNetnsInfo(name)
        return netns['netnsId']

    @log_helpers.log_method_call
    def createMacvlan(self, name, mac, interface, netns_id):
        """创建macvlan"""
        macvlanInfo = MacvlanInfo()
        macvlanInfo.name = name
        macvlanInfo.mac = mac
        macvlanInfo.ifname = interface
        macvlanInfo.netnsId = netns_id
        try:
            ret = self.adapi.createMacvlan(macvlanInfo)
            if ret.isFailed():
                # 创建失败时，查看一下macvlan是否已经存在，存在则不抛异常
                macvlan = self.adapi.getMacvlanInfo(name)
                if macvlan.isFailed() == False:
                    return
                raise Exception('createMacvlan failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def deleteMacvlan(self, name):
        '''
        删除macvlan配置
        '''
        try:
            ret = self.adapi.deleteMacvlan(name)
            if ret.isFailed():
                raise Exception('deleteMacvlan failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def updateMacvlan(self, oldname, name, mac, interface, netns_id):
        '''
        更新macvlan配置信息
        '''
        macvlanInfo = MacvlanInfo()
        macvlanInfo.name = name
        macvlanInfo.mac = mac
        macvlanInfo.ifname = interface
        macvlanInfo.netnsId = netns_id
        try:
            ret = self.adapi.updateMacvlan(oldname, macvlanInfo)
            if ret.isFailed():
                raise Exception('updateMacvlan failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def getMacvlanInfo(self, name):
        '''
        获取macvlan配置信息
        '''
        macvlan = {}
        try:
            macvlanInfo = self.adapi.getMacvlanInfo(name)
            macvlan['name'] = macvlanInfo.name
            macvlan['mac'] = macvlanInfo.mac
            macvlan['ifname'] = macvlanInfo.ifname
            macvlan['netnsId'] = macvlanInfo.netnsId
            macvlan['device'] = macvlanInfo.device
            if macvlanInfo.isFailed():
                raise Exception('getMacvlaninfo failed[%d, %s]' % (macvlanInfo.getErrCode(),
                                                              macvlanInfo.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)
        return macvlan

    @log_helpers.log_method_call
    def getMacvlanDevice(self, name):
        macvlan = self.getMacvlanInfo(name)
        return macvlan['device']

    @log_helpers.log_method_call
    def createVlan(self, name, id, interface='eth1'):
        """创建vlan"""
        vlanInfo = VlanInfo()
        vlanInfo.name = name
        vlanInfo.ifname = interface
        vlanInfo.vlanId = id
        try:
            ret = self.adapi.createVlan(vlanInfo)
            if ret.isFailed():
                # 创建失败时，查看一下vlan是否已经存在，存在则不抛异常
                vlan = self.adapi.getVlanInfo(name)
                if vlan.isFailed() == False:
                    return
                raise Exception('createVlan failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def deleteVlan(self, name):
        '''
        删除vlan配置
        '''
        try:
            ret = self.adapi.deleteVlan(name)
            if ret.isFailed():
                raise Exception('deleteVlan failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def updateVlan(self, oldname, name, id, interface='eth1'):
        '''
        更新vlan配置信息
        '''
        vlanInfo = VlanInfo()
        vlanInfo.name = name
        vlanInfo.ifname = interface
        vlanInfo.vlanId = id
        try:
            ret = self.adapi.updateVlan(oldname, vlanInfo)
            if ret.isFailed():
                raise Exception('updateVlan failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def getVlanInfo(self, name):
        '''
        获取vlan配置信息
        '''
        vlan = {}
        try:
            vlanInfo = self.adapi.getVlanInfo(name)
            vlan['name'] = vlanInfo.name
            vlan['vlanId'] = vlanInfo.vlanId
            vlan['ifname'] = vlanInfo.ifname
            vlan['device'] = vlanInfo.device
            if vlanInfo.isFailed():
                raise Exception('getVlaninfo failed[%d, %s]' % (vlanInfo.getErrCode(),
                                                              vlanInfo.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)
        return vlan

    @log_helpers.log_method_call
    def getVlanDevice(self, name):
        vlan = self.getVlanInfo(name)
        return vlan['device']

    @log_helpers.log_method_call
    def __buildVxlanInfo(self, name, id, remoteaddr, remoteport):
        vxlan = VxlanInfo()
        vxlan.name = name
        vxlan.vxlanId = id
        vxlan.remoteAddr = remoteaddr
        vxlan.remotePort = int(remoteport)
        vxlan.localAddr = ''  # openstack自动选择地址
        vxlan.localPort = 0
        vxlan.isGroup = 0     # openstack只使用单播
        return vxlan

    @log_helpers.log_method_call
    def createVxlan(self, name, id, remoteaddr=[], remoteport=4789):
        '''
        创建vxlan配置
        '''
        try:
            vxlan = self.__buildVxlanInfo(name, id, remoteaddr, remoteport)
            ret = self.adapi.createVxlan(vxlan)
            if ret.isFailed():
                # 创建失败时，查看一下vxlan是否已经存在，存在则不抛异常
                vxlanInfo = self.adapi.getVxlan(name)
                if vxlanInfo.isFailed() == False:
                    return
                raise Exception('createVxlan failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def deleteVxlan(self, name):
        '''
        删除vxlan配置
        '''
        try:
            ret = self.adapi.deleteVxlan(name)
            if ret.isFailed():
                raise Exception('deleteVxlan failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def updateVxlan(self, oldname, name, id, remoteaddr=[], remoteport=4789):
        '''
        更新vxlan配置
        '''
        try:
            vxlan = self.__buildVxlanInfo(name, id, remoteaddr, remoteport)
            ret = self.adapi.updateVxlan(oldname, vxlan)
            if ret.isFailed():
                raise Exception('updateVxlan failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def getVxlaninfo(self, name):
        '''
        获取vxlan配置信息
        '''
        vxlan = {}
        try:
            vxlanInfo = self.adapi.getVxlan(name)
            vxlan['name'] = vxlanInfo.name
            vxlan['vxlanId'] = vxlanInfo.vxlanId
            vxlan['device'] = vxlanInfo.device
            vxlan['remoteAddr'] = vxlanInfo.remoteAddr
            vxlan['remotePort'] = vxlanInfo.remotePort
            vxlan['localPort'] = vxlanInfo.localPort
            if vxlanInfo.isFailed():
                raise Exception('getVxlaninfo failed[%d, %s]' % (vxlanInfo.getErrCode(),
                                                        vxlanInfo.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)
        return vxlan

    def __buildServInfo(self, name, type="SRV_HTTP", port=[]):
        srv = ServInfo()
        srv.name = name
        # openstack TERMINATED_HTTPS/HTTPS/TCP 负载均认为TCP 负载
        # 原因openstack无法配置https卸载
        srv.type = type if type == 'SRV_HTTP' else 'SRV_TCP'
        for new_prot in port:
            portInfo = PortInfo()
            portInfo.fromPort = int(new_prot)
            srv.portInfo.append(portInfo)
        return srv


    @log_helpers.log_method_call
    def createServ(self, name, Stype="SRV_HTTP", port=[]):
        '''
        创建服务配置
        @name: 名字
        @type: 负载均衡的类型
        @port: 端口号数组
        @return:
        '''
        try:
            srv = self.__buildServInfo(name, Stype, port)
            ret = self.adapi.createServInfo(srv)
            if ret.isFailed():
                raise Exception('createServ failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def updateServ(self, name, type="SRV_HTTP", port=[]):
        '''
        添加端口号
        @param name:
        @param type:
        @param port 端口列表, 注意：一次只能添加一个
        @return:
        '''
        try:
            srv = self.__buildServInfo(name, type, port)
            srv.type = None       # 更新不需要类型
            ret = self.adapi.addServPort(srv)
            if ret.isFailed():
                raise Exception('updateServ failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def deleteServ(self, name):
        '''
        删除服务配置
        '''
        try:
            ret = self.adapi.delServInfo(name)
            if ret.isFailed() and self.__configExist(ret.getErrCode()):
                raise Exception('deleteServ failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    def __buildGroupInfo(self, name, ipg=[]):
        ipgroup = IPGroup()
        ipgroup.name = name
        ipInfo = IPInfo()
        ipInfo.ipAddr = ipg
        ipgroup.ipgInfo.append(ipInfo)
        return ipgroup

    @log_helpers.log_method_call
    def createIPGroup(self, name, ip=[], args={}):
        '''
        构建AD ip组+ ip 配置块
        @param name:
        @param ip:  ip组数组
        @return:
        '''
        if 'wan' not in args:
            LOG.error("no wan name")
            raise Exception()
        try:
            # 先创建WAN口配置
            self.createWan(args['wan'], args['ifname'], ip, args)
            # 再创建IP组
            ipgroup = self.__buildGroupInfo(name, ip)
            ret = self.adapi.createIPGroup(ipgroup)
            if ret.isFailed():
                raise Exception('createIPGroup failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def updateIPGroup(self, name, ip=[]):
        '''
        添加ip组
        @param name:
        @param ip:
        @return:
        '''
        LOG.error("CREATE")
        try:
            ipgroup = self.__buildGroupInfo(name, ip)
            ret = self.adapi.addIPInfo(ipgroup)
            if ret.isFailed():
                raise Exception('updateIPGroup failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def deleteIPGroup(self, name, args={}):
        '''
        删除IP组配置
        '''
        if 'wan' not in args or 'ip' not in args:
            LOG.error("no wan name or not ip")
            raise Exception()
        try:
            # 先删除IP组，再删除wan口IP
            # 删除IP组
            ret = self.adapi.delIPGroup(name)
            if ret.isFailed() and self.__configExist(ret.getErrCode()):
                raise Exception('deleteIPGroup failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
            # 删除WAN口IP
            self.delWanIP(args['wan'], args['ip'])
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def IPGroupAddIP(self, ipgrpname="", ip=[]):
        '''
        往IP组内添加IP
        '''
        try:
            # 先添加Wan口IP
            self.addWanIP(ipgrpname, ip)
            # 添加IP组IP
            ipgroup = self.__buildGroupInfo(ipgrpname, ip)
            ret = self.adapi.addIPInfo(ipgroup)
            if ret.isFailed():
                raise Exception('IPGroupAddIP failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def IPGroupDelIP(self, ipgrpname="", ip=[]):
        '''
        从IP组中删除IP
        '''
        try:
            # 先删除WAN口ip
            self.delWanIP(ipgrpname, ip)
            #在删除IP组IP
            ipgroup = self.__buildGroupInfo(ipgrpname, ip)
            ret = self.adapi.delIPInfo(ipgroup)
            if ret.isFailed() and self.__configExist(ret.getErrCode()):
                raise Exception('IPGroupDelIP failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def __buildPersist(self, name, kargs={}):
        '''
        构建AD 会话保持配置块
        @param name:
        @param kargs:
        @return:
        '''
        persist = PersistInfo()
        persist.name = name
        persist.priorToConnect = kargs.get('priorToConnect', 'true')
        persist.type = kargs.get('type', 'PERSIST_SOURCE_IP')
        if persist.type is 'PERSIST_SOURCE_IP':
            persist.maskv4 = kargs.get('maskv4', '255.255.255.255')
            persist.maskv6 = kargs.get('maskv6', 'ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff')
            persist.sourceipTimeout = kargs.get('sourceipTimeout', DEFAULT_TIMEOUT)
        else:
            persist.cookieType = kargs.get('cookieType', 'PERSIST_COOKIE_INSERT')
            persist.cookieName = kargs.get('cookieName')
            persist.cookieDomain = kargs.get('cookieDomain', 'www.sangfor.com') # 次参数必填
            persist.cookiePath = kargs.get('cookiePath', '/')
            persist.cookieTimeout = kargs.get('cookieTimeout', DEFAULT_TIMEOUT)
        return persist

    @log_helpers.log_method_call
    def createPersist(self, name, kargs={}):
        '''
        创建会话保持
        '''
        try:
            persist = self.__buildPersist(name,kargs)
            ret = self.adapi.createPersist(persist)
            if ret.isFailed():
                raise Exception('createPersist failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def deletePersist(self, name):
        '''
        删除会话保持
        '''
        try:
            ret = self.adapi.delPersist(name)
            if ret.isFailed() and self.__configExist(ret.getErrCode()):
                raise Exception('deletePersist failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    def __buildMonitor(self, name, type='MONITOR_CONNECT_TCP', kargs={}):
        monitor = MonitorInfo()
        monitor.name = name
        monitor.type = type
        monitor.interval = kargs.get('interval', 5)
        monitor.timeout = kargs.get('timeout', 2)
        monitor.tryout = kargs.get('tryout', 3)
        monitor.debug = kargs.get('debug', 'true')
        monitor.addr = kargs.get('addr', '*')
        # MONITOR_ICMPV4/MONITOR_ICMPV6
        if monitor.type is 'MONITOR_ICMPV4' or \
           monitor.type is 'MONITOR_ICMPV6':
            monitor.isFirewall = kargs.get('isFirewall', 'false')
            return monitor
        # MONITOR_CONNECT_HTTP
        if monitor.type is 'MONITOR_CONNECT_HTTP':
            monitor.port = kargs.get('port', 80)
            if kargs.has_key('respCode'):
                for code in kargs.get('respCode'):
                    monitor.respCode.append(code)
            else:
                monitor.respCode = ['200', '302']
            monitor.urlMsg = kargs.get('urlMsg', '/')
            return monitor
        # MONITOR_CONNECT_TCP/MONITOR_CONNECT_UDP
        monitor.port = kargs.get('port', 0)
        monitor.maxRecvBuf = int(kargs.get('maxRecvBuf', 2048))
        monitor.sendMsg = kargs.get('sendMsg', 'sangfor')           #必填
        monitor.recvInclude = kargs.get('recvInclude', 'sangfor')   #必填
        monitor.closeSendMsg = kargs.get('closeSendMsg', 'sangfor') # 必填
        return monitor

    @log_helpers.log_method_call
    def createMonitor(self, name, type='MONITOR_CONNECT_TCP', kargs={}):
        '''
        新建监视器
        '''
        try:
            monitor = self.__buildMonitor(name, type, kargs)
            ret = self.adapi.createMonitorInfo(monitor)
            if ret.isFailed():
                raise Exception('createMonitor failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def updateMonitor(self, name, type='MONITOR_CONNECT_TCP', kargs={}):
        '''
        更新监视器
        '''
        try:
            monitor = self.__buildMonitor(name, type, kargs)
            monitor.type = None # 更新时，不需要类型
            ret = self.adapi.updateMonitorInfo(name, monitor)
            if ret.isFailed():
                raise Exception('updateMonitor failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def deleteMonitor(self, name):
        '''
        删除监视器
        '''
        try:
            ret = self.adapi.delMonitorInfo(name)
            if ret.isFailed() and self.__configExist(ret.getErrCode()):
                raise Exception('deleteMonitor failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    def __buildPool(self, name, kargs={}):
        nodepool = PoolInfo()
        nodepool.name = name
        nodepool.monitors.append(kargs.get('monitor', 'ping'))
        nodepool.minMonitors = kargs.get('minMonitors', 0)
        nodepool.recoverInterval = kargs.get('recoverInterval', 0)
        nodepool.stepperInterval = kargs.get('stepperInterval', 0)
        nodepool.connStatAll = kargs.get('connStatAll', 'true')
        nodepool.persist1Name = kargs.get('persist1Name', 'none')
        nodepool.persist2Name = kargs.get('persist2Name', 'none')
        nodepool.schedMethod = kargs.get('schedMethod', 'SCHED_METHOD_FAIELD')
        if nodepool.schedMethod is 'SCHED_METHOD_QUEUE':
            nodepool.queueLength = kargs.get('queueLength', 100)
            nodepool.queueTimeout = kargs.get('queueTimeout', 5)
        nodepool.lbMethod = kargs.get('lbMethod', 'NODE_LB_RR')
        if nodepool.lbMethod is 'NODE_LB_HASH':
            nodepool.hashType = kargs.get('hashType', 'HASH_SRC_IP')
        return nodepool

    @log_helpers.log_method_call
    def createPool(self, name, kargs={}):
        '''
        新建节点池
        '''
        try:
            nodepool = self.__buildPool(name, kargs)
            ret = self.adapi.createPoolInfo(nodepool)
            if ret.isFailed():
                raise Exception('createPool failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def updatePool(self, name, kargs={}):
        '''
        更新节点池
        '''
        try:
            nodepool = self.__buildPool(name, kargs)
            ret = self.adapi.updatePoolInfo(name, nodepool)
            if ret.isFailed():
                raise Exception('updatePool failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def deletePool(self, name):
        '''
        删除节点池
        '''
        try:
            ret = self.adapi.delPoolInfo(name)
            if ret.isFailed() and self.__configExist(ret.getErrCode()):
                raise Exception('deletePool failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    def __buildNode(self, name, ip="", port=80, kargs={}):
        '''
        构建AD 节点配置块
        @param name: 名字
        @param ip:  ip
        @param port:
        @param kargs:
        @return:  节点配置块
        '''
        node = NodeInfo()
        node.confStatus = 'NODE_ENABLE'
        # 节点权值校正
        node.ratio = int(kargs.get('ratio', 1))
        if node.ratio > DEFAULT_WEIGHT_MAX:
            node.ratio = DEFAULT_WEIGHT_MAX
            LOG.info("addriver member weight must be adjust ,"
                     "effective from 1 to DEFAULT_WEIGHT_MAX = 100 to ad")
        node.maxConnects = kargs.get('maxConnects', 0)
        node.newConnects = kargs.get('newConnects', 0)
        node.maxRequest = kargs.get('maxRequest', 0)
        node.nodeIP = ip
        node.nodePort = port
        return node

    @log_helpers.log_method_call
    def createMember(self, name, ip="", port=80, kargs={}):
        '''
        往节点池添加解决点
        '''
        try:
            node = self.__buildNode(name, ip, port, kargs)
            ret = self.adapi.createNode(name, node)
            if ret.isFailed():
                raise Exception('createMember failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def deleteMember(self, name, ip="", port=80, kargs={}):
        '''
        删除节点池中的节点
        '''
        try:
            ret = self.adapi.delNode(name, ip, port)
            if ret.isFailed() and self.__configExist(ret.getErrCode()):
                raise Exception('deleteMember failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def updateMemeber(self, name, ip="", port=80, kargs={}):
        '''
        更新节点信息
        '''
        try:
            node = self.__buildNode(name, ip, port, kargs)
            ret = self.adapi.updateNode(name, ip, port, node)
            if ret.isFailed():
                raise Exception('updateMemeber failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def addPoolMonitor(self, poolname, monitorname):
        '''
        往节点池中添加监视器
        '''
        try:
            ret = self.adapi.addMonitor(poolname, monitorname)
            if ret.isFailed():
                raise Exception('addPoolMonitor failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def delPoolMonitor(self, poolname, monitorname):
        '''
        删除节点池中的监视器
        '''
        try:
            ret = self.adapi.delMonitor(poolname, monitorname)
            if ret.isFailed() and self.__configExist(ret.getErrCode()):
                raise Exception('delPoolMonitor failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    def __buildVS(self, name, kargs={}):
        '''
        构建AD 虚拟服务配置块
        @param name:
        @param kargs:
        @return:
        '''
        vs = VSInfo()
        vs.name = name
        vs.enable = kargs.get('enable', 'true')
        vs.ipgName = kargs.get('ipgName')           # 必填
        vs.serviceName = kargs.get('serviceName')   # 必填
        vs.poolName = kargs.get('poolName')         # 必填
        # 判断是否开启自动snat
        vs.autoSnat = kargs.get('autoSnat', 'true')
        # openstack HTTP  --> AD HTTP 7层负载
        # openstack HTTPS --> AD TCP 4层负载
        # openstack TCP   --> AD TCP 4层负载
        # openstack TERMINATED_HTTPS --> AD TCP 4层负载
        vs.mode = kargs.get('mode', 'VS_MODE_L4')
        if vs.mode is 'VS_MODE_L7':
            vs.httpSchedMode = kargs.get('httpSchedMode', 'HTTP_SCHED_MODE_EVERY_REQ') # 只用于7层VS
            vs.tcpCacheStream = kargs.get('tcpCacheStream', 'false') # 7层VS,服务为smtp/imap/pop时才填
            if vs.tcpCacheStream is 'true':
                vs.endStr = kargs.get('endStr', '/')
        if vs.mode is 'VS_MODE_L3':
            vs.serviceName = kargs.get('serviceName', 'layer3')
        vs.dnatEnable = kargs.get('dnatEnable', 'false')
        return vs

    def getPoolList(self):
        return self.adapi.getPoolList()

    @log_helpers.log_method_call
    def createVS(self, name, kargs={}):
        '''
        新建虚拟服务
        @param name:  虚拟服务名字
        @param kargs:  携带配置字典
        @return:
        '''
        try:
            vs = self.__buildVS(name, kargs)
            ret = self.adapi.createVS(vs)
            if ret.isFailed():
                raise Exception('createVS failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    def __buildUpdateVS(self, kargs={}):
        vs = VSInfo()
        vs.enable = kargs.get('enable')
        vs.ipgName = kargs.get('ipgName')
        vs.serviceName = kargs.get('serviceName')
        vs.poolName = kargs.get('poolName')
        vs.autoSnat = kargs.get('autoSnat')
        vs.httpSchedMode = kargs.get('httpSchedMode')
        vs.tcpCacheStream = kargs.get('tcpCacheStream')
        vs.endStr = kargs.get('endStr')
        vs.dnatEnable = kargs.get('dnatEnable')
        return vs
    @log_helpers.log_method_call
    def updateVS(self, name, kargs={}):
        '''
        更新虚拟服务
        @param name:  虚拟服务名字
        @param kargs:
        @return:
        '''
        try:
            vs = self.__buildUpdateVS(kargs)
            ret = self.adapi.updateVS(name, vs)
            if ret.isFailed():
                raise Exception('updateVS failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def deleteVS(self, name):
        '''
        删除虚拟服务
        '''
        try:
            ret = self.adapi.delVS(name)
            if ret.isFailed() and self.__configExist(ret.getErrCode()):
                raise Exception('deleteVS failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    def __buildACL(self, name, kargs={}):
        '''
        构建AD 高级acl配置块
        @param name:
        @param kargs:
        @return:
        '''
        acl = AclInfo()
        acl.name = name
        acl.vsname = kargs.get('vsname')
        acl.enable = kargs.get('enable', 'true')
        acl.type = kargs.get('type', 'ADDR_ALL')
        acl.info = kargs.get('info')
        acl.connectLimit = kargs.get('connectLimit', 2000)
        return acl

    @log_helpers.log_method_call
    def createACL(self, name, kargs):
        '''
        创建高级ACL
        '''
        try:
            acl = self.__buildACL(name, kargs)
            ret = self.adapi.createAcl(acl)
            if ret.isFailed():
                raise Exception('createACL failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def updateACL(self, name, kargs={}):
        '''
        更新高级ACL
        '''
        try:
            acl = self.__buildACL(name, kargs)
            ret = self.adapi.updateAcl(acl)
            if ret.isFailed():
                raise Exception('updateACL failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def deleteACL(self, name):
        '''
        删除高级ACL
        '''
        try:
            ret = self.adapi.deleteAcl(name)
            if ret.isFailed() and self.__configExist(ret.getErrCode()):
                raise Exception('deleteACL failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    def __buildWan(self, name, ifname, ips=[], args={}):
        wan = WanInfo()
        wan.name = name
        wan.ifname = ifname
        wan.enable = 'true'
        for item in ips:
            ip = item + '/' + str(args.get('mask', 22))
            wan.ip.append(AddrElement(ip))
        wan.gwAddr.append(AddrElement(args.get('gatewayIP')))
        wan.maxUpBandwidth = 10000
        wan.maxDownBandwidth = 10000
        wan.upBusyRate = 80
        wan.downBusyRate = 80
        wan.enableDetect = 'false'
        wan.enableNicCheck = 'false'
        return wan

    def __addIPWithName(self, name, ips=[]):
        '''
        当存在WAN口配置时，只需要往网口中添加IP
        @return True: 网口存在，False：网口不存在
        '''
        return False
        wan = self.adapi.getWanInfo(name)
        if wan.isFailed() and self.__configExist(wan.getErrCode()) == False:
            return False
        # 网口肯定会有ip
        mask = wan.ip[0].ip.split('/')[1]
        wanInfo = WanInfo()
        wanInfo.ip = wan.ip
        for item in ips:
            ip = item + '/' + str(mask)
            wanInfo.ip.append(AddrElement(ip))
        self.adapi.updateWanInfo(name, wanInfo)
        return True


    @log_helpers.log_method_call
    def createWan(self, name, ifname, ips=[], args={}):
        '''
        创建wan口
        '''
        try:
            # 如果网口存在则直接添加IP
            if self.__addIPWithName(name, ips):
                return
            # 网口不存在，需要创建
            wan = self.__buildWan(name, ifname, ips, args)
            print wan.name
            ret = self.adapi.createWanInfo(wan)
            if ret.isFailed():
                raise Exception('createWan failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def updateWan(self, name, ifname, ips=[], args={}):
        '''
        创建wan口
        '''
        try:
            # 网口不存在，需要创建
            wan = self.__buildWan(name, ifname, ips, args)
            ret = self.adapi.updateWanInfo(name, wan)
            if ret.isFailed():
                raise Exception('updateWan failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def deleteWan(self, name):
        '''
        删除wan口
        '''
        try:
            ret = self.adapi.deleteWanInfo(name)
            if ret.isFailed():
                raise Exception('deleteWan failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    def __addIP(self, name, ips=[]):
        wan = self.adapi.getWanInfo(name)
        if wan.isFailed() and self.__configExist(wan.getErrCode()):
            raise Exception('getWanInfo failed[%d, %s]' % (wan.getErrCode(),
                                                          wan.getErrStr()))
        # 网口肯定会有ip
        mask = wan.ip[0].ip.split('/')[1]
        wanInfo = WanInfo()
        wanInfo.ip = wan.ip
        for item in ips:
            ip = item + '/' + str(mask)
            wanInfo.ip.append(AddrElement(ip))
        return wanInfo

    @log_helpers.log_method_call
    def addWanIP(self, name, ips=[]):
        '''
        添加WAN口IP
        '''
        try:
            # 先获取WAN口IP
            wan = self.__addIP(name, ips)
            self.adapi.updateWanInfo(name, wan)
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    def __findIP(self, ip, ips=[]):
        for item in ips:
            if item == ip:
                return True
        return False

    def __delIP(self, name, ips=[]):
        wan = self.adapi.getWanInfo(name)
        if wan.isFailed() and self.__configExist(wan.getErrCode()):
            raise Exception('getWanInfo failed[%d, %s]' % (wan.getErrCode(),
                                                          wan.getErrStr()))
        # 网口肯定会有ip
        mask = wan.ip[0].ip.split('/')[1]
        wanInfo = WanInfo()
        # 过滤掉要删除的ip
        for item in wan.ip:
            if self.__findIP(item.ip.split('/')[0], ips) == False:
                wanInfo.ip.append(item)
        return wanInfo

    @log_helpers.log_method_call
    def delWanIP(self, name, ips=[]):
        '''
        删除WAN口IP
        '''
        try:
            # 先获取WAN口IP
            wan = self.__delIP(name, ips)
            self.adapi.updateWanInfo(name, wan)
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

if __name__ == '__main__':
    ad = ADHOST('admin', 'root1234', '200.200.147.193', '443')

    #ad.deleteMacvlan('test123')
    ad.deleteMacvlan('openstack-179f2ae3-606a-4670-8802-276d9e1dc596')
    ad.deleteNetns('openstack-179f2ae3-606a-4670-8802-276d9e1dc596')
    ad.deleteVlan('op-vlan-52db8248-76de-4585-b6e0-e7999400ee0d')
    '''
    ad.createVlan('openstack_2_123', 123, 'eth2')
    vlan_device = ad.getVlanDevice('openstack_2_123')
    ad.createNetns('openstack_test5', 'test_user1')
    netns_id = ad.getNetnsId('openstack_test5')
    ad.createMacvlan('openstack_test5', '0A:ff:fe:22:33:44', vlan_device, netns_id)
    #ad.deleteMacvlan('openstack_test5')
    #print ad.getMacvlanDevice('openstack_test2')

    #wan test
    args = {'mask':24,'gatewayIP':'43.23.111.2'}
    ips = ['43.23.111.33', '22.44.123.44']
    ad.createWan('wan2_222', 'eth2.222', ips, args)
    #ad.deleteWan('wan5')
    '''
