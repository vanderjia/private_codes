# -*- coding: utf-8 -*-
# Copyright (c) 2008-2016, AD SANGFOR, [Version 6.3.0]
# Filename: LogInfo.py

import logging

class LogInfo () :
    def __init__(self) :
        None
    @classmethod
    def makeLogger(cls, log):
        #LOG_FILENAME = 'log_test.txt'
        logging.basicConfig(level=logging.NOTSET)
        logger = logging.getLogger(__name__)
        logger.debug(log)
        #logging.debug(log+"\n")
        
        
if __name__ == "__main__":
    None


