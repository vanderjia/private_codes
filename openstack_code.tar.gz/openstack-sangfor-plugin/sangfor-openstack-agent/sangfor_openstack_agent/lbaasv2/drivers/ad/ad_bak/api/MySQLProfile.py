# -*- coding: utf-8 -*-
# Copyright (c) 2008-2016, AD SANGFOR, [Version 6.3.0]
# Filename: ServConfig.py

from ErrorInfo import ErrInfo
from urllib2 import base64
from APIException import APIException
import XMLObject as xmlo
import urllib
from Configuration import Configuration
from ParentList import ParentList

class userInfo (ErrInfo):
    def __init__(self, httpBody = None) :
        ErrInfo.__init__(self, httpBody)
        self.username = None
        self.passwd = None
        if httpBody == "" or httpBody == None :
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0 :
            return
        if not isinstance(httpBody, unicode) :
                httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)
            if self.xmlObj.hasTag("username") :
                self.username = urllib.unquote(Configuration.base64decode(self.xmlObj["username"][0].getChildValue()))
            if self.xmlObj.hasTag("passwd"):
                self.passwd = urllib.unquote(Configuration.base64decode(self.xmlObj["passwd"][0].getChildValue()))
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)
class MySQLProfileInfo (ErrInfo) :
    def __init__(self, httpBody = None) :
        ErrInfo.__init__(self, httpBody)
        self.name = None
        self.user = []
        self.connect_enable = None
        self.connect_size = -1
        self.timeout = -1
        self.mask = -1
        self.version = -1
        self.server_version = None
        self.string_unit = -1
        self.server_unit = -1
        self.length = 0
        if httpBody == "" or httpBody == None :
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0 :
            return
        if not isinstance(httpBody, unicode) :
                httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)
            if self.xmlObj.hasTag("name") :
                self.name = urllib.unquote(Configuration.base64decode(self.xmlObj["name"][0].getChildValue()))
            if self.xmlObj.hasTag("connect_enable") :
                self.connect_enable = self.xmlObj["connect_enable"][0].getChildValue()
            if self.xmlObj.hasTag("connect_size") :
                self.connect_size = self.xmlObj["connect_size"][0].getChildValue()
            if self.xmlObj.hasTag("timeout") :
                self.timeout = self.xmlObj["timeout"][0].getChildValue()
            if self.xmlObj.hasTag("mask") :
                self.mask = self.xmlObj["mask"][0].getChildValue()
            if self.xmlObj.hasTag("version") :
                self.version = self.xmlObj["version"][0].getChildValue()
            if self.xmlObj.hasTag("server_version") :
                self.server_version = self.xmlObj["server_version"][0].getChildValue()
            if self.xmlObj.hasTag("string_unit") :
                self.string_unit = self.xmlObj["string_unit"][0].getChildValue()
            if self.xmlObj.hasTag("server_unit") :
                self.server_unit = self.xmlObj["server_unit"][0].getChildValue()
            if self.xmlObj.hasTag("MySQLProfileType") :
                userInfoList = self.xmlObj["user"]
                for i in range(len(userInfoList)) :
                    node = userInfo(userInfoList[i].toxml())
                    self.user.append(node)
                    self.length += 1
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)
    def __str__(self) :
        return self.originStr
    @classmethod
    def usertoxml(cls, MySQLProfile):
        params = ""
        username = ""
        passwd = ""
        for user in MySQLProfile.user:
            if user.username != None:
                username = '<username>' + base64.b64encode(user.username) + '</username>\n'
            if user.passwd != None:
                passwd = '<passwd>' + base64.b64encode(user.passwd) + '</passwd>\n'
            params += "<user>\n" + username + passwd + "</user>\n"
        return params
    
    @classmethod
    def make_xml_data(cls, MySQLProfile, action) : 
        params = "<mysqlprofile>\n"
        if (MySQLProfile.name != None) and (action == 'create') :
            params += "<name>" + base64.b64encode(MySQLProfile.name) + "</name>\n"
        user = MySQLProfileInfo.usertoxml(MySQLProfile)
        if user != None :
            params += user
        if MySQLProfile.connect_enable != None :
            params += "<connect_enable>" + MySQLProfile.connect_enable + "</connect_enable>\n"
        if MySQLProfile.connect_size != -1 :
            params += "<connect_size>" + str(MySQLProfile.connect_size) + "</connect_size>\n"
        if MySQLProfile.timeout != -1 :
            params += "<timeout>" + str(MySQLProfile.timeout) + "</timeout>\n"
        if MySQLProfile.mask != -1 :
            params += "<mask>" + str(MySQLProfile.mask) + "</mask>\n"
        if MySQLProfile.version != -1 :
            params += "<version>" + str(MySQLProfile.version) + "</version>\n"
        if MySQLProfile.server_version != None :
            params += "<server_version>" + MySQLProfile.server_version + "</server_version>\n"
        if MySQLProfile.string_unit != -1 :
            params += "<string_unit>" + str(MySQLProfile.string_unit) + "</string_unit>\n"
        if MySQLProfile.server_unit != -1 :
            params += "<server_unit>" + str(MySQLProfile.server_unit) + "</server_unit>\n"
        params += "</mysqlprofile>\n"
        return params

    @classmethod
    def generatingMySQLProfileInfo(cls, httpBody) :
        return MySQLProfileInfo(httpBody)