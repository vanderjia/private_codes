# -*- coding: utf-8 -*-
# Copyright (c) 2008-2016, AD SANGFOR, [Version 6.3.0]
# Filename: Monitor.py

from ErrorInfo import ErrInfo
from urllib2 import base64
from Configuration import Configuration
from APIException import APIException
import XMLObject as xmlo
import urllib
from ParentList import ParentList

class MonitorInfo (ErrInfo) :
    def __init__(self, httpBody = None) :
        ErrInfo.__init__(self, httpBody)
        self.name = None
        self.type = None
        self.interval = -1
        self.timeout = -1
        self.tryout = -1
        self.addr = None
        self.port = -1
        self.debug = None
        self.recv_buf_max = -1
        self.send_msg = None
        self.recv_include = None
        self.close_send_msg = None
        self.resp_code = -1
        self.url_msg = None
        self.hex = None
        self.is_firewall = None
        
        if httpBody == "" or httpBody == None :
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0 :
            return
        if not isinstance(httpBody, unicode) :
                httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)
            if self.xmlObj.hasTag("name") :
                self.name = urllib.unquote(Configuration.base64decode(self.xmlObj["name"][0].getChildValue()))
            if self.xmlObj.hasTag("monitor_name") :
                self.name = urllib.unquote(Configuration.base64decode(self.xmlObj["monitor_name"][0].getChildValue()))
            if self.xmlObj.hasTag("type") :
                self.type = self.xmlObj["type"][0].getChildValue()
            if self.xmlObj.hasTag("interval") :
               self.interval = self.xmlObj["interval"][0].getChildValue()
            if self.xmlObj.hasTag("timeout") :
               self.timeout = self.xmlObj["timeout"][0].getChildValue()
            if self.xmlObj.hasTag("tryout") :
                self.tryout = self.xmlObj["tryout"][0].getChildValue()
            if self.xmlObj.hasTag("addr") :
                self.addr = self.xmlObj["addr"][0].getChildValue()
            if self.xmlObj.hasTag("port") :
                self.port = self.xmlObj["port"][0].getChildValue()
            if self.xmlObj.hasTag("debug") :
               self.debug = self.xmlObj["debug"][0].getChildValue()
            if self.xmlObj.hasTag("recv_buf_max") :
               self.recv_buf_max = self.xmlObj["recv_buf_max"][0].getChildValue()
            if self.xmlObj.hasTag("send_msg") :
                self.send_msg = urllib.unquote(self.xmlObj["send_msg"][0].getChildValue())
            if self.xmlObj.hasTag("recv_include") :
                self.recv_include = urllib.unquote(self.xmlObj["recv_include"][0].getChildValue())
            if self.xmlObj.hasTag("close_send_msg") :
                self.close_send_msg = urllib.unquote(self.xmlObj["close_send_msg"][0].getChildValue())
            if self.xmlObj.hasTag("hex") :
                self.hex = self.xmlObj["hex"][0].getChildValue()
            if self.xmlObj.hasTag("resp_code") :
                self.resp_code = self.xmlObj["resp_code"][0].getChildValue()
            if self.xmlObj.hasTag("url_msg") :
                self.url_msg = self.xmlObj["url_msg"][0].getChildValue()
            if self.xmlObj.hasTag("is_firewall") :
                self.url_msg = self.xmlObj["is_firewall"][0].getChildValue()
            
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)
    def __str__(self) :
        return self.originStr
    @classmethod
    def make_resp_data(cls, orig_resp) : 
        resp_data = ''
        resp_array = orig_resp.split(',')
        for resp in resp_array:
            resp_num = resp.split('-')
            if len(resp_num) == 1:
                resp_data += ';' + resp_num[0]
            elif len(resp_num) == 2:
                data = resp_num[0]
                while str(data) != resp_num[-1]:
                    resp_data += ';' + str(data)
                    data = int(data) + 1
                resp_data += ';' + str(data)
        resp_data = resp_data[1:]
        return resp_data
    @classmethod
    def baseInfotoxml(cls, monitor) : 
        params = ""
        if monitor.type != None :
            params += "<type>" + monitor.type + "</type>\n"
        if monitor.interval != -1 :
            params += "<interval>" + str(monitor.interval) + "</interval>\n"
        if monitor.timeout != -1 :
            params += "<timeout>" + str(monitor.timeout) + "</timeout>\n"
        if monitor.tryout != -1 :
            params += "<tryout>" + str(monitor.tryout) + "</tryout>\n"
        if monitor.addr != None : 
            params += "<addr>" + monitor.addr + "</addr>\n"
        if monitor.port != -1 :
            params += "<port>" + str(monitor.port) + "</port>\n"
        if monitor.debug != None :
            params += "<debug>" + monitor.debug + "</debug>\n"
        return params
    @classmethod
    def icmpExttoxml(cls, monitor) :
        params = ""
        if monitor.is_firewall != None :
            params += "<is_firewall>" + str(monitor.is_firewall) + "</is_firewall>\n"
        return params
    @classmethod
    def connectExttoxml(cls, monitor) : 
        params = ""
        if monitor.recv_buf_max != -1 :
            params += "<recv_buf_max>" + str(monitor.recv_buf_max) + "</recv_buf_max>\n"
        if monitor.send_msg != None :
            params += "<send_msg>" + monitor.send_msg + "</send_msg>\n"
        if monitor.recv_include != None :
            params += "<recv_include>" + monitor.recv_include + "</recv_include>\n"
        if monitor.close_send_msg != None :
            params += "<close_send_msg>" + monitor.close_send_msg + "</close_send_msg>\n"
        if monitor.resp_code != -1 :
            resp_data = MonitorInfo.make_resp_data(monitor.resp_code)
            params += "<resp_code>" + str(resp_data) + "</resp_code>\n"
        if monitor.url_msg != None :
            params += "<url_msg>" + urllib.quote_plus(monitor.url_msg.encode('utf8')) + "</url_msg>\n"
        if monitor.hex != None :
            params += "<hex>" + monitor.hex + "</hex>\n"
        return params
    
    @classmethod
    def make_xml_data(cls, monitor) : 
        params = "<monitor_info>\n"
        if monitor.name != None :
            params += "<monitor_name>" + base64.b64encode(monitor.name) + "</monitor_name>\n"
        base_info = MonitorInfo.baseInfotoxml(monitor)
        if base_info != "":
            params += "<base_info>\n" + base_info + "</base_info>\n"
        icmp_ext = MonitorInfo.icmpExttoxml(monitor)
        if icmp_ext != "":
            params += "<icmp_ext>\n" + icmp_ext + "</icmp_ext>\n"
        connect_ext = MonitorInfo.connectExttoxml(monitor)
        if connect_ext != "":
            params += "<connect_ext>\n" + connect_ext + "</connect_ext>\n"
        params += "</monitor_info>\n"
        return params
    @classmethod
    def generatingmonitorList(cls, httpBody) :
        return MonitorList(httpBody)
    @classmethod
    def generatingmonitorInfo(cls, httpBody) :
        return MonitorInfo(httpBody)
        
class MonitorList (ParentList) :
    '''
    从xml中获取监视器列表
    '''
    def __init__(self, httpBody = None) :
        ParentList.__init__(self, httpBody)
        #self.monitorList = []
        #self.length = 0
        if httpBody == None or httpBody == "" :
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0 :
            return
        if not isinstance(httpBody, unicode) :
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)
            if self.xmlObj.hasTag("NodeMonitorInfoListType"):
                if not self.xmlObj.hasTag("monitor_info"):
                    return
                monitorListXmlObj = self.xmlObj["monitor_info"]
            elif self.xmlObj.hasTag("NodeMonitorInfoType") :
                monitorListXmlObj = self.xmlObj["NodeMonitorInfoType"]
            else:
                return
            #print len(monitorListXmlObj)
            for i in range(len(monitorListXmlObj)) :
                #print monitorListXmlObj[i].toxml()
                node = MonitorInfo(monitorListXmlObj[i].toxml())
                self.elementList.append(node)
                self.length += 1
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)