# -*- coding: utf-8 -*-
# Copyright (c) 2008-2016, AD SANGFOR, [Version 6.3.0]
# Filename: NodeInfoV2.py

import XMLObject as xmlo
from Configuration import Configuration
from APIException import APIException
from ErrorInfo import ErrInfo
from http.HttpClient import HttpClient
import urllib
from urllib2 import base64
from ParentList import ParentList

class ConfStatus :
    NODE_ENABLE = "NODE_ENABLE"
    NODE_DISABLE = "NODE_DISABLE"
    NODE_OFFLINE = "NODE_OFFLINE"
    def __init__(self) :
        None
    @classmethod
    def check(cls, checkValue) :
        if (checkValue != ConfStatus.NODE_ENABLE and
            checkValue != ConfStatus.NODE_DISABLE and
            checkValue != ConfStatus.NODE_OFFLINE) :
            return False
        return True
class HealthStatus :
    NODE_NORMAL = "NODE_NORMAL"
    NODE_BUSY = "NODE_BUSY"
    NODE_FAIL = "NODE_FAIL"
    NODE_UNAVAILABLE = "NODE_UNAVAILABLE"
    NODE_DISABLE = "NODE_DISABLE"
    def __init__(self) :
        None
    @classmethod
    def check(cls, checkValue) :
        if (checkValue != HealthStatus.NODE_NORMAL and
            checkValue != HealthStatus.NODE_BUSY and
            checkValue != HealthStatus.NODE_FAIL and
            checkValue != HealthStatus.NODE_UNAVAILABLE and
            checkValue != HealthStatus.NODE_DISABLE) :
            return False
        return True

class NodeInfoV2 (ErrInfo):
    '''
    从xml中获取节点信息
    '''
    def __init__(self, httpBody = None) :
        ErrInfo.__init__(self, httpBody)
        self.nodePoolName = None
        self.nodeIP = None
        self.nodePort = -1
        self.ratio = -1
        self.maxConnects = -1
        self.newConnects = -1
        self.maxRequest = -1
        self.rsVal1 = None
        self.confStatus = None
        self.healStatus = None
        self.connection = -1
        if httpBody == "" or httpBody == None :
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0 :
            return
        if not isinstance(httpBody, unicode) :
                httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)

            if self.xmlObj.hasTag("NodeStatusListType") :
                self.nodePoolName =(
                    urllib.unquote(Configuration.base64decode(self.xmlObj["NodeStatusListType"][0].getAttri("name"))))
            if self.xmlObj.hasTag("conf_status") :
                self.confStatus = self.xmlObj["conf_status"][0].getChildValue()
                if not ConfStatus.check(self.confStatus) :
                    self.confStatus = None
            if self.xmlObj.hasTag("status") :
                self.confStatus = self.xmlObj["status"][0].getChildValue()
                if not ConfStatus.check(self.confStatus) :
                    self.confStatus = None
            if self.xmlObj.hasTag("current_status") :
                self.healStatus = self.xmlObj["current_status"][0].getChildValue()
                if not HealthStatus.check(self.healStatus) :
                    self.healStatus = None
            if self.xmlObj.hasTag("connection") :
                self.connection = self.xmlObj["connection"][0].getChildValue()
            if self.xmlObj.hasTag("addr") :
                self.nodeIP = self.xmlObj["addr"][0].getChildValue()
            if self.xmlObj.hasTag("port") :
                self.nodePort = self.xmlObj["port"][0].getChildValue()
            if self.xmlObj.hasTag("ratio") :
                self.ratio = self.xmlObj["ratio"][0].getChildValue()
            if self.xmlObj.hasTag("max_connects") :
                self.maxConnects = self.xmlObj["max_connects"][0].getChildValue()
            if self.xmlObj.hasTag("new_connects") :
                self.newConnects = self.xmlObj["new_connects"][0].getChildValue()
            if self.xmlObj.hasTag("max_request") :
                self.maxRequest = self.xmlObj["max_request"][0].getChildValue()
            if self.xmlObj.hasTag("rs_val1") :
                xmlChildObj = self.xmlObj["rs_val1"][0]
                self.rsVal1 = xmlChildObj.getChildValue()
                if (self.rsVal1 != "" and self.rsVal1 != None) :
                    self.rsVal1 = urllib.unquote(Configuration.base64decode(str(xmlChildObj.getChildValue())))
                    print 'rsVal1:' + self.rsVal1
                    if not isinstance(self.rsVal1, unicode) :
                        self.rsVal1 = unicode(self.rsVal1, "utf8")
                else :
                    self.rsVal1 = ""
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)
    def __str__(self) :
        return self.originStr
    #@staticmethod
    @classmethod
    def generatingNodeList(cls, httpBody) :
        return NodeList(httpBody)
    @classmethod
    def generatingNodeInfo(cls, httpBody) :
        return NodeInfoV2(httpBody)
    @classmethod
    def generatingNodeStatus(cls, httpBody) :
        return NodeList(httpBody)
        
        
    @classmethod
    def nodeinfoToXml(cls, node, action = None) :
        params = "<node_info>\n"
        if node.confStatus != None :
            params += "<status>" + node.confStatus + "</status>\n"
        if node.ratio != -1 :
            params += "<ratio>" + str(node.ratio) + "</ratio>\n"
        if node.maxConnects != -1 :
            params += "<max_connects>" + str(node.maxConnects) + "</max_connects>\n"
        if node.newConnects != -1 :
            params += "<new_connects>" + str(node.newConnects) + "</new_connects>\n"
        if node.maxRequest != -1 :
            params += "<max_request>" + str(node.maxRequest) + "</max_request>\n"
        if node.rsVal1 != None :
            params += "<rs_val1>" + base64.b64encode(node.rsVal1) + "</rs_val1>\n"
        if (node.nodeIP != None) and (action == "create") :
            params += "<addr>" + node.nodeIP + "</addr>\n"
        if node.nodePort != -1 :
            params += "<port>" + str(node.nodePort) + "</port>\n"
        params += "</node_info>\n"
        return params

class NodeList (ParentList) :
    '''
    从xml中获取节点列表
    '''
    def __init__(self, httpBody = None) :
        ParentList.__init__(self, httpBody)
        # self.nodeList = []
        # self.length = 0
        #self.index = 0
        if httpBody == None or httpBody == "" :
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0 :
            return
        if not isinstance(httpBody, unicode) :
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)
            if self.xmlObj.hasTag("NodeStatusListType") :
                self.nodePoolName =(
                    urllib.unquote(Configuration.base64decode(self.xmlObj["NodeStatusListType"][0].getAttri("name"))))
                if not self.xmlObj.hasTag('node'):
                    return
                nodeListXmlObj = self.xmlObj["node"]
            elif self.xmlObj.hasTag("NodeInfoType") :
                nodeListXmlObj = self.xmlObj["NodeInfoType"]
            if self.xmlObj.hasTag("NodeListType") :
                self.nodePoolName =(
                    urllib.unquote(Configuration.base64decode(self.xmlObj["NodeListType"][0].getAttri("name"))))
                if not self.xmlObj.hasTag("node"):
                    return
                nodeListXmlObj = self.xmlObj["node"]
            
            
            #print nodeListXmlObj.m_obj
            #print len(nodeListXmlObj)
            for i in range(len(nodeListXmlObj)) :
                #print nodeListXmlObj[i].toxml()
                node = NodeInfoV2(nodeListXmlObj[i].toxml())
                self.elementList.append(node)
                self.length += 1
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)




