# -*- coding: utf-8 -*-
# Copyright (c) 2008-2016, AD SANGFOR, [Version 6.3.0]
# Filename: SysStatus.py

from Configuration import Configuration
from APIException import APIException
from ErrorInfo import ErrInfo
from urllib2 import base64
import XMLObject as xmlo

class SysInfo (ErrInfo) :
    def __init__(self, httpBody = None) :
        ErrInfo.__init__(self, httpBody)
        self.dev_conn = -1
        self.dev_new_conn = -1
        self.cpu = None
        self.mem = None
        self.tput_in = None
        self.tput_out = None
        if httpBody == "" or httpBody == None :
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0 :
            return
        if not isinstance(httpBody, unicode) :
                httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)
            if self.xmlObj.hasTag("dev_conn") :
                self.dev_conn = self.xmlObj["dev_conn"][0].getChildValue()
            if self.xmlObj.hasTag("dev_new_conn") :
                self.dev_new_conn = self.xmlObj["dev_new_conn"][0].getChildValue()
            if self.xmlObj.hasTag("cpu") :
                self.cpu = self.xmlObj["cpu"][0].getChildValue()
            if self.xmlObj.hasTag("mem") :
                self.mem = self.xmlObj["mem"][0].getChildValue()
            if self.xmlObj.hasTag("tput_in") :
                self.tput_in = self.xmlObj["tput_in"][0].getChildValue()
            if self.xmlObj.hasTag("tput_out") :
                self.tput_out = self.xmlObj["tput_out"][0].getChildValue()
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)
    def __str__(self) :
        return self.originStr
    @classmethod
    def generatingsysInfo(cls, httpBody) :
        return SysInfo(httpBody)