# -*- coding: utf-8 -*-
# Copyright (c) 2008-2016, AD SANGFOR, [Version 6.3.0]
# Filename: ErrorInfo.py

from APIException import APIException
import XMLObject as xmlo

# 错误信息类。同时负责解析XML，若解析失败，则抛出异常
class ErrInfo (object) :
    def __init__(self, httpBody = None) :
        self.beFailed = False
        self.errCode = None
        self.errStr = None
        if httpBody == None or httpBody == "":
            self.originStr = ""
            return
        if not isinstance(httpBody, unicode) :
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)
            if not self.xmlObj.hasTag("error") :
                return
            xmlChildObj = self.xmlObj["err_code"][0]
            self.errCode = int(str(xmlChildObj.getChildValue()))
            xmlChildObj = self.xmlObj["err_info"][0]
            self.errStr = xmlChildObj.getChildValue()
            if not self.errCode == 0:
                self.beFailed = True
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)
    def isFailed(self) :
        return self.beFailed
    def getErrCode(self) :
        return self.errCode
    def getErrStr(self) :
        return self.errStr
    def __str__(self) :
        return str(self.originStr.encode("utf8"))
