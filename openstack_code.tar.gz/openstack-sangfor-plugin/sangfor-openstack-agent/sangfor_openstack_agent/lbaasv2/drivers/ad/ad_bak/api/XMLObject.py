# -*- coding: utf-8 -*-
# Copyright (c) 2008-2016, AD SANGFOR, [Version 6.3.0]
# Filename: XMLObject.py

from xml.dom import minidom

def parseXmlString(xmlStr):
    return minidom.parseString(xmlStr)

def hasTag(xmlDoc, tag) :
    return xmlDoc.getElementsByTagName(tag) != []

def getChildListObj(xmlDoc, tag) :
    return XMLChildListObject(xmlDoc.getElementsByTagName(tag))

def getChildObj(childListObj, index) :
    return XMLChildObject(childListObj[index])

def getChildObjAttri(childObj, key) :
    return childObj.attributes[key].value

def getTagData(xmlDoc, tag, index) :
    return xmlDoc.getElementsByTagName(tag)[index].childNodes[index].nodeValue

class XMLObjectException (StandardError) :
    '''
    解析XML字符串
    '''
    def __init__(self, code, reason) :
        '''
        1 can't parse xml
        2 can't find tag
        3 can't find attributes
        4 can't find child nodes
        5 can't get node value
        @param  reason 出错信息
        @type   str
        @param  code 错误码
        @type   int
        '''
        StandardError.__init__(self, reason)
        self.code = code
        self.reason = reason
    def __str__(self) :
        '''
        '''
        return 'XMLObjectException: %d; %s' % (self.code, self.reason)


class XMLObject :
    def __init__(self, xmlStr) :
        '''
        要求传入的参数是unicode对象 utf8编码
        @param xmlStr 字符串
        @param unicode
        '''
        try :
            if not isinstance(xmlStr, unicode) :
                xmlStr = unicode(xmlStr, "utf8")
            self.m_xmlDoc = parseXmlString(xmlStr.encode("utf8"))
        except :
            raise XMLObjectException(1, "can't parse xml")
    def __getitem__(self, key) :
        '''
        重载下标操作符
        @param key 要获取的子节点的tag
        @type str
        @return 子节点列表
        @rtype XMLChildListObject
        '''
        if not hasTag(self.m_xmlDoc, key) :
            raise XMLObjectException(2, "can't parse xml")
        return getChildListObj(self.m_xmlDoc, key)
    def hasTag(self, tag) :
        '''
        判断是否含有tag
        @param key tag
        @type str
        @return 含有tag返回True，否则返回False
        @rtype Boolean
        '''
        return hasTag(self.m_xmlDoc, tag)
    def toxml(self) :
        '''
        返回本对象的XML字符串
        @return XML字符串
        @rtype str
        '''
        return self.m_xmlDoc.toxml()


class XMLChildListObject :
    def __init__(self, childObject) :
        self.m_obj = childObject
    def __getitem__(self, index) :
        '''
        重载下标操作符
        @param index 要获取子节点的索引
        @type int
        @return 子节点
        @rtype XMLChildObject
        '''
        ret = getChildObj(self.m_obj, index)
        if ret == None :
            raise XMLObjectException(4, "can't parse xml")
        return ret
    def __len__(self) :
        '''
        获取子节点列表长度。使用len(xmlChildObj)调用
        @return 子节点列表长度
        @rtype int
        '''
        return len(self.m_obj)
    def length(self) :
        return len(self.m_obj)

class XMLChildObject :
    def __init__(self, childObject) :
        self.m_obj = childObject
    def getAttri(self, key) :
        '''
        获取节点的属性
        @param key 属性名称
        @type str
        @return 节点属性字符串
        @rtype str
        '''
        ret = getChildObjAttri(self.m_obj, key)
        if ret == None :
            raise XMLObjectException(3, "can't parse xml")
        return ret
    # 获取子节点
    def getChildObj(self, key) :
        '''
        获取子节点
        @param key 子节点名称
        @type str
        @return 节点对象
        @rtype XMLChildObject
        '''
        if not hasTag(self.m_obj, key) :
            raise XMLObjectException(2, "can't parse xml")
        return getChildListObj(self.m_obj, key)
    # 获取第一个子节点
    def getFirstChildObj(self, key) :
        if not hasTag(self.m_obj, key) :
            raise XMLObjectException(2, "can't parse xml")
        return getChildListObj(self.m_obj, key)[0]

    def getChildValue(self) :
        '''
        若本节点为叶节点，返回叶节点的值
        @return 叶节点的值
        @rtype str
        '''
        if (len(self.m_obj.childNodes) == 0 or
            self.m_obj.childNodes[0].nodeValue == None) :
            return None
        ret = self.m_obj.childNodes[0].nodeValue
        return ret
    def hasTag(self, tag) :
        return hasTag(self.m_obj, tag)
    def toxml(self) :
        return self.m_obj.toxml()


