# -*- coding: utf-8 -*-
# Copyright (c) 2008-2016, AD SANGFOR, [Version 6.3.0]
# Filename: Ipgroup.py

from ErrorInfo import ErrInfo
from APIException import APIException
from urllib2 import base64
import XMLObject as xmlo
import urllib
from Configuration import Configuration
from ParentList import ParentList

class ipNode(ErrInfo):
    def __init__(self, httpBody = None) :
        ErrInfo.__init__(self, httpBody)
        self.netif_name = None
        self.addr = []
        if httpBody == "" or httpBody == None :
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0 :
            return
        if not isinstance(httpBody, unicode) :
                httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)
            if self.xmlObj.hasTag("netif_name") :
                self.netif_name = urllib.unquote(Configuration.base64decode(self.xmlObj["netif_name"][0].getChildValue()))
            if self.xmlObj.hasTag("ip_addr") :
                for ip in self.xmlObj["ip_addr"]:
                    self.addr.append(ip.getChildValue())
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)
class IpgroupInfo (ErrInfo) :
    def __init__(self, httpBody = None) :
        ErrInfo.__init__(self, httpBody)
        self.ipg = []
        self.name = None
        self.length = 0
        self.ipgInfo = []
        if httpBody == "" or httpBody == None :
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0 :
            return
        if not isinstance(httpBody, unicode) :
                httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)
            if self.xmlObj.hasTag("name") :
                self.name = urllib.unquote(Configuration.base64decode(self.xmlObj["name"][0].getChildValue()))
            if self.xmlObj.hasTag("IpInfoListType") :
                if self.xmlObj.hasTag("ip_list"):
                    return
                IpInfoList = self.xmlObj["ip_list"]
                for i in range(len(IpInfoList)) :
                    #print ipgListXmlObj[i].toxml()
                    node = ipNode(IpInfoList[i].toxml())
                    self.ipgInfo.append(node)
                    self.length += 1
                
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)
    def __str__(self) :
        return self.originStr
    @classmethod
    def make_xml_data(cls, ipgs) : 
        params = ""
        if ipgs != None:
            for ipg in ipgs.ipg:
                params += '<ip_info>\n'
                if ipg.netif_name != None:
                    params += '<netif_name>' + base64.b64encode(ipg.netif_name) + '</netif_name>\n'
                for ip in ipg.addr:
                    params += '<ip_addr>' + ip + '</ip_addr>\n'
                params += '</ip_info>\n'
        return params
    @classmethod
    def generatingipgList(cls, httpBody) :
        return IpgroupList(httpBody)
    @classmethod
    def generatingipgInfo(cls, httpBody) :
        return IpgroupInfo(httpBody)

class IpgroupList (ParentList) :
    '''
    从xml中获取节点列表
    '''
    def __init__(self, httpBody = None) :
        ParentList.__init__(self, httpBody)
        # self.ipgList = []
        # self.length = 0
        if httpBody == None or httpBody == "" :
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0 :
            return
        if not isinstance(httpBody, unicode) :
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)
            if self.xmlObj.hasTag("IpGroupInfoListType"):
                if not self.xmlObj.hasTag("ip_group_list"):
                    return
                ipgListXmlObj = self.xmlObj["ip_group_list"]
            elif self.xmlObj.hasTag("IpInfoListType") :
                ipgListXmlObj = self.xmlObj["IpInfoListType"]
            else:
                return
            #print len(ipgListXmlObj)
            for i in range(len(ipgListXmlObj)) :
                #print ipgListXmlObj[i].toxml()
                node = IpgroupInfo(ipgListXmlObj[i].toxml())
                self.elementList.append(node)
                self.length += 1
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)