# -*- coding: utf-8 -*-
# Copyright (c) 2008-2016, AD SANGFOR, [Version 6.3.0]
# Filename: AclInfo.py

from ErrorInfo import ErrInfo
from APIException import APIException
from urllib2 import base64
import XMLObject as xmlo
import urllib
from Configuration import Configuration
from ParentList import ParentList

class AclInfo (ErrInfo) :
    def __init__(self, httpBody = None) :
        ErrInfo.__init__(self, httpBody)
        self.name = None
        self.enable = None
        self.type = None
        self.info = None
        self.vsname = None
        self.connect_limit = -1
       
        if httpBody == "" or httpBody == None :
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0 :
            return
        if not isinstance(httpBody, unicode) :
                httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)
            if self.xmlObj.hasTag("name") :
                self.name = urllib.unquote(Configuration.base64decode(self.xmlObj["name"][0].getChildValue()))
            if self.xmlObj.hasTag("vsname") :
                self.vsname = urllib.unquote(Configuration.base64decode(self.xmlObj["vsname"][0].getChildValue()))
            if self.xmlObj.hasTag("enable") :
                self.enable = self.xmlObj["enable"][0].getChildValue()
            if self.xmlObj.hasTag("type") :
               self.type = self.xmlObj["type"][0].getChildValue()
            if self.xmlObj.hasTag("info") :
               self.info = self.xmlObj["info"][0].getChildValue()
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)
    def __str__(self) :
        return self.originStr
    @classmethod
    def makeSrcAddrToXml(cls, acl):
        src_addr = ''
        if acl.type != None:
            src_addr += '<type>' + acl.type + '</type>\n'
        if acl.info != None:
            src_addr += '<info>' + acl.info + '</info>\n'
        return src_addr
    @classmethod
    def aclinfoToXml(cls, acl) : 
        params = "<acl_info>\n"
        if acl.name != None:
            params += '<name>' + base64.b64encode(acl.name) + '</name>\n'
        if acl.enable != None:
            params += '<enable>' + str(acl.enable) + '</enable>\n'
        src_addr = AclInfo.makeSrcAddrToXml(acl)
        if src_addr != '':
            params += '<src_addr>\n' + src_addr + '</src_addr>\n'
        if acl.vsname!= None:
            params += '<vsname>' + base64.b64encode(acl.vsname) + '</vsname>\n'
        if acl.connect_limit != -1:
            params += '<connect_limit>' + str(acl.connect_limit) + '</connect_limit>\n'
        params += "</acl_info>\n"
        return params
    @classmethod
    def generatingaclList(cls, httpBody) :
        return AclList(httpBody)
    @classmethod
    def generatingaclInfo(cls, httpBody) :
        return AclInfo(httpBody)

class AclList (ParentList) :
    '''
    ��xml�л�ȡ�ڵ��б�
    '''
    def __init__(self, httpBody = None) :
        ParentList.__init__(self, httpBody)
        # self.aclList = []
        # self.length = 0
        if httpBody == None or httpBody == "" :
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0 :
            return
        if not isinstance(httpBody, unicode) :
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)
            if self.xmlObj.hasTag("AdvanceAclListType"):
                if not self.xmlObj.hasTag("acl_info"):
                    return
                aclListXmlObj = self.xmlObj["acl_info"]
            elif self.xmlObj.hasTag("AdvanceAclType") :
                aclListXmlObj = self.xmlObj["AdvanceAclType"]
            else:
                return
            #print len(aclListXmlObj)
            for i in range(len(aclListXmlObj)) :
                #print aclListXmlObj[i].toxml()
                node = AclInfo(aclListXmlObj[i].toxml())
                self.elementList.append(node)
                self.length += 1
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)