# -*- coding: utf-8 -*-
# Copyright (c) 2008-2016, AD SANGFOR, [Version 6.3.0]
# Filename: Persist.py

from ErrorInfo import ErrInfo
from urllib2 import base64
import XMLObject as xmlo
from APIException import APIException
from xml.dom import minidom
import urllib
from Configuration import Configuration
from ParentList import ParentList

class PersistInfo (ErrInfo) :
    def __init__(self, httpBody = None) :
        ErrInfo.__init__(self, httpBody)
        self.name = None
        self.p_type = None
        self.prior_to_connect = None
        self.mask_v4 = None
        self.mask_v6 = None
        self.sourceip_timeout = -1
        self.cookie_type = None
        self.cookie_name = None
        self.cookie_domain = None
        self.cookie_path = None
        self.cookie_timeout = -1
        self.persist_name = None
        if httpBody == "" or httpBody == None :
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0 :
            return
        if not isinstance(httpBody, unicode) :
                httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)
            xmlChildObj = None
            if self.xmlObj.hasTag("persist_name") :
                xmlChildObj = self.xmlObj["persist_name"][0]
                self.persist_name = urllib.unquote(Configuration.base64decode(xmlChildObj.getChildValue()))
            if self.xmlObj.hasTag("p_type") :
                xmlChildObj = self.xmlObj["p_type"][0]
                self.p_type = xmlChildObj.getChildValue()
            if self.xmlObj.hasTag("prior_to_connect") :
                xmlChildObj = self.xmlObj["prior_to_connect"][0]
                self.prior_to_connect = xmlChildObj.getChildValue()
            if self.xmlObj.hasTag("sourceIp") :
                xmlChildObj = self.xmlObj["sourceIp"][0]
                if xmlChildObj.hasTag('mask_v4'):
                    self.mask_v4 = xmlChildObj.getChildObj('mask_v4')[0].getChildValue()
                if xmlChildObj.hasTag('mask_v6'):
                    self.mask_v6 = xmlChildObj.getChildObj('mask_v6')[0].getChildValue()
                if xmlChildObj.hasTag('sourceip_timeout'):
                    self.sourceip_timeout = xmlChildObj.getChildObj('sourceip_timeout')[0].getChildValue()
            if self.xmlObj.hasTag("cookie") :
                xmlChildObj = self.xmlObj["cookie"][0]
                if xmlChildObj.hasTag('cookie_type'):
                    self.cookie_type = xmlChildObj.getChildObj('cookie_type')[0].getChildValue()
                if xmlChildObj.hasTag('cookie_name'):
                    self.cookie_name = urllib.unquote(Configuration.base64decode(xmlChildObj.getChildObj('cookie_name')[0].getChildValue()))
                if xmlChildObj.hasTag('cookie_domain'):
                    self.cookie_domain = xmlChildObj.getChildObj('cookie_domain')[0].getChildValue()
                if xmlChildObj.hasTag('cookie_path'):
                    self.cookie_path = urllib.unquote(xmlChildObj.getChildObj('cookie_path')[0].getChildValue())
                if xmlChildObj.hasTag('cookie_timeout'):
                    self.cookie_timeout = xmlChildObj.getChildObj('cookie_timeout')[0].getChildValue()
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)
    def __str__(self) :
        return self.originStr
    @classmethod
    def sourceIptoxml(cls, persist) : 
        params = ""
        if persist.mask_v4 != None :
            params += "<mask_v4>" + persist.mask_v4 + "</mask_v4>\n"
        if persist.mask_v6 != None :
            params += "<mask_v6>" + persist.mask_v6 + "</mask_v6>\n"
        if persist.sourceip_timeout != -1 :
            params += "<sourceip_timeout>" + str(persist.sourceip_timeout) + "</sourceip_timeout>\n"
        return params
    @classmethod
    def cookietoxml(cls, persist) : 
        params = ""
        if persist.cookie_type != None :
            params += "<cookie_type>" + persist.cookie_type + "</cookie_type>\n"
        if persist.cookie_name != None :
            params += "<cookie_name>" + base64.b64encode(persist.cookie_name) + "</cookie_name>\n"
        if persist.cookie_domain != None :
            params += "<cookie_domain>" + persist.cookie_domain + "</cookie_domain>\n"
        if persist.cookie_path != None :
            params += "<cookie_path>" + persist.cookie_path + "</cookie_path>\n"
        if persist.cookie_timeout != -1 :
            params += "<cookie_timeout>" + str(persist.cookie_timeout) + "</cookie_timeout>\n"
        return params
    
    @classmethod
    def make_xml_data(cls, persist) : 
        params = "<persist_info>\n"
        if persist.name != None :
            params += "<persist_name>" + base64.b64encode(persist.name) + "</persist_name>\n"
        if persist.p_type != None :
            params += "<p_type>" + persist.p_type + "</p_type>\n"
        if persist.prior_to_connect != None :
            params += "<prior_to_connect>" + persist.prior_to_connect + "</prior_to_connect>\n"
        sourceIp = PersistInfo.sourceIptoxml(persist)
        if sourceIp != "":
            params += "<sourceIp>\n" + sourceIp + "</sourceIp>\n"
        cookie = PersistInfo.cookietoxml(persist)
        if cookie != "":
            params += "<cookie>\n" + cookie + "</cookie>\n"
        params += "</persist_info>\n"
        return params
    @classmethod
    def generatingpersistList(cls, httpBody) :
        return PersistList(httpBody)
    @classmethod
    def generatingpersistInfo(cls, httpBody) :
        return PersistInfo(httpBody)
class PersistList (ParentList) :
    '''
    从xml中获取节点列表
    '''
    def __init__(self, httpBody = None) :
        ParentList.__init__(self, httpBody)
        #self.persistList = []
        #self.length = 0
        if httpBody == None or httpBody == "" :
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0 :
            return
        if not isinstance(httpBody, unicode) :
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)
            if self.xmlObj.hasTag("PersistInfoListType"):
                if not self.xmlObj.hasTag('persist_info'):
                    return
                persistListXmlObj = self.xmlObj["persist_info"]
            elif self.xmlObj.hasTag("PersistInfoType") :
                persistListXmlObj = self.xmlObj["PersistInfoType"]
            else:
                return
            #print len(persistListXmlObj)
            for i in range(len(persistListXmlObj)) :
                #print persistListXmlObj[i].toxml()
                node = PersistInfo(persistListXmlObj[i].toxml())
                self.elementList.append(node)#self.elementList是从父类继承的元素
                self.length += 1
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)