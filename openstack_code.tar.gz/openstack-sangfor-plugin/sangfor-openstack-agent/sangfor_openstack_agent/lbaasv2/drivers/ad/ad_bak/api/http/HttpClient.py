# -*- coding: utf-8 -*-
# Copyright (c) 2008-2016, AD SANGFOR, [Version 6.3.0]
# Filename: HttpClient.py

import os
import sys
sys.path.append(os.path.abspath(os.path.dirname(__file__) + '/' + '..'))
from LogInfo import LogInfo
import codecs
import urllib
import urllib2
from urllib2 import URLError
from httplib import InvalidURL
import socket
#socket.setdefaulttimeout(10)

#handler=urllib2.HTTPHandler(debuglevel=1)
#opener = urllib2.build_opener(handler)
#urllib2.install_opener(opener)

# 用于封装HTTP请求的参数
# 返回xxx=xxx&xx=xx的字符串，并进行url编码
error_status = ''
class HttpClientException (StandardError) :
    '''
    '''
    def __init__(self, code, reason) :
        '''
        1. timeout; code: 1; reason: time out
        2. http error; code: http status code; reason: http error reason
        3. unknown error; code:3; reaon: unknown error
        @param  reason 出错信息
        @type   str
        @param  code 错误码
        @type   int
        '''
        StandardError.__init__(self, reason)
        self.code = code
        self.reason = reason
    def __str__(self) :
        '''
        '''
        return ('HttpClientException: %s; %s' %
            (str(self.code), str(self.reason)))


def encodeParams(params) :
    '''
    处理请求参数。会进行url编码。
    @param params http请求的参数
    @type params dict
    @return 类似"xxx=xxx&xx=xx"格式的字符串。此字符串已经进行url编码
    @rtype string
    '''
    if len(params) == 0 :
        return ""
    args = []
    for k, v in params.iteritems() :
        qv = None
        if isinstance(v, unicode) :
            qv = v.encode("utf8")
        else :
            qv = str(v)
        args.append('%s=%s' % (urllib.quote_plus(k), urllib.quote_plus(qv)))
    #print "encodeParams params: " + str("&".join(args))
    #return urllib.quote_plus("&".join(args))
    return "&".join(args)

class RequestMethod :
    GET = "GET"
    POST = "POST"
    def __init__(self) :
        None
    @classmethod
    def check(cls, checkValue) :
        if (checkValue != RequestMethod.GET and
            checkValue != RequestMethod.POST) :
            return False
        return True
    @classmethod
    def get(cls) :
        return RequestMethod.GET
    @classmethod
    def post(cls) :
        return RequestMethod.POST

class HttpClient :
    '''
    '''
    def __init__(self) :
        None
    @classmethod
    def urlEncode(cls, sour) :
        if not isinstance(sour, str) :
            return None
        return urllib.quote(sour)
    @classmethod
    def urlDecode(cls, sour) :
        if not isinstance(sour, str) :
            return None
        return urllib.unquote(sour)
    @classmethod
    def setTimeout(cls, timeout) :
        socket.setdefaulttimeout(timeout)
    @classmethod
    def httpClient(cls, uri, params, host, port = None,
                   requestMethod=RequestMethod.GET) :
        '''
        发送https请求
        @param requestMethod 请求的类型 GET或POST
        @type requestMethod RequestMethod
        @param uri 请求的URI
        @type uri string
        @param host 请求的主机地址
        @type host string
        @param port 请求的主机端口
        @type port int
        @param params http请求的参数
        @type params dict
        @return 请求得到的数据
        @rtype string
        '''
        # 处理请求地址
        #print "something"
        port = str(port)
        if port != "0" and port != "None" :
            uri = host + ":" + port + uri
        else :
            uri = host + uri
        #if(request_type.lower() == "HTTPS".lower()) :
        uri = "https://" + uri
        #else :
        #    url = "http://" + url
        strParams = ""
        # 处理请求参数
        #print "httpClient params: " + str(params)
        if params != None and len(params) != 0 :
            strParams = encodeParams(params)
        #print "httpClient encode params: " + strParams
        httpBody = None
        if requestMethod.lower() == "GET".lower() :
            if strParams != "" :
                uri += "?" + strParams
        else :
            httpBody = strParams
        # 发送请求
        #print "uri: " + str(uri) + "\thttpBody: " + str(httpBody)
        req = urllib2.Request(uri, data = httpBody)
        body = ""
        try :
            resp = urllib2.urlopen(req)
            body = resp.read()
            #print resp.info()
            #print "body: " + str(body)
            #look = codecs.lookup("utf8")
            #body = look.decode(body)
        except urllib2.HTTPError, e:
            #print "1"
            raise HttpClientException(e.code, e.msg)
        except URLError, e :
            #print "2"
            raise HttpClientException(1, e.reason)
        except InvalidURL, e :
            #print "3"
            errStr = ""
            if len(e.args) >= 1:
                errStr = e.args[0]
            raise HttpClientException(1, errStr)
        except :
            #print "4"
            raise HttpClientException(3, "")
        #import chardet
        #print chardet.detect(body)
        #body = cls.urlDecode(body)
        if not isinstance(body, unicode) :
            body = unicode(body, "utf8")
        return body
    @classmethod
    def httpClientRestFul(cls, uri, params, host, port = None, request_type="HTTPS",
                   requestMethod=RequestMethod.GET) :
        ''' 
        restFul发送https请求
        @param requestMethod 请求的类型 GET或POST
        @type requestMethod RequestMethod
        @param uri 请求的URI
        @type uri string
        @param host 请求的主机地址
        @type host string
        @param port 请求的主机端口
        @type port int
        @param params http请求的参数
        @type params dict
        @return 请求得到的数据
        @rtype string
        '''
        # 处理请求地址
        global error_status
        port = str(port)
        if port != "0" and port != "None" :
            uri = host + ":" + port + uri
        else :
            uri = host + uri
        if(request_type.lower() == "HTTPS".lower()) :
            uri = "https://" + uri
        else :
            uri = "http://" + uri
        strParams = params
        # 处理请求参数
        #print "httpClient params: " + str(params)
        #if params != None and len(params) != 0 :
            #strParams = encodeParams(params)
        #print "httpClient encode params: " + strParams
        if isinstance(strParams, unicode) :
            LogInfo.makeLogger('unicode')
            strParams = strParams.encode("utf8")
        httpBody = None
        if requestMethod.lower() == "GET".lower() :
            if strParams != "" :
                uri += "?" + strParams
        else :
            httpBody = strParams
        # 发送请求
        LogInfo.makeLogger("uri " + str(uri))
        req = urllib2.Request(uri, data = httpBody)
        body = ""
        try :
            resp = urllib2.urlopen(req)
            error_status = "200"
            body = str(resp.read())
        except urllib2.HTTPError, e:
            error_status = str(e.code)
            LogInfo.makeLogger("HTTPError.error_status " + str(error_status))
            body = str(e.read())
            LogInfo.makeLogger("HTTPError.e.reason " + str(body))
            #500错误认为配置类内部可以处理，不raise错误
            if error_status != '500':
                raise HttpClientException(e.code, str(body))
        except URLError, e :
            print "URLError = 2"
            error_status = '1'
            LogInfo.makeLogger("URLError.error_status " + str(error_status))
            LogInfo.makeLogger("URLError.e.reason " + str(e.reason))
            #print e.__dict__
            raise HttpClientException(1, str(e.reason))
        except InvalidURL, e :
            print "InvalidURL = 3"
            error_status = '1'
            errStr = ""
            if len(e.args) >= 1:
                errStr = e.args[0]
            LogInfo.makeLogger("InvalidURL.error_status " + str(error_status))
            LogInfo.makeLogger("InvalidURL.e.reason " + str(errStr))
            raise HttpClientException(1, str(errStr))
        except :
            error_status = "1"
            print 'other_error' + str(e.read())
            LogInfo.makeLogger("otherError.error_status " + str(error_status))
            LogInfo.makeLogger("otherError.e.reason: unknow reason")
            raise HttpClientException(3, "unknow reason")
        if not isinstance(body, unicode) :
            body = unicode(body, "utf8")#body.decode('utf8')
        return body

