# -*- coding: utf-8 -*-
# Copyright (c) 2008-2016, AD SANGFOR, [Version 6.3.0]
# Filename: RespondXml.py

import XMLObject as xmlo
from xml.dom import minidom
from ErrorInfo import ErrInfo
from APIException import APIException
from LogInfo import LogInfo
# 此文件用来专门解析返回值。与ErrorInfo.py是要区分开的，restful文件正常返回是没有error字段
# 如果使用ErrorInfo文件，则判断失败
class Nodes (ErrInfo) :
    def __init__(self, httpBody = None) :
        ErrInfo.__init__(self, httpBody)#后台正常返回，则ErrorInfo直接返回来。
        self.errCode = None
        self.errStr = None
        if httpBody == None or httpBody == "":
            self.originStr = ""
            return
        if not isinstance(httpBody, unicode) :
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)
            if self.xmlObj.hasTag("err_code") :
                xmlChildObj = self.xmlObj["err_code"][0]
                self.errCode = int(str(xmlChildObj.getChildValue()))
                LogInfo.makeLogger('RespondXml[--]' + str(self.errCode))
            if self.xmlObj.hasTag("err_info") :
                xmlChildObj = self.xmlObj["err_info"][0]
                self.errStr = xmlChildObj.getChildValue()
                LogInfo.makeLogger('RespondXml[--]' + self.errStr)
            if self.errStr == "" or self.errStr == None:
                LogInfo.makeLogger('RespondXml_faultstring')
                if self.xmlObj.hasTag("faultstring") :
                    xmlChildObj = self.xmlObj["faultstring"][0]
                    self.errStr = xmlChildObj.getChildValue()
                    LogInfo.makeLogger('RespondXml_faultstring[--]' + self.errStr)
            if "Not Matched the RegExp" in self.errStr:
                self.errStr = "含有特殊字符"
            if not isinstance(self.errStr, unicode) :
                LogInfo.makeLogger('RespondXml[--] not unicode string' + self.errStr)
                self.errStr = self.errStr.decode("utf8")
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)
    def getErrCode(self) :
        return self.errCode
    def getErrStr(self) :
        return self.errStr
    def __str__(self) :
        return str(self.originStr.encode("utf8"))
