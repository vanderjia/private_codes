# -*- coding: utf-8 -*-
# Copyright (c) 2008-2016, AD SANGFOR, [Version 6.3.0]
# Filename: ServConfig.py

from ErrorInfo import ErrInfo
from urllib2 import base64
from APIException import APIException
import XMLObject as xmlo
import urllib
from Configuration import Configuration
from ParentList import ParentList

class portInfo (ErrInfo):
    def __init__(self, httpBody = None) :
        ErrInfo.__init__(self, httpBody)
        self.from_port = -1
        self.to_port = -1
        if httpBody == "" or httpBody == None :
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0 :
            return
        if not isinstance(httpBody, unicode) :
                httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)
            if self.xmlObj.hasTag("from") :
                self.from_port = self.xmlObj["from"][0].getChildValue()
            if self.xmlObj.hasTag("to"):
                self.to_port = self.xmlObj["to"][0].getChildValue()
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)
class ServInfo (ErrInfo) :
    def __init__(self, httpBody = None) :
        ErrInfo.__init__(self, httpBody)
        self.type = None
        self.port = []
        self.name = None
        self.length = 0
        self.portInfo = []
        if httpBody == "" or httpBody == None :
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0 :
            return
        if not isinstance(httpBody, unicode) :
                httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)
            if self.xmlObj.hasTag("name") :
                self.name = urllib.unquote(Configuration.base64decode(self.xmlObj["name"][0].getChildValue()))
            if self.xmlObj.hasTag("type") :
                self.type = self.xmlObj["type"][0].getChildValue()
            if self.xmlObj.hasTag("PortListType") :
                portInfoList = self.xmlObj["port"]
                for i in range(len(portInfoList)) :
                    #print ipgListXmlObj[i].toxml()
                    node = portInfo(portInfoList[i].toxml())
                    self.portInfo.append(node)
                    self.length += 1
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)
    def __str__(self) :
        return self.originStr
    @classmethod
    def portScopetoxml(cls, Server, action):
        params = ""
        to_port = ""
        from_port = ""
        for port in Server.port:
            if port.from_port != -1:
                from_port = '<from>' + str(port.from_port) + '</from>\n'
            if port.to_port != -1:
                to_port = '<to>' + str(port.to_port) + '</to>\n'
            if action == "create":
                params += "<port_scope>\n" + from_port + to_port + "</port_scope>\n"
            else:
                params += "<port_info>\n" + from_port + to_port + "</port_info>\n"
        return params
    
    @classmethod
    def make_xml_data(cls, Server, action) : 
        params = ""
        if action == 'create': 
            params = "<server_info>\n"
        if (Server.name != None) and (action == 'create') :
            params += "<name>" + base64.b64encode(Server.name) + "</name>\n"
        else:
            params += "<server_name>" + base64.b64encode(Server.name) + "</server_name>\n"
        if Server.type != None :
            params += "<type>" + Server.type + "</type>\n"
        if action == 'create':
            port_scope = ServInfo.portScopetoxml(Server,action)
        else:
            port_scope = ServInfo.portScopetoxml(Server,action)
        if port_scope != None :
            params += port_scope
        if action == 'create': 
            params += "</server_info>\n"
        return params
    @classmethod
    def generatingsrvList(cls, httpBody) :
        return SrvList(httpBody)
    @classmethod
    def generatingsrvInfo(cls, httpBody) :
        return ServInfo(httpBody)
        
class SrvList (ParentList) :
    '''
    从xml中获取节点列表
    '''
    def __init__(self, httpBody = None) :
        ParentList.__init__(self, httpBody)
        # self.srvList = []
        # self.length = 0
        if httpBody == None or httpBody == "" :
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0 :
            return
        if not isinstance(httpBody, unicode) :
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)
            if self.xmlObj.hasTag("ServiceInfoListType"):
                if not self.xmlObj.hasTag("service_info"):
                    return
                srvListXmlObj = self.xmlObj["service_info"]
            elif self.xmlObj.hasTag("PortListType") :
                srvListXmlObj = self.xmlObj["PortListType"]
            else:
                return
            #print len(srvListXmlObj)
            for i in range(len(srvListXmlObj)) :
                #print srvListXmlObj[i].toxml()
                node = ServInfo(srvListXmlObj[i].toxml())
                self.elementList.append(node)
                self.length += 1
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)