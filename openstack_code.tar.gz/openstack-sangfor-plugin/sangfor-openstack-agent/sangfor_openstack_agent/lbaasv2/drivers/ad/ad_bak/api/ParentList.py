# -*- coding: utf-8 -*-
# Copyright (c) 2008-2016, AD SANGFOR, [Version 6.3.0]
# Filename: ParentList.py

from ErrorInfo import ErrInfo

class ParentList (ErrInfo) :
    def __init__(self, httpBody = None) :
        ErrInfo.__init__(self, httpBody)
        self.elementList = []
        self.length = 0
    def __len__(self) :
        if self.elementList == None :
            return 0
        return len(self.elementList)
    def __iter__(self) :
        '''
        迭代器
        '''
        #self.index = 0
        return iter(self.elementList)
    #def next(self) :
        #if self.index == self.length :
        #    raise StopIteration
        #self.index += 1
        #return self.elementList[self.index - 1]
    def __getitem__(self, index) :
        '''
        重载下标操作符
        '''
        #if index >= self.length :
        #    return None
        return self.elementList[index]
    def __delitem__(self, key) :
        del self.elementList[key]
    def __setitem__(self, key, value) :
        self.elementList[key] = value