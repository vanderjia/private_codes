# -*- coding: utf-8 -*-
# Copyright (c) 2008-2016, AD SANGFOR, [Version 6.3.0]
# Filename: __init__.py

__version__ = '6.3.0'
__author__ = 'ad.sangfor.com'

import platform
version = platform.python_version()[:3]
if not (version >= "2.4" and version <= "2.7"):
    raise Exception("NotSupportedPythonVersion")
