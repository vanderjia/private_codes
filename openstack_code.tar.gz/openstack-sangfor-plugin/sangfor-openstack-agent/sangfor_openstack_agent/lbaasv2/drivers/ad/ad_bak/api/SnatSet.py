﻿# -*- coding: utf-8 -*-
# Copyright (c) 2008-2016, AD SANGFOR, [Version 6.3.0]
# Filename: SnatSet.py
# snat地址集
from Configuration import Configuration
from APIException import APIException
from ErrorInfo import ErrInfo
from urllib2 import base64
import XMLObject as xmlo
import urllib
from ParentList import ParentList
from AddrElement import AddrElement


class SnatSet(ErrInfo):
    def __init__(self, httpBody=None):
        ErrInfo.__init__(self, httpBody)
        self.name = None
        self.ip_range = []      # ip地址范围，AddrElement类型
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
                httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)
            if self.xmlObj.hasTag("name"):
                self.name = urllib.unquote(
                    Configuration.base64decode(self.xmlObj["name"][0].getChildValue()))
            if self.xmlObj.hasTag('SnatSetType'):
                if self.xmlObj.hasTag("name"):
                    self.name = urllib.unquote(
                        Configuration.base64decode(self.xmlObj["name"][0].getChildValue()))
                if self.xmlObj.hasTag("ip_range"):
                    for ips in self.xmlObj["ip_range"]:
                        subXmlObj = xmlo.XMLObject(ips.toxml())
                        addr_type = None
                        info = None
                        if subXmlObj.hasTag('type'):
                            addr_type = subXmlObj['type'][0].getChildValue()
                        if subXmlObj.hasTag('info'):
                            info = subXmlObj['info'][0].getChildValue()
                        self.ip_range.append(AddrElement(info, 0, addr_type))
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)

    @classmethod
    def snatSetToXml(cls, snatSet):
        params = ''
        params += '<snat_set>'
        if snatSet.name is not None:
            params += '<name>' + base64.b64encode(snatSet.name) +'</name>'
        for ip in snatSet.ip_range:
            params += '<ip_range>'
            if ip.type is not None:
                params += '<type>' + ip.type + '</type>'
            if ip.ip is not None:
                params += '<info>' + ip.ip + '</info>'
            params += '</ip_range>'
        params += '</snat_set>'
        return params

    @classmethod
    def generatingSnatSetList(cls, httpBody) :
        return SnatSetList(httpBody)

    @classmethod
    def generatingSnatSet(cls, httpBody) :
        return SnatSet(httpBody)
        
class SnatSetList(ParentList):
    '''
    '''
    def __init__(self, httpBody = None):
        ParentList.__init__(self, httpBody)
        if httpBody is None or httpBody == "":
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)
            if self.xmlObj.hasTag("SnatSetListType"):
                if self.xmlObj.hasTag("snat_set"):
                    for snat in self.xmlObj["snat_set"]:
                        snatSet = SnatSet(snat.toxml())
                        self.elementList.append(snatSet)
                        self.length += 1
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)