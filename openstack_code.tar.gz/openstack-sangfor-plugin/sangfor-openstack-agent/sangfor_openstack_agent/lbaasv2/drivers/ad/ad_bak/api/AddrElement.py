﻿# -*- coding: utf-8 -*-
# Copyright (c) 2008-2016, AD SANGFOR, [Version 6.3.0]
# Filename: AddrElement.py


class AddrElement:
    ADDR_ONE = 'ADDR_ONE'
    ADDR_SCOPE = 'ADDR_SCOPE'
    ADDR_SUBNET = 'ADDR_SUBNET'
    '''
    IP类型
    '''
    def __init__(self, ip, info_id=1, addr_type=None):
        self.type = addr_type   # 地址类型
        self.ip = ip            # 网口ip(格式为:ip/mask, ip)
        self.info_id = info_id  # 集群时，此值为dev_id；非集群时为1
