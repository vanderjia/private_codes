import eventlet

eventlet.monkey_patch()
