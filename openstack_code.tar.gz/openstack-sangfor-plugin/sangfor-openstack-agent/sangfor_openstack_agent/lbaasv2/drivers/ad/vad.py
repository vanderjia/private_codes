#coding:utf-8
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad import MADAPI as MAD
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api import APIException as APIException
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api.ErrorInfo import ErrInfo
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api.VlanInfo import VlanInfo, VlanInfoList
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api.VxlanInfo import VxlanInfo, VxlanList
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api.VADInfo import VADInfo, VADInfoList
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api.ImageInfo import ImageInfo, ImageInfoList
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api.ServInfo import ServInfo, ServInfoList, PortInfo
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api.IPGroup import IPGroup, IPGroupList, IPInfo
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api.PersistInfo import PersistInfo, PersistList
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api.MonitorInfo import MonitorInfo, MonitorList
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api.NodeInfo import NodeInfo, NodeList
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api.PoolInfo import PoolInfo, PoolList
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api.VSInfo import VSInfo, VSList, VSStatus
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api.WanInfo import WanInfo, WanList
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api.AclInfo import AclInfo, AclList
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api.SnatSet import SnatSet, SnatSetList
from sangfor_openstack_agent.lbaasv2.drivers.ad.mad.api.AddrElement import AddrElement
from oslo_log import log as logging
from oslo_log import helpers as log_helpers

MADAPI=MAD.MADAPI

#会话保持默认超时时间 单位：秒
DEFAULT_TIMEOUT = 86400
#节点默认最大权值
DEFAULT_WEIGHT_MAX = 100
#连接限制最大值
DEFAULT_CONN_LIMIT = 2147483647

LOG = logging.getLogger(__name__)
class MADHOST(object):
    '''
    MAD主机操作类
    '''

    def __init__(self, username, password, host, port):
        self.mad = MADAPI(username, password,host, port)

    @log_helpers.log_method_call
    def createVlan(self, name, id, interface='eth1'):
        """创建vlan"""
        vlanInfo = VlanInfo()
        vlanInfo.name = name
        vlanInfo.ifname = interface
        vlanInfo.vlanId = id
        try:
            ret = self.mad.createVlan(vlanInfo)
            if ret.isFailed():
                # 创建失败时，查看一下vlan是否已经存在，存在则不抛异常
                vlan = self.mad.getVlanInfo(name)
                if vlan.isFailed() == False:
                    return
                raise Exception('createVlan failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def deleteVlan(self, name):
        '''
        删除vlan配置
        '''
        try:
            ret = self.mad.deleteVlan(name)
            if ret.isFailed():
                raise Exception('deleteVlan failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def updateVlan(self, oldname, name, id, interface='eth1'):
        '''
        更新vlan配置信息
        '''
        vlanInfo = VlanInfo()
        vlanInfo.name = name
        vlanInfo.ifname = interface
        vlanInfo.vlanId = id
        try:
            ret = self.mad.updateVlan(oldname, vlanInfo)
            if ret.isFailed():
                raise Exception('updateVlan failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def getVlaninfo(self, name):
        '''
        获取vlan配置信息
        '''
        vlan = {}
        try:
            vlanInfo = self.mad.getVlanInfo(name)
            vlan['name'] = vlanInfo.name
            vlan['vlanId'] = vlanInfo.vlanId
            vlan['ifname'] = vlanInfo.ifname
            vlan['device'] = vlanInfo.device
            if vlanInfo.isFailed():
                raise Exception('getVlaninfo failed[%d, %s]' % (vlanInfo.getErrCode(),
                                                              vlanInfo.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)
        return vlan

    @log_helpers.log_method_call
    def __buildVxlanInfo(self, name, id, remoteaddr, remoteport):
        vxlan = VxlanInfo()
        vxlan.name = name
        vxlan.vxlanId = id
        vxlan.remoteAddr = remoteaddr
        vxlan.remotePort = int(remoteport)
        vxlan.localAddr = ''  # openstack自动选择地址
        vxlan.localPort = 0
        vxlan.isGroup = 0     # openstack只使用单播
        return vxlan

    @log_helpers.log_method_call
    def createVxlan(self, name, id, remoteaddr=[], remoteport=4789):
        '''
        创建vxlan配置
        '''
        try:
            vxlan = self.__buildVxlanInfo(name, id, remoteaddr, remoteport)
            ret = self.mad.createVxlan(vxlan)
            if ret.isFailed():
                # 创建失败时，查看一下vxlan是否已经存在，存在则不抛异常
                vxlanInfo = self.mad.getVxlan(name)
                if vxlanInfo.isFailed() == False:
                    return
                raise Exception('createVxlan failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def deleteVxlan(self, name):
        '''
        删除vxlan配置
        '''
        try:
            ret = self.mad.deleteVxlan(name)
            if ret.isFailed():
                raise Exception('deleteVxlan failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def updateVxlan(self, oldname, name, id, remoteaddr=[], remoteport=4789):
        '''
        更新vxlan配置
        '''
        try:
            vxlan = self.__buildVxlanInfo(name, id, remoteaddr, remoteport)
            ret = self.mad.updateVxlan(oldname, vxlan)
            if ret.isFailed():
                raise Exception('updateVxlan failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def getVxlaninfo(self, name):
        '''
        获取vxlan配置信息
        '''
        vxlan = {}
        try:
            vxlanInfo = self.mad.getVxlan(name)
            vxlan['name'] = vxlanInfo.name
            vxlan['vxlanId'] = vxlanInfo.vxlanId
            vxlan['device'] = vxlanInfo.device
            vxlan['remoteAddr'] = vxlanInfo.remoteAddr
            vxlan['remotePort'] = vxlanInfo.remotePort
            vxlan['localPort'] = vxlanInfo.localPort
            if vxlanInfo.isFailed():
                raise Exception('getVxlaninfo failed[%d, %s]' % (vxlanInfo.getErrCode(),
                                                        vxlanInfo.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)
        return vxlan

    @log_helpers.log_method_call
    def getVADList(self):
        '''
        获取VAD配置信息列表
        '''
        vads = []
        try:
            vadList = self.mad.getVADInfoList()
            for vadInfo in vadList.elements:
                vad = {}
                vad['uuid'] = vadInfo.uuid
                vad['name'] = vadInfo.name
                vad['adVersion'] = vadInfo.adVersion
                vad['imageVer'] = vadInfo.imageVer
                vad['ip'] = vadInfo.ip
                vad['mask'] = vadInfo.mask
                vad['cpuCore'] = vadInfo.cpuCore
                vad['mem'] = vadInfo.mem
                vad['maxNewConn'] = vadInfo.maxNewConn
                vad['maxConn'] = vadInfo.maxConn
                vad['status'] = vadInfo.status
                vad['vlanSel'] = vadInfo.vlanSel
                vad['password']= ''
                vad['interface']=['eth0', '']
                kargs = {
                    'mad': self.mad,
                    'mirror': {'uuid': vad['adVersion']},
                    'ip': vad['ip'],
                    'mask': vad['mask'],
                    'password': vad['password'],
                    'interface': vad['interface'],
                    'bri_type': 'flat',
                    'bri_name': vad['vlanSel'][1], # 获取桥接口，非管理口
                    'vad': vad
                }
                vadobj = VAD(vad['name'], kargs)
                vads.append(vadobj)
            if vadList.isFailed():
                raise Exception('getVADList failed[%d, %s]' % (vadList.getErrCode(),
                                                              vadList.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)
        return vads

    @log_helpers.log_method_call
    def getVAD(self, vadname):
        '''
        获取VAD配置信息
        '''
        vad = {}
        try:
            vadInfo = self.mad.getVADInfo(vadname)
            vad['uuid'] = vadInfo.uuid
            vad['name'] = vadInfo.name
            vad['adVersion'] = vadInfo.adVersion
            vad['imageVer'] = vadInfo.imageVer
            vad['ip'] = vadInfo.ip
            vad['mask'] = vadInfo.mask
            vad['cpuCore'] = vadInfo.cpuCore
            vad['mem'] = vadInfo.mem
            vad['maxNewConn'] = vadInfo.maxNewConn
            vad['maxConn'] = vadInfo.maxConn
            vad['status'] = vadInfo.status
            vad['vlanSel'] = vadInfo.vlanSel
            vad['password'] = ''
            vad['interface']=['eth0', '']
            if vadInfo.isFailed():
                raise Exception('getVAD failed[%d, %s]' % (vadInfo.getErrCode(),
                                                              vadInfo.getErrStr()))
            kargs = {
                'mad': self.mad,
                'mirror': {'uuid': vad['adVersion']},
                'ip': vad['ip'],
                'mask': vad['mask'],
                'password': vad['password'],
                'interface': vad['interface'],
                'bri_type': 'flat',
                'bri_name': vad['vlanSel'][1], # 获取桥接口，非管理口
                'vad': vad
            }
            vadobj = VAD(vad['name'], kargs)
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)
        return vadobj

    @log_helpers.log_method_call
    def getmirrorList(self):
        '''
        获取VAD镜像列表
        '''
        imageList = []
        try:
            images = self.mad.getImageInfoList()
            for item in images.elements:
                image = {}
                image['version'] = item.version
                image['uuid'] = item.uuid
                imageList.append(image)
            if images.isFailed():
                raise Exception('getmirrorList failed[%d, %s]' % (images.getErrCode(),
                                                            images.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)
        return imageList

    def __getInterface(self, bri_type, bri_name):
        '''
        bri_type vxlan/vlan/flat
        1）为vxlan类型时，bri_name传的是vxlan的名称
        2）为vlan时，bri_name传的是vlan的名称
        3）为flat时，bri_name为实际的物理网口
        @return 返回物理网口列表
        '''
        # 桥接口
        device = None
        if bri_type == 'vlan':
            vlan = self.getVlaninfo(bri_name)
            device = vlan['device']
        elif bri_type == 'vxlan':
            vxlan = self.getVxlaninfo(bri_name)
            device = vxlan['device']
        else:
            device = bri_name
        return device

    @log_helpers.log_method_call
    def createVAD(self, name, kargs={}):
        '''
        创建一个VAD
        kargs  =  {
                    "mad":
                    "mirror":
                    "ip":
                    "mask":
                    "password":
                    "interface":  VAD网络接口列表
                    "bri_type": "vxlan"|"vlan"|"flat"
                    "bri_name":   桥接口名称
                    "vad":
                }
        '''
        if 'mirror' not in kargs or 'ip' not in kargs or 'mask' not in kargs or \
           'bri_type' not in kargs or 'bri_name' not in kargs or \
           'interface' not in kargs or 'mad' not in kargs:
            raise Exception('createVAD args error')
        # 转换网口名称为物理网口名称
        kargs['bri_name'] = self.__getInterface(kargs.get('bri_type'), kargs.get('bri_name'))
        # 网口名称已经转换，bri_type要赋值为flat，表示bri_name时物理网口
        kargs['bri_type'] = 'flat'
        vad = VAD(name, kargs)
        return vad

    @log_helpers.log_method_call
    def startVAD(self, vad):
        '''
        启动VAD
        '''
        try:
            ret = self.mad.startVAD(vad.name)
            if ret.isFailed():
                raise Exception('startVAD failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def stopVAD(self, vad):
        '''
        关闭VAD
        '''
        try:
            ret = self.mad.stopVAD(vad.name)
            if ret.isFailed():
                raise Exception('stopVAD failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def deleteVAD(self, vad):
        '''
        删除VAD
        '''
        try:
            ret = self.mad.deleteVAD(vad.name)
            if ret.isFailed():
                raise Exception('deleteVAD failed[%d, %s]' % (ret.getErrCode(), ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)


class VAD(object):
    '''
    VAD操作类
    '''

    @log_helpers.log_method_call
    def __init__(self, name, kargs={}):
        '''
        kargs  =  {
                    "mad":
                    "mirror":
                    "ip":
                    "mask":
                    "password":
                    "interface": VAD网络接口
                    "bri_type": "vxlan"|"vlan"|"flat"
                    "bri_name":
                    "vad":
                }
        '''
        #"默认中配"
        self.mad = kargs.get('mad')
        # vad名称
        self.name = name
        self.mirror = kargs.get('mirror')
        self.ip = kargs.get('ip')
        self.mask = kargs.get('mask')
        self.password = kargs.get('password', 'root1234')
        self.bri_type = kargs.get('bri_type')
        self.bri_name = kargs.get('bri_name')
        # 桥接口
        # 有两个元素，一个管理口，一个WAN口
        bri_interface = ['eth0']
        bri_interface.append(self.bri_name)
        # VAD网络接口，只有一个物理口
        # 只有单臂，只需要一个网口eth1
        self.ifname = 'eth1'
        # 如果vad为空，说明vad还没创建，需要创建
        vad = kargs.get('vad')
        if vad is None:
            self.create(self.mirror, self.ip, self.mask, self.password, bri_interface)

    def __configExist(self, code):
        if code == 105:
            return False
        else:
            return True

    def __buildServInfo(self, name, type="SRV_HTTP", port=[]):
        srv = ServInfo()
        srv.name = name
        # openstack TERMINATED_HTTPS/HTTPS/TCP 负载均认为TCP 负载
        # 原因openstack无法配置https卸载
        srv.type = type if type == 'SRV_HTTP' else 'SRV_TCP'
        for new_prot in port:
            portInfo = PortInfo()
            portInfo.fromPort = int(new_prot)
            srv.portInfo.append(portInfo)
        return srv


    @log_helpers.log_method_call
    def createServ(self, name, Stype="SRV_HTTP", port=[]):
        '''
        创建服务配置
        @name: 名字
        @type: 负载均衡的类型
        @port: 端口号数组
        @return:
        '''
        # 设置VAD身份标志
        self.mad.setVADAuthInfo(self.name)
        try:
            srv = self.__buildServInfo(name, Stype, port)
            ret = self.mad.createServInfo(srv)
            if ret.isFailed():
                raise Exception('createServ failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def updateServ(self, name, type="SRV_HTTP", port=[]):
        '''
        添加端口号
        @param name:
        @param type:
        @param port 端口列表, 注意：一次只能添加一个
        @return:
        '''
        # 设置VAD身份标志
        self.mad.setVADAuthInfo(self.name)
        try:
            srv = self.__buildServInfo(name, type, port)
            srv.type = None       # 更新不需要类型
            ret = self.mad.addServPort(srv)
            if ret.isFailed():
                raise Exception('updateServ failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def deleteServ(self, name):
        '''
        删除服务配置
        '''
        # 设置VAD身份标志
        self.mad.setVADAuthInfo(self.name)
        try:
            ret = self.mad.delServInfo(name)
            if ret.isFailed() and self.__configExist(ret.getErrCode()):
                raise Exception('deleteServ failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    def __buildGroupInfo(self, name, ipg=[]):
        ipgroup = IPGroup()
        ipgroup.name = name
        ipInfo = IPInfo()
        ipInfo.ipAddr = ipg
        ipgroup.ipgInfo.append(ipInfo)
        return ipgroup

    @log_helpers.log_method_call
    def createIPGroup(self, name, ip=[], args={}):
        '''
        构建AD ip组+ ip 配置块
        @param name:
        @param ip:  ip组数组
        @return:
        '''
        if 'wan' not in args:
            LOG.error("no wan name")
            raise Exception()
        # 设置VAD身份标志
        self.mad.setVADAuthInfo(self.name)
        try:
            # 先创建WAN口配置
            self.createWan(args['wan'], self.ifname, ip, args)
            # 再创建IP组
            ipgroup = self.__buildGroupInfo(name, ip)
            ret = self.mad.createIPGroup(ipgroup)
            if ret.isFailed():
                raise Exception('createIPGroup failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def updateIPGroup(self, name, ip=[]):
        '''
        添加ip组
        @param name:
        @param ip:
        @return:
        '''
        # 设置VAD身份标志
        LOG.error("CREATE")
        self.mad.setVADAuthInfo(self.name)
        try:
            ipgroup = self.__buildGroupInfo(name, ip)
            ret = self.mad.addIPInfo(ipgroup)
            if ret.isFailed():
                raise Exception('updateIPGroup failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def deleteIPGroup(self, name, args={}):
        '''
        删除IP组配置
        '''
        if 'wan' not in args or 'ip' not in args:
            LOG.error("no wan name or not ip")
            raise Exception()
        # 设置VAD身份标志
        self.mad.setVADAuthInfo(self.name)
        try:
            # 先删除IP组，再删除wan口IP
            # 删除IP组
            ret = self.mad.delIPGroup(name)
            if ret.isFailed() and self.__configExist(ret.getErrCode()):
                raise Exception('deleteIPGroup failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
            # 删除WAN口IP
            self.delWanIP(args['wan'], args['ip'])
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def IPGroupAddIP(self, ipgrpname="", ip=[]):
        '''
        往IP组内添加IP
        '''
        # 设置VAD身份标志
        self.mad.setVADAuthInfo(self.name)
        try:
            # 先添加Wan口IP
            self.addWanIP(ipgrpname, ip)
            # 添加IP组IP
            ipgroup = self.__buildGroupInfo(ipgrpname, ip)
            ret = self.mad.addIPInfo(ipgroup)
            if ret.isFailed():
                raise Exception('IPGroupAddIP failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def IPGroupDelIP(self, ipgrpname="", ip=[]):
        '''
        从IP组中删除IP
        '''
        # 设置VAD身份标志
        self.mad.setVADAuthInfo(self.name)
        try:
            # 先删除WAN口ip
            self.delWanIP(ipgrpname, ip)
            #在删除IP组IP
            ipgroup = self.__buildGroupInfo(ipgrpname, ip)
            ret = self.mad.delIPInfo(ipgroup)
            if ret.isFailed() and self.__configExist(ret.getErrCode()):
                raise Exception('IPGroupDelIP failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def __buildPersist(self, name, kargs={}):
        '''
        构建AD 会话保持配置块
        @param name:
        @param kargs:
        @return:
        '''
        persist = PersistInfo()
        persist.name = name
        persist.priorToConnect = kargs.get('priorToConnect', 'true')
        persist.type = kargs.get('type', 'PERSIST_SOURCE_IP')
        if persist.type is 'PERSIST_SOURCE_IP':
            persist.maskv4 = kargs.get('maskv4', '255.255.255.255')
            persist.maskv6 = kargs.get('maskv6', 'ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff')
            persist.sourceipTimeout = kargs.get('sourceipTimeout', DEFAULT_TIMEOUT)
        else:
            persist.cookieType = kargs.get('cookieType', 'PERSIST_COOKIE_INSERT')
            persist.cookieName = kargs.get('cookieName')
            persist.cookieDomain = kargs.get('cookieDomain', 'www.sangfor.com') # 次参数必填
            persist.cookiePath = kargs.get('cookiePath', '/')
            persist.cookieTimeout = kargs.get('cookieTimeout', DEFAULT_TIMEOUT)
        return persist

    @log_helpers.log_method_call
    def createPersist(self, name, kargs={}):
        '''
        创建会话保持
        '''
        # 设置VAD身份标志
        self.mad.setVADAuthInfo(self.name)
        try:
            persist = self.__buildPersist(name,kargs)
            ret = self.mad.createPersist(persist)
            if ret.isFailed():
                raise Exception('createPersist failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def deletePersist(self, name):
        '''
        删除会话保持
        '''
        # 设置VAD身份标志
        self.mad.setVADAuthInfo(self.name)
        try:
            ret = self.mad.delPersist(name)
            if ret.isFailed() and self.__configExist(ret.getErrCode()):
                raise Exception('deletePersist failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    def __buildMonitor(self, name, type='MONITOR_CONNECT_TCP', kargs={}):
        monitor = MonitorInfo()
        monitor.name = name
        monitor.type = type
        monitor.interval = kargs.get('interval', 5)
        monitor.timeout = kargs.get('timeout', 2)
        monitor.tryout = kargs.get('tryout', 3)
        monitor.debug = kargs.get('debug', 'true')
        monitor.addr = kargs.get('addr', '*')
        # MONITOR_ICMPV4/MONITOR_ICMPV6
        if monitor.type is 'MONITOR_ICMPV4' or \
           monitor.type is 'MONITOR_ICMPV6':
            monitor.isFirewall = kargs.get('isFirewall', 'false')
            return monitor
        # MONITOR_CONNECT_HTTP
        if monitor.type is 'MONITOR_CONNECT_HTTP':
            monitor.port = kargs.get('port', 80)
            if kargs.has_key('respCode'):
                for code in kargs.get('respCode'):
                    monitor.respCode.append(code)
            else:
                monitor.respCode = ['200', '302']
            monitor.urlMsg = kargs.get('urlMsg', '/')
            return monitor
        # MONITOR_CONNECT_TCP/MONITOR_CONNECT_UDP
        monitor.port = kargs.get('port', 0)
        monitor.maxRecvBuf = int(kargs.get('maxRecvBuf', 2048))
        monitor.sendMsg = kargs.get('sendMsg', 'sangfor')           #必填
        monitor.recvInclude = kargs.get('recvInclude', 'sangfor')   #必填
        monitor.closeSendMsg = kargs.get('closeSendMsg', 'sangfor') # 必填
        return monitor

    @log_helpers.log_method_call
    def createMonitor(self, name, type='MONITOR_CONNECT_TCP', kargs={}):
        '''
        新建监视器
        '''
        # 设置VAD身份标志
        self.mad.setVADAuthInfo(self.name)
        try:
            monitor = self.__buildMonitor(name, type, kargs)
            ret = self.mad.createMonitorInfo(monitor)
            if ret.isFailed():
                raise Exception('createMonitor failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def updateMonitor(self, name, type='MONITOR_CONNECT_TCP', kargs={}):
        '''
        更新监视器
        '''
        # 设置VAD身份标志
        self.mad.setVADAuthInfo(self.name)
        try:
            monitor = self.__buildMonitor(name, type, kargs)
            monitor.type = None # 更新时，不需要类型
            ret = self.mad.updateMonitorInfo(name, monitor)
            if ret.isFailed():
                raise Exception('updateMonitor failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def deleteMonitor(self, name):
        '''
        删除监视器
        '''
        # 设置VAD身份标志
        self.mad.setVADAuthInfo(self.name)
        try:
            ret = self.mad.delMonitorInfo(name)
            if ret.isFailed() and self.__configExist(ret.getErrCode()):
                raise Exception('deleteMonitor failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    def __buildPool(self, name, kargs={}):
        nodepool = PoolInfo()
        nodepool.name = name
        nodepool.monitors.append(kargs.get('monitor', 'ping'))
        nodepool.minMonitors = kargs.get('minMonitors', 0)
        nodepool.recoverInterval = kargs.get('recoverInterval', 0)
        nodepool.stepperInterval = kargs.get('stepperInterval', 0)
        nodepool.connStatAll = kargs.get('connStatAll', 'true')
        nodepool.persist1Name = kargs.get('persist1Name', 'none')
        nodepool.persist2Name = kargs.get('persist2Name', 'none')
        nodepool.schedMethod = kargs.get('schedMethod', 'SCHED_METHOD_FAIELD')
        if nodepool.schedMethod is 'SCHED_METHOD_QUEUE':
            nodepool.queueLength = kargs.get('queueLength', 100)
            nodepool.queueTimeout = kargs.get('queueTimeout', 5)
        nodepool.lbMethod = kargs.get('lbMethod', 'NODE_LB_RR')
        if nodepool.lbMethod is 'NODE_LB_HASH':
            nodepool.hashType = kargs.get('hashType', 'HASH_SRC_IP')
        return nodepool

    @log_helpers.log_method_call
    def createPool(self, name, kargs={}):
        '''
        新建节点池
        '''
        # 设置VAD身份标志
        self.mad.setVADAuthInfo(self.name)
        try:
            nodepool = self.__buildPool(name, kargs)
            ret = self.mad.createPoolInfo(nodepool)
            if ret.isFailed():
                raise Exception('createPool failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def updatePool(self, name, kargs={}):
        '''
        更新节点池
        '''
        # 设置VAD身份标志
        self.mad.setVADAuthInfo(self.name)
        try:
            nodepool = self.__buildPool(name, kargs)
            ret = self.mad.updatePoolInfo(name, nodepool)
            if ret.isFailed():
                raise Exception('updatePool failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def deletePool(self, name):
        '''
        删除节点池
        '''
        # 设置VAD身份标志
        self.mad.setVADAuthInfo(self.name)
        try:
            ret = self.mad.delPoolInfo(name)
            if ret.isFailed() and self.__configExist(ret.getErrCode()):
                raise Exception('deletePool failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    def __buildNode(self, name, ip="", port=80, kargs={}):
        '''
        构建AD 节点配置块
        @param name: 名字
        @param ip:  ip
        @param port:
        @param kargs:
        @return:  节点配置块
        '''
        node = NodeInfo()
        node.confStatus = 'NODE_ENABLE'
        # 节点权值校正
        node.ratio = int(kargs.get('ratio', 1))
        if node.ratio > DEFAULT_WEIGHT_MAX:
            node.ratio = DEFAULT_WEIGHT_MAX
            LOG.info("addriver member weight must be adjust ,"
                     "effective from 1 to DEFAULT_WEIGHT_MAX = 100 to ad")
        node.maxConnects = kargs.get('maxConnects', 0)
        node.newConnects = kargs.get('newConnects', 0)
        node.maxRequest = kargs.get('maxRequest', 0)
        node.nodeIP = ip
        node.nodePort = port
        return node

    @log_helpers.log_method_call
    def createMember(self, name, ip="", port=80, kargs={}):
        '''
        往节点池添加解决点
        '''
        # 设置VAD身份标志
        self.mad.setVADAuthInfo(self.name)
        try:
            node = self.__buildNode(name, ip, port, kargs)
            ret = self.mad.createNode(name, node)
            if ret.isFailed():
                raise Exception('createMember failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def deleteMember(self, name, ip="", port=80, kargs={}):
        '''
        删除节点池中的节点
        '''
        # 设置VAD身份标志
        self.mad.setVADAuthInfo(self.name)
        try:
            ret = self.mad.delNode(name, ip, port)
            if ret.isFailed() and self.__configExist(ret.getErrCode()):
                raise Exception('deleteMember failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def updateMemeber(self, name, ip="", port=80, kargs={}):
        '''
        更新节点信息
        '''
        # 设置VAD身份标志
        self.mad.setVADAuthInfo(self.name)
        try:
            node = self.__buildNode(name, ip, port, kargs)
            ret = self.mad.updateNode(name, ip, port, node)
            if ret.isFailed():
                raise Exception('updateMemeber failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def addPoolMonitor(self, poolname, monitorname):
        '''
        往节点池中添加监视器
        '''
        # 设置VAD身份标志
        self.mad.setVADAuthInfo(self.name)
        try:
            ret = self.mad.addMonitor(poolname, monitorname)
            if ret.isFailed():
                raise Exception('addPoolMonitor failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def delPoolMonitor(self, poolname, monitorname):
        '''
        删除节点池中的监视器
        '''
        # 设置VAD身份标志
        self.mad.setVADAuthInfo(self.name)
        try:
            ret = self.mad.delMonitor(poolname, monitorname)
            if ret.isFailed() and self.__configExist(ret.getErrCode()):
                raise Exception('delPoolMonitor failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    def __buildVS(self, name, kargs={}):
        '''
        构建AD 虚拟服务配置块
        @param name:
        @param kargs:
        @return:
        '''
        vs = VSInfo()
        vs.name = name
        vs.enable = kargs.get('enable', 'true')
        vs.ipgName = kargs.get('ipgName')           # 必填
        vs.serviceName = kargs.get('serviceName')   # 必填
        vs.poolName = kargs.get('poolName')         # 必填
        # 判断是否开启自动snat
        vs.autoSnat = kargs.get('autoSnat', 'true')
        # openstack HTTP  --> AD HTTP 7层负载
        # openstack HTTPS --> AD TCP 4层负载
        # openstack TCP   --> AD TCP 4层负载
        # openstack TERMINATED_HTTPS --> AD TCP 4层负载
        vs.mode = kargs.get('mode', 'VS_MODE_L4')
        if vs.mode is 'VS_MODE_L7':
            vs.httpSchedMode = kargs.get('httpSchedMode', 'HTTP_SCHED_MODE_EVERY_REQ') # 只用于7层VS
            vs.tcpCacheStream = kargs.get('tcpCacheStream', 'false') # 7层VS,服务为smtp/imap/pop时才填
            if vs.tcpCacheStream is 'true':
                vs.endStr = kargs.get('endStr', '/')
        if vs.mode is 'VS_MODE_L3':
            vs.serviceName = kargs.get('serviceName', 'layer3')
        vs.dnatEnable = kargs.get('dnatEnable', 'false')
        return vs

    def getPoolList(self):
        self.mad.setVADAuthInfo(self.name)
        return self.mad.getPoolList()

    @log_helpers.log_method_call
    def createVS(self, name, kargs={}):
        '''
        新建虚拟服务
        @param name:  虚拟服务名字
        @param kargs:  携带配置字典
        @return:
        '''
        # 设置VAD身份标志
        self.mad.setVADAuthInfo(self.name)
        try:
            vs = self.__buildVS(name, kargs)
            ret = self.mad.createVS(vs)
            if ret.isFailed():
                raise Exception('createVS failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    def __buildUpdateVS(self, kargs={}):
        vs = VSInfo()
        vs.enable = kargs.get('enable')
        vs.ipgName = kargs.get('ipgName')
        vs.serviceName = kargs.get('serviceName')
        vs.poolName = kargs.get('poolName')
        vs.autoSnat = kargs.get('autoSnat')
        vs.httpSchedMode = kargs.get('httpSchedMode')
        vs.tcpCacheStream = kargs.get('tcpCacheStream')
        vs.endStr = kargs.get('endStr')
        vs.dnatEnable = kargs.get('dnatEnable')
        return vs
    @log_helpers.log_method_call
    def updateVS(self, name, kargs={}):
        '''
        更新虚拟服务
        @param name:  虚拟服务名字
        @param kargs:
        @return:
        '''
        # 设置VAD身份标志
        self.mad.setVADAuthInfo(self.name)
        try:
            vs = self.__buildUpdateVS(kargs)
            ret = self.mad.updateVS(name, vs)
            if ret.isFailed():
                raise Exception('updateVS failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def deleteVS(self, name):
        '''
        删除虚拟服务
        '''
        # 设置VAD身份标志
        self.mad.setVADAuthInfo(self.name)
        try:
            ret = self.mad.delVS(name)
            if ret.isFailed() and self.__configExist(ret.getErrCode()):
                raise Exception('deleteVS failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    def __buildACL(self, name, kargs={}):
        '''
        构建AD 高级acl配置块
        @param name:
        @param kargs:
        @return:
        '''
        acl = AclInfo()
        acl.name = name
        acl.vsname = kargs.get('vsname')
        acl.enable = kargs.get('enable', 'true')
        acl.type = kargs.get('type', 'ADDR_ALL')
        acl.info = kargs.get('info')
        acl.connectLimit = kargs.get('connectLimit', 2000)
        return acl

    @log_helpers.log_method_call
    def createACL(self, name, kargs):
        '''
        创建高级ACL
        '''
        # 设置VAD身份标志
        self.mad.setVADAuthInfo(self.name)
        try:
            acl = self.__buildACL(name, kargs)
            ret = self.mad.createAcl(acl)
            if ret.isFailed():
                raise Exception('createACL failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def updateACL(self, name, kargs={}):
        '''
        更新高级ACL
        '''
        # 设置VAD身份标志
        self.mad.setVADAuthInfo(self.name)
        try:
            acl = self.__buildACL(name, kargs)
            ret = self.mad.updateAcl(acl)
            if ret.isFailed():
                raise Exception('updateACL failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def deleteACL(self, name):
        '''
        删除高级ACL
        '''
        # 设置VAD身份标志
        self.mad.setVADAuthInfo(self.name)
        try:
            ret = self.mad.deleteAcl(name)
            if ret.isFailed() and self.__configExist(ret.getErrCode()):
                raise Exception('deleteACL failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    def __buildWan(self, name, ifname, ips=[], args={}):
        wan = WanInfo()
        wan.name = name
        wan.ifname = ifname
        wan.enable = 'true'
        for item in ips:
            ip = item + '/' + str(args.get('mask', 22))
            wan.ip.append(AddrElement(ip))
        wan.gwAddr.append(AddrElement(args.get('gatewayIP')))
        wan.maxUpBandwidth = 10000
        wan.maxDownBandwidth = 10000
        wan.upBusyRate = 80
        wan.downBusyRate = 80
        wan.enableDetect = 'false'
        wan.enableNicCheck = 'false'
        return wan

    def __addIPWithName(self, name, ips=[]):
        '''
        当存在WAN口配置时，只需要往网口中添加IP
        @return True: 网口存在，False：网口不存在
        '''
        wan = self.mad.getWanInfo(name)
        if wan.isFailed() and self.__configExist(wan.getErrCode()) == False:
            return False
        # 网口肯定会有ip
        mask = wan.ip[0].ip.split('/')[1]
        wanInfo = WanInfo()
        wanInfo.ip = wan.ip
        for item in ips:
            ip = item + '/' + str(mask)
            wanInfo.ip.append(AddrElement(ip))
        self.mad.updateWanInfo(name, wanInfo)
        return True


    @log_helpers.log_method_call
    def createWan(self, name, ifname, ips=[], args={}):
        '''
        创建wan口
        '''
        # 设置VAD身份标志
        self.mad.setVADAuthInfo(self.name)
        try:
            # 如果网口存在则直接添加IP
            if self.__addIPWithName(name, ips):
                return
            # 网口不存在，需要创建
            wan = self.__buildWan(name, ifname, ips, args)
            ret = self.mad.createWanInfo(wan)
            if ret.isFailed():
                raise Exception('createWan failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    def __addIP(self, name, ips=[]):
        wan = self.mad.getWanInfo(name)
        if wan.isFailed() and self.__configExist(wan.getErrCode()):
            raise Exception('getWanInfo failed[%d, %s]' % (wan.getErrCode(),
                                                          wan.getErrStr()))
        # 网口肯定会有ip
        mask = wan.ip[0].ip.split('/')[1]
        wanInfo = WanInfo()
        wanInfo.ip = wan.ip
        for item in ips:
            ip = item + '/' + str(mask)
            wanInfo.ip.append(AddrElement(ip))
        return wanInfo

    @log_helpers.log_method_call
    def addWanIP(self, name, ips=[]):
        '''
        添加WAN口IP
        '''
        try:
            # 先获取WAN口IP
            wan = self.__addIP(name, ips)
            self.mad.updateWanInfo(name, wan)
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    def __findIP(self, ip, ips=[]):
        for item in ips:
            if item == ip:
                return True
        return False

    def __delIP(self, name, ips=[]):
        wan = self.mad.getWanInfo(name)
        if wan.isFailed() and self.__configExist(wan.getErrCode()):
            raise Exception('getWanInfo failed[%d, %s]' % (wan.getErrCode(),
                                                          wan.getErrStr()))
        # 网口肯定会有ip
        mask = wan.ip[0].ip.split('/')[1]
        wanInfo = WanInfo()
        # 过滤掉要删除的ip
        for item in wan.ip:
            if self.__findIP(item.ip.split('/')[0], ips) == False:
                wanInfo.ip.append(item)
        return wanInfo

    @log_helpers.log_method_call
    def delWanIP(self, name, ips=[]):
        '''
        删除WAN口IP
        '''
        try:
            # 先获取WAN口IP
            wan = self.__delIP(name, ips)
            self.mad.updateWanInfo(name, wan)
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    @log_helpers.log_method_call
    def resetConfig(self):
        '''
        清除VAD上配置
        '''
        # 设置VAD身份标志
        self.mad.setVADAuthInfo(self.name)
        try:
            self.mad.resetVADConfig()
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    def create(self, mirror, ip, mask, password, interface=[]):
        '''
        创建中配VAD
        '''
        vadInfo = VADInfo()
        vadInfo.name = self.name
        vadInfo.adVersion = mirror['uuid']
        vadInfo.gateway = ''
        vadInfo.ip = ip
        vadInfo.mask = int(mask)
        vadInfo.passwd = password
        vadInfo.cpuCore = 4        # 默认四核
        vadInfo.cpuNum = 0
        vadInfo.mem = 2000         # 默认2G
        vadInfo.maxNewConn = 3000
        vadInfo.maxConn = 30000
        vadInfo.resType = 1        # 中配
        for ifname in interface:
            vadInfo.vlanSel.append(ifname)
        try:
            ret = self.mad.createVAD(vadInfo)
            if ret.isFailed():
                raise Exception('creatVAD failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    def start(self):
        '''
        启动VAD
        '''
        try:
            ret = self.mad.startVAD(self.name)
            if ret.isFailed():
                raise Exception('startVAD failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    def stop(self):
        '''
        关闭VAD
        '''
        try:
            ret = self.mad.closeVAD(self.name)
            if ret.isFailed():
                raise Exception('stopVAD failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    def delete(self):
        '''
        删除VAD
        '''
        try:
            ret = self.mad.deleteVAD(self.name)
            if ret.isFailed():
                raise Exception('deleteVAD failed[%d, %s]' % (ret.getErrCode(),
                                                              ret.getErrStr()))
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)

    def started(self):
        '''
        VAD是否启动
        '''
        try:
            vadInfo = self.mad.getVADInfo(self.name)
            if vadInfo.status == 'running':
                return True
            else:
                return False
        except Exception as e:
            LOG.error("Exception: %s" % e.message)
            raise Exception(e)
