# -*- coding: utf-8 -*-
# Copyright (c) 2008-2016, AD SANGFOR, [Version 6.3.0]
# Filename: StaticRoute.py

from ErrorInfo import ErrInfo
from urllib2 import base64
import XMLObject as xmlo
from APIException import APIException
from xml.dom import minidom
import urllib
from Configuration import Configuration
from ParentList import ParentList

class StaticRouteInfo (ErrInfo) :
    def __init__(self, httpBody = None) :
        self.net = None     #网络号
        self.mask = -1      #掩码
        self.gw_addr = None #网关ip
        self.dev_id = 0     #生效设备，默认都生效
        self.netns_id = -1  #对应netns id
        ErrInfo.__init__(self, httpBody)
        if httpBody == "" or httpBody == None :
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0 :
            return
        if not isinstance(httpBody, unicode) :
                httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)
            xmlChildObj = None
            if self.xmlObj.hasTag("net") :
                xmlChildObj = self.xmlObj["net"][0]
                self.net = xmlChildObj.getChildValue()
            if self.xmlObj.hasTag("mask") :
                xmlChildObj = self.xmlObj["mask"][0]
                self.mask = xmlChildObj.getChildValue()
            if self.xmlObj.hasTag("netns_id") :
                xmlChildObj = self.xmlObj["netns_id"][0]
                self.netns_id = xmlChildObj.getChildValue()
            #gw配置
            if self.xmlObj.hasTag("dev_gw") :
                xmlChildObj = self.xmlObj["dev_gw"][0]
                if xmlChildObj.hasTag('dev_id'):
                    self.dev_id = xmlChildObj.getChildObj('dev_id')[0].getChildValue()
                if xmlChildObj.hasTag('gw_addr'):
                    self.gw_addr = xmlChildObj.getChildObj('gw_addr')[0].getChildValue()
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)
    def __str__(self) :
        return self.originStr

    @classmethod
    def devGwtoxml(cls, route) : 
        params = ""
        if route.dev_id != -1 :
            params += "<dev_id>" + str(route.dev_id) + "</dev_id>\n"
        if route.gw_addr != None :
            params += "<gw_addr>" + route.gw_addr + "</gw_addr>\n"
        return params

    @classmethod
    def make_xml_data(cls, route) : 
        params = "<static_route_info>\n"
        if route.net != None :
            params += "<net>" + route.net + "</net>\n"
        if route.mask != None :
            params += "<mask>" + str(route.mask) + "</mask>\n"
        if route.netns_id != None :
            params += "<netns_id>" + str(route.netns_id) + "</netns_id>\n"
        dev_gw = StaticRouteInfo.devGwtoxml(route)
        if dev_gw != "":
            params += "<dev_gw>\n" + dev_gw + "</dev_gw>\n"
        params += "</static_route_info>\n"
        return params
    @classmethod
    def generatingpersistList(cls, httpBody) :
        return PersistList(httpBody)
    @classmethod
    def generatingRouteInfo(cls, httpBody) :
        return StaticRouteInfo(httpBody)

