# -*- coding: utf-8 -*-
# Copyright (c) 2008-2016, AD SANGFOR, [Version 6.3.0]
# Filename: NetnsInfo.py

from Configuration import Configuration
from APIException import APIException
from ErrorInfo import ErrInfo
from urllib2 import base64
import XMLObject as xmlo
import urllib
from ParentList import ParentList
from AddrElement import AddrElement


class NetnsInfo (ErrInfo) :
    def __init__(self, httpBody = None) :
        ErrInfo.__init__(self, httpBody)
        self.name = None
        self.enable = None
        self.tenant = None
        self.appg_id = 0
        self.netns_id = 0
        if httpBody == "" or httpBody == None :
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0 :
            return
        if not isinstance(httpBody, unicode) :
                httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)
            if self.xmlObj.hasTag("name") :
                self.name = urllib.unquote(Configuration.base64decode(self.xmlObj["name"][0].getChildValue()))
            if self.xmlObj.hasTag("tenant") :
                self.tenant = urllib.unquote(Configuration.base64decode(self.xmlObj['tenant'][0].getChildValue()))
            if self.xmlObj.hasTag("enable") :
                self.enable = self.xmlObj['enable'][0].getChildValue()
            if self.xmlObj.hasTag("netns_id") :
                self.netns_id = self.xmlObj['netns_id'][0].getChildValue()
            if self.xmlObj.hasTag("appg_id") :
                self.appg_id = self.xmlObj['appg_id'][0].getChildValue()
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)

    def __str__(self) :
        return self.originStr

    @classmethod
    def netnsInfoToXml(cls, netnsInfo):
        '''
        拼接发送信息
        '''
        params = ''
        if netnsInfo is not None:
            params += '<netns_info>'
            if netnsInfo.name is not None:
                params += '<name>' + base64.b64encode(netnsInfo.name) + '</name>'
            if netnsInfo.enable is not None:
                params += '<enable>' + netnsInfo.enable + '</enable>'
            if netnsInfo.tenant is not None:
                params += '<tenant>' + base64.b64encode(netnsInfo.tenant) + '</tenant>'
            if netnsInfo.appg_id is not None:
                params += '<appg_id>' + str(netnsInfo.appg_id) + '</appg_id>'
            params += '</netns_info>'
        return params

    @classmethod
    def generatingNetnsInfo(cls, httpBody) :
        return NetnsInfo(httpBody)

