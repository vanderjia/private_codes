# -*- coding: utf-8 -*-
# Copyright (c) 2008-2016, AD SANGFOR, [Version 6.3.0]
# Filename: REST_ADAPI.py

# 定义了 ADAPI PYTHON SDK 对外的接口
#from http import HttpClient

import urllib
from httplib import InvalidURL
from api.Configuration import Configuration
from api.APIException import APIException
from api.http.HttpClient import HttpClient, RequestMethod, HttpClientException
from urllib2 import base64
import api.http.HttpClient
from api.RespondXml import Nodes
from api.Ipgroup import IpgroupInfo
from api.Servconfig import ServInfo
from api.Persist import PersistInfo
from api.Monitor import MonitorInfo
from api.NodeInfoV2 import NodeInfoV2
from api.NodePoolV2 import NodePoolV2
from api.VsInfo import VsInfo
from api.WanInfo import WanInfo
from api.VlanInfo import VlanInfo
from api.NetnsInfo import NetnsInfo
from api.MacvlanInfo import MacvlanInfo
from api.LanInfo import LanInfo
from api.SysStatus import SysInfo
from api.AclInfo import AclInfo
from api.MySQLProfile import MySQLProfileInfo
from api.SnatSet import SnatSet
from api.LogInfo import LogInfo

class REST_ADAPI :
    '''
    包含 ADAPI PYTHON SDK 对外的接口
    '''
    def __init__(self, username, password, ip, port, timeout=20) :
        '''
        初始化类
        @username ： 用户名称
        @password ： 用户密码
        @ip       ： 设备IP
        @port     ： 设备端口
        @timeout  :  超时时间设置
        @return
        '''
        config = Configuration(username, password, ip, port, timeout)
        self.config = config
        self.ad_auth = "<ad_auth>\n"
        self.ad_auth += "<username>" + self.config.username + "</username>\n"
        self.ad_auth += "<passwd>" + self.config.password + "</passwd>\n"
        self.ad_auth += "</ad_auth>\n"
        self.authStr = "username=" + urllib.quote_plus(self.config.username)   \
                     + "&passwd=" + urllib.quote_plus(self.config.password)
    '''
    获取ADAPI的版本信息
    '''
    @classmethod
    def getVersion(cls) :
        import __init__
        return __init__.__version__
    def setConfig(self, configuration = None) :
        '''
        用于初始化ADAPI SDK所需信息。包括AD IP、AD端口(若为None，默认设置为443)、用户名、密码
        @param configuration 初始化信息类。
        @type Configuration
        @return
        @rtype
        '''
        self.config = configuration
        self.ad_auth = "<ad_auth>\n"
        self.ad_auth += "<username>" + self.config.username + "</username>\n"
        self.ad_auth += "<passwd>" + self.config.password + "</passwd>\n"
        self.ad_auth += "</ad_auth>\n"
        self.authStr = "username=" + urllib.quote_plus(self.config.username)   \
                     + "&passwd=" + urllib.quote_plus(self.config.password)
    def makeResult(self, httpBody):
        try:
            node = Nodes(httpBody)
            result = {'error_status':'', 'err_code':'', 'err_info':''}
            result['error_status'] = str(api.http.HttpClient.error_status)
            result['err_code'] = node.getErrCode() 
            result['err_info'] =  node.getErrStr()
            LogInfo.makeLogger('makeResult [--]' + str(result['error_status']) + ',' + str(result['err_code']) + ',' + result['err_info'])    
            return result
        except APIException ,e:
            LogInfo.makeLogger('makeResult [--]' + str(e.code) + ',' + e.reason)
            raise APIException(e.code, e.reason)
        except Exception, e:
            raise Exception(e)
    def DefaultHttpRequestRetryHandler(self, url, params, requestMethod, flag="post"):
        '''
        用于发送数据并且接收数据
        @url 发送链接
        @params 发送的数据
        @requestMethod 请求方式
        @flag 用于标记是get请求还是post请求
        @rtype
        '''
        #HttpClient.setTimeout(self.config.timeout)
        httpBody = None
        try:
            httpBody =  HttpClient.httpClientRestFul(url,params, self.config.ip, self.config.port, "HTTPS",requestMethod)
            LogInfo.makeLogger("DefaultHttpRequestRetryHandler_httpBody [--]: " + httpBody)
            if httpBody == None :
                raise APIException(4, "unknown error")
            if flag == "post":
                result = self.makeResult(httpBody)
                return result
            else:
                return httpBody
        except (HttpClientException, APIException) as e:
            code = e.code#http-code
            reason = str(e.reason)#body
            LogInfo.makeLogger('DefaultHttpRequestRetryHandler [--]' + str(code) + ' ' + reason)
            if str(api.http.HttpClient.error_status) == "500":#500
                LogInfo.makeLogger("enter default 500 error")
                result = self.makeResult(reason)
                LogInfo.makeLogger("Default500 [--]" + str(result['err_code']) + "," + result['err_info'])
                if result['err_code'] == "":
                    result['err_code'] = e.code
                raise APIException(result['err_code'], result['err_info'])
            else:
                LogInfo.makeLogger("Default : [--]" + str(code) + "," + reason)
                raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def make_Params(self, data):
        '''
        用于组合数据
        @data 每个接口不同的数据
        @rtype
        '''
        params = '<?xml version="1.0" encoding="UTF-8"?>\n' + data              \
                   + self.ad_auth 
        return params
    def createIpGroup(self, ipgname, ipg=None):
        '''
        创建IP组
        @param ipgname 要创建IP组的名字
        @ipg  要创建服务的信息 
        @type str, IpgroupInfo
        '''
        requestMethod = RequestMethod.POST
        data = '<ip_group_info>\n'
        data += '<name>' + base64.b64encode(ipgname) + '</name>\n'
        try:
            data += IpgroupInfo.make_xml_data(ipg)
            data += '</ip_group_info>\n'
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.createIpGroupURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("createIpGroup : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def getIpGroupList(self):
        '''
        获取list列表
        '''
        requestMethod = RequestMethod.GET
        params = self.authStr
        try :
            httpBody = self.DefaultHttpRequestRetryHandler(self.config.getIpGroupListURI,params,requestMethod,'get')
            if httpBody == None :
                raise APIException(4, "unknown error")
            LogInfo.makeLogger("getIpGroupList_httpBody : " + httpBody)
            ipgNodeList = IpgroupInfo.generatingipgList(httpBody)
            return ipgNodeList
        except (HttpClientException, APIException) as e:
            reason = str(e.reason)
            LogInfo.makeLogger("getIpGroupList : " + str(e.code) + ',' + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def getIpGroupInfo(self, ipgname):
        '''
        获取IP组具体节点信息
        @param ipgname ip组的名字
        @type str
        '''
        requestMethod = RequestMethod.GET
        params = 'name=' + urllib.quote_plus(ipgname) + '&' + self.authStr
        try :
            httpBody = self.DefaultHttpRequestRetryHandler(self.config.getIpGroupInfoURI,params,requestMethod,'get')
            if httpBody == None :
                raise APIException(4, "unknown error")
            LogInfo.makeLogger("getIpGroupInfo_httpBody : " + httpBody)
            ipgNodeInfo = IpgroupInfo.generatingipgInfo(httpBody)
            return ipgNodeInfo
        except (HttpClientException, APIException) as e:
            reason = str(e.reason)
            LogInfo.makeLogger("getIpGroupInfo : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def delIpGroup(self, ipgname):
        '''
        删除IP组信息
        @param ipgname ip组名称
        @type str
        '''
        requestMethod = RequestMethod.POST
        try:
            data = '<ip_group_name>' + base64.b64encode(ipgname) + '</ip_group_name>'
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.delIpGroupURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("delIpGroup : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def addIp(self, ipgname, ipg):
        '''
        添加Ip组IP
        @param ipgname ip组名称
        @ipg 数据， 
        @type str, Ipgroup
        '''
        requestMethod = RequestMethod.POST
        try:
            data = '<ip_group_name>' + base64.b64encode(ipgname) + '</ip_group_name>'
            data += IpgroupInfo.make_xml_data(ipg)
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.addIpURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("addIp : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def delIp(self, ipgname, ipg):
        '''
        删除Ip组IP
        @param ipgname ip组名称
        @ipg 数据，
        @type str,Ipgroup
        '''
        requestMethod = RequestMethod.POST
        try:
            data = '<ip_group_name>' + base64.b64encode(ipgname) + '</ip_group_name>'
            data += IpgroupInfo.make_xml_data(ipg)
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.delIpURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("delIp : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def createServ(self, server):
        '''
        创建服务
        @param server 要创建服务的信息
        @type ServInfo
        '''
        requestMethod = RequestMethod.POST
        try:
            data = ServInfo.make_xml_data(server,'create')
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.createServURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("createServ : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def getServList(self):
        '''
        获取list列表
        '''
        requestMethod = RequestMethod.GET
        params = self.authStr
        try :
            httpBody = self.DefaultHttpRequestRetryHandler(self.config.getServListURI,params,requestMethod,'get')
            if httpBody == None :
                raise APIException(4, "unknown error")
            LogInfo.makeLogger("getServList_httpBody : " + httpBody)
            srvNodeList = ServInfo.generatingsrvList(httpBody)
            return srvNodeList
        except (HttpClientException, APIException) as e:
            reason = str(e.reason)
            LogInfo.makeLogger("getServList : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def getServInfo(self, servername):
        '''
        获取list列表
        @param servername 服务的name
        @type str
        '''
        requestMethod = RequestMethod.GET
        params = 'name=' + urllib.quote_plus(servername) + '&' + self.authStr
        try :
            httpBody = self.DefaultHttpRequestRetryHandler(self.config.getServInfoURI,params,requestMethod,'get')
            if httpBody == None :
                raise APIException(4, "unknown error")
            LogInfo.makeLogger("getServInfo_httpBody : " + httpBody)
            srvNodeInfo = ServInfo.generatingsrvInfo(httpBody)
            return srvNodeInfo
        except (HttpClientException, APIException) as e:
            reason = str(e.reason)
            LogInfo.makeLogger("getServInfo : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def delServ(self, servname):
        '''
        删除服务
        @param servname 要创建服务名称
        @type str
        '''
        requestMethod = RequestMethod.POST
        try:
            data = '<server_name>' + base64.b64encode(servname) + '</server_name>'
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.delServURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("delServ : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def addServPort(self, server):
        '''
        添加服务端口
        @param server 要添加服务的信息
        @type ServInfo
        '''
        requestMethod = RequestMethod.POST
        try:
            data = ServInfo.make_xml_data(server,"addport")
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.addServPortURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("addServPort : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def delServPort(self, server):
        '''
        删除服务端口
        @param server 要删除服务的信息
        @type ServInfo
        '''
        requestMethod = RequestMethod.POST
        try:
            data = ServInfo.make_xml_data(server,"delport")
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.delServPortURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("delServPort : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def createPersist(self, persist):
        '''
        创建会话保持
        @param persist 待创建的会话保持信息
        @type PersistInfo
        '''
        requestMethod = RequestMethod.POST
        try:
            data = PersistInfo.make_xml_data(persist)
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.createPersistURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("createPersist : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def getPersistList(self):
        '''
        获取list列表
        '''
        requestMethod = RequestMethod.GET
        params = self.authStr
        try :
            httpBody = self.DefaultHttpRequestRetryHandler(self.config.getPersistListURI,params,requestMethod,'get')
            if httpBody == None :
                raise APIException(4, "unknown error")
            LogInfo.makeLogger("getPersistList_httpBody : " + httpBody)
            persistNodeList = PersistInfo.generatingpersistList(httpBody)
            return persistNodeList
        except (HttpClientException, APIException) as e:
            reason = str(e.reason)
            LogInfo.makeLogger("getPersistList : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def getPersistInfo(self, persistname):
        '''
        获取会话保持具体信息
        @param persistname 会话保持name
        @type str
        '''
        requestMethod = RequestMethod.GET
        params = 'name=' + urllib.quote_plus(persistname) + '&' + self.authStr
        try :
            httpBody = self.DefaultHttpRequestRetryHandler(self.config.getPersistInfoURI,params,requestMethod,'get')
            if httpBody == None :
                raise APIException(4, "unknown error")
            LogInfo.makeLogger("getPersistInfo_httpBody : " + httpBody)
            persistNodeInfo = PersistInfo.generatingpersistInfo(httpBody)
            return persistNodeInfo
        except (HttpClientException, APIException) as e:
            reason = str(e.reason)
            LogInfo.makeLogger("getPersistInfo : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def delPersist(self, persistname):
        '''
        删除会话保持
        @param persistname 待删除的节点的名称
        @type str
        '''
        requestMethod = RequestMethod.POST
        try:
            data = '<persist_name>' + base64.b64encode(persistname) + '</persist_name>'
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.delPersistURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("delPersist : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def updatePersist(self,persistname,persist):
        '''
        更新会话保持
        @param persistname 待更新的会话保持名称
        @param persist 待更新的会话保持
        @type str, PersistInfo
        '''
        requestMethod = RequestMethod.POST
        try:
            data = "<persist_name>" + base64.b64encode(persistname) + "</persist_name>\n"
            data += PersistInfo.make_xml_data(persist)
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.updatePersistURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("updatePersist : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def createNodeMonitor(self,monitor):
        '''
        创建节点监视器
        @param monitor 待创建的节点监视器信息
        @type MonitorInfo
        '''
        requestMethod = RequestMethod.POST
        try:
            data = MonitorInfo.make_xml_data(monitor)
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.createNodeMonitorURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("createNodeMonitor : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def getNodeMonitorList(self):
        '''
        获取借点监视器list列表
        '''
        requestMethod = RequestMethod.GET
        params = self.authStr
        try :
            httpBody = self.DefaultHttpRequestRetryHandler(self.config.getMonitorListURI,params,requestMethod,'get')
            if httpBody == None :
                raise APIException(4, "unknown error")
            LogInfo.makeLogger("getNodeMonitorList_httpBody : " + httpBody)
            monitorNodeList = MonitorInfo.generatingmonitorList(httpBody)
            return monitorNodeList
        except (HttpClientException, APIException) as e:
            reason = str(e.reason)
            LogInfo.makeLogger("getNodeMonitorList : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def getNodeMonitorInfo(self, monitorname):
        '''
        获取节点监视器信息
        @param monitorname 节点监视器名称
        @type str
        '''
        requestMethod = RequestMethod.GET
        params = 'name=' + urllib.quote_plus(monitorname) + '&' + self.authStr
        try :
            httpBody = self.DefaultHttpRequestRetryHandler(self.config.getMonitorInfoURI,params,requestMethod,'get')
            if httpBody == None :
                raise APIException(4, "unknown error")
            LogInfo.makeLogger("getNodeMonitorInfo_httpBody : " + httpBody)
            monitorNodeInfo = MonitorInfo.generatingmonitorInfo(httpBody)
            return monitorNodeInfo
        except (HttpClientException, APIException) as e:
            reason = str(e.reason)
            LogInfo.makeLogger("getNodeMonitorInfo : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def delNodeMonitor(self, monitorname):
        '''
        删除节点监视器
        @param monitorname 待删除的节点池名称
        @type str
        '''
        requestMethod = RequestMethod.POST
        try:
            data = '<monitor_name>' + base64.b64encode(monitorname) + '</monitor_name>'
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.delMonitorURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("delNodeMonitor : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def updateNodeMonitor(self,monitorname,monitor):
        '''
        更新节点监视器
        @param monitorname 待更新的节点池名称
        @param monitor 待更新的节点监视器信息
        @type str,MonitorInfo
        '''
        requestMethod = RequestMethod.POST
        try:
            data = "<monitor_name>" + base64.b64encode(monitorname) + "</monitor_name>\n"
            data += MonitorInfo.make_xml_data(monitor)
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.updateNodeMonitorURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("updateNodeMonitor : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def createNodePool(self, pool):
        '''
        创建节点池
        @param pool 待创建的节点池
        @type NodePoolV2
        '''
        requestMethod = RequestMethod.POST
        try:
            data = NodePoolV2.poolinfoToXml(pool)
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.createNodePoolURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("createNodePool : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def delNodePool(self, poolname):
        '''
        删除节点池
        @param poolname 待删除的节点池名称
        @type str
        '''
        requestMethod = RequestMethod.POST
        poolname =  base64.b64encode(poolname)  
        try:
            data = '<node_pool_name>' + poolname + '</node_pool_name>'
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.delNodePoolURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("delNodePool : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def getNodePoolListV2(self) :
        '''
        获取节点池列表
        @return PoolList
        '''
        requestMethod = RequestMethod.GET
        params = self.authStr
        try :
            httpBody = self.DefaultHttpRequestRetryHandler(self.config.getNodePoolListV2URI,params,requestMethod,'get')
            if httpBody == None :
                raise APIException(4, "unknown error")
            LogInfo.makeLogger("getNodePoolListV2_httpBody : " + httpBody)
            nodepoolList = NodePoolV2.generatingPoolList(httpBody)
            return nodepoolList
        except (HttpClientException, APIException) as e:
            reason = str(e.reason)
            LogInfo.makeLogger("getNodePoolListV2 : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def getNodePoolInfoV2(self, nodePoolName) :
        '''
        获取节点池列表
        @nodePoolName 节电池名称
        @return PoolList
        @rtype str
        '''
        requestMethod = RequestMethod.GET
        params = 'name=' + urllib.quote_plus(nodePoolName) + '&' + self.authStr
        try :
            httpBody = self.DefaultHttpRequestRetryHandler(self.config.getNodePoolInfoURI,params,requestMethod,'get')
            if httpBody == None :
                raise APIException(4, "unknown error")
            LogInfo.makeLogger("getNodePoolInfoV2_httpBody : " + httpBody)
            nodepoolInfo = NodePoolV2.generatingPoolInfo(httpBody)
            return nodepoolInfo
        except (HttpClientException, APIException) as e:
            reason = str(e.reason)
            LogInfo.makeLogger("getNodePoolInfoV2 : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def updateNodePool(self, poolname, pool) :
        '''
        更新节点池
        @param poolname 待更新的节点池名称
        @param pool 待更新的节点池
        @type str,NodePoolV2
        '''
        requestMethod = RequestMethod.POST
        try :
            data = "<node_pool_name>" + base64.b64encode(poolname) + "</node_pool_name>\n"
            data += NodePoolV2.poolinfoToXml(pool)
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.updateNodePoolURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("updateNodePool : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def createNodeV2(self, poolname, node) :
        '''
        创建新节点
        @param poolname 节点池名称
        @param  node    要创建的节点信息
        @type str,NodeInfoV2
        '''
        requestMethod = RequestMethod.POST
        try:
            data = "<node_pool_name>" + base64.b64encode(poolname) + "</node_pool_name>\n"
            data += NodeInfoV2.nodeinfoToXml(node, "create")
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.createNodeV2URI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("createNodeV2 : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def delNodeV2(self, poolname, nodeIp, nodePort) :
        '''
        删除指定节点
        @param poolname 节点池名称
        @type str
        @param nodeIP 节点IP
        @type str
        @param nodePort 节点端口
        @type int
        '''
        requestMethod = RequestMethod.POST
        data = "<node_key>\n"
        data += "<node_pool_name>" + base64.b64encode(poolname) + "</node_pool_name>\n"
        data += "<ip>" + nodeIp + "</ip>\n"
        data += "<port>" + str(nodePort) + "</port>\n"
        data += "</node_key>\n"
        try:
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.delNodeURIV2URI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("delNodeV2 : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def updateNodeV2(self, poolname, nodeIp, nodePort, node) :
        '''
        更新指定节点的配置信息
        @param poolname 节点池名称
        @type str
        @param nodeIP 节点IP，用于指定节点
        @type str
        @param nodePort 节点端口，用于指定节点
        @type int
        @param  node   要更新的节点数据。若成员变量不为默认值，则表示要更新
        @type NodeInfoV2
        '''
        requestMethod = RequestMethod.POST
        try :
            data = "<node_key>\n"
            data += "<node_pool_name>" + base64.b64encode(poolname) + "</node_pool_name>\n"
            data += "<ip>" + nodeIp + "</node_pool_name>\n"
            data += "<port>" + str(nodePort) + "</port>\n"
            data += "</node_key>\n"
            data += NodeInfoV2.nodeinfoToXml(node, "update")
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.updateNodeV2URI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("updateNodeV2 : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def getNodesV2Status(self, nodePoolName) :
        '''
        获取指定节点池中所有节点的健康状态、连接数、配置状态列表
        @param nodePoolName 节点池名称
        @type str
        @return nodeStatus
        '''
        requestMethod = RequestMethod.GET
        params = "name=" + urllib.quote_plus(nodePoolName) \
               + "&" + self.authStr
        try :
            httpBody = self.DefaultHttpRequestRetryHandler(self.config.getNodeStatusV2URI,params,requestMethod,'get')
            if httpBody == None :
                raise APIException(4, "unknown error")
            LogInfo.makeLogger("getNodesV2Status_httpBody : " + httpBody)
            nodeStatus = NodeInfoV2.generatingNodeStatus(httpBody)
            return nodeStatus
        except (HttpClientException, APIException) as e:
            reason = str(e.reason)
            LogInfo.makeLogger("getNodesV2Status : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def getNodeV2Info(self, nodePoolName, nodeip, nodeport) :
        '''
        获取具体节点
        @param nodePoolName 节点池名称
        @param nodeip 节点ip
        @param nodeport 节点端口
        @type str
        @return nodeInfo
        '''
        requestMethod = RequestMethod.GET
        params = "name=" + urllib.quote_plus(nodePoolName)    \
               + "&nodeip=" + nodeip                    \
               + "&nodeport=" + str(nodeport)            \
               + "&" + self.authStr
        try :
            httpBody = self.DefaultHttpRequestRetryHandler(self.config.getNodeInfoV2URI,params,requestMethod,'get')
            if httpBody == None :
                raise APIException(4, "unknown error")
            LogInfo.makeLogger("getNodeV2Info_httpBody : " + httpBody)
            nodeInfo = NodeInfoV2.generatingNodeInfo(httpBody)
            return nodeInfo
        except (HttpClientException, APIException) as e:
            reason = str(e.reason)
            LogInfo.makeLogger("getNodeV2Info : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def getNodeListV2(self, nodePoolName) :
        '''
        获取指定节点池中所有节点的健康状态、连接数、配置状态列表
        @param nodePoolName 节点池名称
        @type str
        @return NodeList
        @rtype NodeList
        '''
        requestMethod = RequestMethod.GET
        params = "name=" + urllib.quote_plus(nodePoolName)         \
               + "&" + self.authStr
        try :
            httpBody = self.DefaultHttpRequestRetryHandler(self.config.getNodeListV2URI,params,requestMethod,'get')
            if httpBody == None :
                raise APIException(4, "unknown error")
            LogInfo.makeLogger("getNodeListV2_httpBody : " + httpBody)
            nodeList = NodeInfoV2.generatingNodeList(httpBody)
            return nodeList
        except (HttpClientException, APIException) as e:
            reason = str(e.reason)
            LogInfo.makeLogger("getNodeListV2 : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def createVs(self, vs) :
        '''
        创建新虚拟服务
        @param  vs    要创建的虚拟服务信息
        @type VsInfo
        '''
        requestMethod = RequestMethod.POST
        data = VsInfo.vsinfoToXml(vs, "create")
        try :
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.createVsURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("createVs : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def getVsList(self):
        '''
        获取虚拟服务列表
        '''
        requestMethod = RequestMethod.GET
        params = self.authStr
        try :
            httpBody = self.DefaultHttpRequestRetryHandler(self.config.getVsListURI,params,requestMethod,'get')
            if httpBody == None :
                raise APIException(4, "unknown error")
            LogInfo.makeLogger("getVsList_httpBody : " + httpBody)
            vsNodeList = VsInfo.generatingvsList(httpBody)
            return vsNodeList
        except (HttpClientException, APIException) as e:
            reason = str(e.reason)
            LogInfo.makeLogger("getVsList : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def getVsInfo(self, vsname):
        '''
        获取虚拟服务信息
        @param vsname 虚拟服务名称
        @type str
        '''
        requestMethod = RequestMethod.GET
        params = 'name=' + urllib.quote_plus(vsname) + '&' + self.authStr
        try :
            httpBody = self.DefaultHttpRequestRetryHandler(self.config.getVsInfoURI,params,requestMethod,'get')
            if httpBody == None :
                raise APIException(4, "unknown error")
            LogInfo.makeLogger("getVsInfo_httpBody : " + httpBody)
            vsNodeInfo = VsInfo.generatingvsInfo(httpBody)
            return vsNodeInfo
        except (HttpClientException, APIException) as e:
            reason = str(e.reason)
            LogInfo.makeLogger("getVsInfo : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def getVsStatus(self):
        '''
        获取虚拟服务状态列表
        '''
        requestMethod = RequestMethod.GET
        params = self.authStr
        try :
            httpBody = self.DefaultHttpRequestRetryHandler(self.config.getVsStatusURI,params,requestMethod,'get')
            if httpBody == None :
                raise APIException(4, "unknown error")
            LogInfo.makeLogger("getVsStatus_httpBody : " + httpBody)
            vsNodeStatus = VsInfo.generatingvsStatus(httpBody)
            return vsNodeStatus
        except (HttpClientException, APIException) as e:
            reason = str(e.reason)
            LogInfo.makeLogger("getVsStatus : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def delVs(self, vsname) :
        '''
        删除虚拟服务
        @param vsname 待删除的虚拟服务名称
        @type str
        '''
        requestMethod = RequestMethod.POST
        data = "<vs_name>" + base64.b64encode(vsname) + "</vs_name>\n"
        try :
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.delVsURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("delVs : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def updateVs(self, vsname, vs) :
        '''
        更新指定虚拟服务的配置信息
        @param vsname 虚拟服务名称
        @type str
        @param  vs   要更新的虚拟服务数据。若成员变量不为默认值，则表示要更新
        @type VsInfo
        '''
        requestMethod = RequestMethod.POST
        data = "<vs_name>" + base64.b64encode(vsname) + "</vs_name>\n"
        data += VsInfo.vsinfoToXml(vs, "update")
        
        try :
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.updateVsURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("updateVs : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def resetConfig(self) :
        '''
        openstack用于清空配置
        '''
        requestMethod = RequestMethod.POST
        authStr = "username=" + urllib.quote_plus(self.config.username)    \
                    + "&password=" + urllib.quote_plus(self.config.password)
        try :
            url = self.config.reSetURI + "?" + authStr
            result = self.DefaultHttpRequestRetryHandler(url,'reset',requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("resetConfig : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)

    def getNetnsInfo(self, netns_name):
        '''
        获取netns具体信息
        @param netns_name netns名称
        @type str
        '''
        requestMethod = RequestMethod.GET
        params = 'name=' + urllib.quote_plus(netns_name) + '&' + self.authStr
        try :
            httpBody = self.DefaultHttpRequestRetryHandler(self.config.getNetnsInfoURI,params,requestMethod,'get')
            if httpBody == None :
                raise APIException(4, "unknown error")
            LogInfo.makeLogger("getNetnsInfo_httpBody : " + httpBody)
            netns_info = NetnsInfo.generatingNetnsInfo(httpBody)
            return netns_info
        except (HttpClientException, APIException) as e:
            reason = str(e.reason)
            LogInfo.makeLogger("getNetnsInfo : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)

    def getMacvlanInfo(self, macvlan_name):
        '''
        获取macvlan具体信息
        @param macvlan_name macvlan名称
        @type str
        '''
        requestMethod = RequestMethod.GET
        params = 'name=' + urllib.quote_plus(macvlan_name) + '&' + self.authStr
        try :
            httpBody = self.DefaultHttpRequestRetryHandler(self.config.getMacvlanInfoURI,params,requestMethod,'get')
            if httpBody == None :
                raise APIException(4, "unknown error")
            LogInfo.makeLogger("getMacvlanInfo_httpBody : " + httpBody)
            macvlan_info = MacvlanInfo.generatingMacvlanInfo(httpBody)
            return macvlan_info
        except (HttpClientException, APIException) as e:
            reason = str(e.reason)
            LogInfo.makeLogger("getMacvlanInfo : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)

    def getVlanInfo(self, vlan_device):
        '''
        获取vlan具体信息
        @param vlan_device vlan口device名称，比如eth2.113
        @type str
        '''
        requestMethod = RequestMethod.GET
        params = 'device=' + urllib.quote_plus(vlan_device) + '&' + self.authStr
        try :
            httpBody = self.DefaultHttpRequestRetryHandler(self.config.getVlanInfoURI,params,requestMethod,'get')
            if httpBody == None :
                raise APIException(4, "unknown error")
            LogInfo.makeLogger("getVlanInfo_httpBody : " + httpBody)
            vlan_info = VlanInfo.generatingVlanInfo(httpBody)
            return vlan_info
        except (HttpClientException, APIException) as e:
            reason = str(e.reason)
            LogInfo.makeLogger("getVlanInfo : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)

    def getWanList(self):
        '''
        获取wan口列表
        '''
        requestMethod = RequestMethod.GET
        params = self.authStr
        try :
            httpBody = self.DefaultHttpRequestRetryHandler(self.config.getWanListURI,params,requestMethod,'get')
            if httpBody == None :
                raise APIException(4, "unknown error")
            LogInfo.makeLogger("getWanList_httpBody : " + httpBody)
	    print httpBody
            wanNodeList = WanInfo.generatingwanList(httpBody)
            return wanNodeList
        except (HttpClientException, APIException) as e:
            reason = str(e.reason)
            LogInfo.makeLogger("getWanList : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def getWanInfo(self, wanname):
        '''
        获取wan口具体信息
        @param wanname wan口名称
        @type str
        '''
        requestMethod = RequestMethod.GET
        params = 'name=' + urllib.quote_plus(wanname) + '&' + self.authStr
        try :
            httpBody = self.DefaultHttpRequestRetryHandler(self.config.getWanInfoURI,params,requestMethod,'get')
            if httpBody == None :
                raise APIException(4, "unknown error")
            LogInfo.makeLogger("getWanInfo_httpBody : " + httpBody)
            wanNodeInfo = WanInfo.generatingwanInfo(httpBody)
            return wanNodeInfo
        except (HttpClientException, APIException) as e:
            reason = str(e.reason)
            LogInfo.makeLogger("getWanInfo : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)

    def getLanList(self):
        '''
        获取lan口名称列表
        '''
        requestMethod = RequestMethod.GET
        params = self.authStr
        try :
            httpBody = self.DefaultHttpRequestRetryHandler(self.config.getLanListURI,params,requestMethod,'get')
            if httpBody == None :
                raise APIException(4, "unknown error")
            LogInfo.makeLogger("getLanList_httpBody : " + httpBody)
            return LanInfo.generatinglanList(httpBody)
        except (HttpClientException, APIException) as e:
            reason = str(e.reason)
            LogInfo.makeLogger("getLanList : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)

    def getLanInfo(self, name):
        '''
        获取lan口对应的ip列表
        @name lan口名称
        '''
        requestMethod = RequestMethod.GET
        params = 'name=' + urllib.quote_plus(name) + '&' + self.authStr
        try :
            httpBody = self.DefaultHttpRequestRetryHandler(self.config.getLanInfoURI,params,requestMethod,'get')
            if httpBody == None :
                raise APIException(4, "unknown error")
            LogInfo.makeLogger("getLanInfo_httpBody : " + httpBody)
            return LanInfo.generatinglanInfo(httpBody)
        except (HttpClientException, APIException) as e:
            reason = str(e.reason)
            LogInfo.makeLogger("getLanInfo : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)

    def createNetnsInfo(self, netnsInfo):
        '''
        创建netns配置
        @netnsInfo NetnsInfo类型数据
        '''
        requestMethod = RequestMethod.POST
        data = NetnsInfo.netnsInfoToXml(netnsInfo)
        try :
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.createNetnsURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("create netns: " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)

    def updateNetnsInfo(self, name, netnsInfo) :
        '''
        更新指定netns的配置信息
        @name 指定的netns名称
        @netnsInfo NetnsInfo类型信息
        '''
        requestMethod = RequestMethod.POST
        data = "<netns_name>" + base64.b64encode(name) + "</netns_name>\n"
        data += NetnsInfo.netnsInfoToXml(netnsInfo)
        try :
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.updateNetnsURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("update netns: " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)

    def delNetnsInfo(self, name):
        '''
        删除netns配置
        @name netns配置名称
        '''
        requestMethod = RequestMethod.POST
        data = "<name>" + base64.b64encode(name) + "</name>\n"
        try :
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.deleteNetnsURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("del netns: " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)

    def createMacvlanInfo(self, macvlanInfo):
        '''
        创建macvlan口配置
        @wanInfo MacvlanInfo类型数据
        '''
        requestMethod = RequestMethod.POST
        data = MacvlanInfo.macvlanInfoToXml(macvlanInfo)
        try :
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.createMacvlanURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("create macvlan: " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)

    def updateMacvlanInfo(self, name, macvlanInfo) :
        '''
        更新指定macvlan口的配置信息
        @name 指定的macvlan口名称
        @macvlanInfo MacvlanInfo类型信息
        '''
        requestMethod = RequestMethod.POST
        data = "<macvlan_name>" + base64.b64encode(name) + "</macvlan_name>\n"
        data += MacvlanInfo.macvlanInfoToXml(macvlanInfo)
        try :
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.updateMacvlanURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("update macvlan: " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)

    def delMacvlanInfo(self, name):
        '''
        删除macvlan口配置
        @name macvlan口配置名称
        '''
        requestMethod = RequestMethod.POST
        data = "<name>" + base64.b64encode(name) + "</name>\n"
        try :
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.deleteMacvlanURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("del macvlan: " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)

    def createVlanInfo(self, vlanInfo):
        '''
        创建vlan口配置
        @wanInfo VlanInfo类型数据
        '''
        requestMethod = RequestMethod.POST
        data = VlanInfo.vlanInfoToXml(vlanInfo)
        try :
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.createVlanURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("create vlan: " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)

    def updateVlanInfo(self, name, vlanInfo) :
        '''
        更新指定vlan口的配置信息
        @name 指定的vlan口名称
        @vlanInfo VlanInfo类型信息
        '''
        requestMethod = RequestMethod.POST
        data = "<vlan_name>" + base64.b64encode(name) + "</vlan_name>\n"
        data += VlanInfo.vlanInfoToXml(vlanInfo)
        try :
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.updateVlanURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("update vlan: " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)

    def delVlanInfo(self, name):
        '''
        删除vlan口配置
        @name vlan口配置名称
        '''
        requestMethod = RequestMethod.POST
        data = "<name>" + base64.b64encode(name) + "</name>\n"
        try :
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.deleteVlanURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("del vlan: " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)

    def createWanInfo(self, wanInfo):
        '''
        创建wan口配置
        @wanInfo WanInfo类型数据
        '''
        requestMethod = RequestMethod.POST
        data = WanInfo.wanInfoToXml(wanInfo)
        try :
            params = self.make_Params(data)
            print params
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.createWanURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("create wan: " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)

    def updateWanInfo(self, name, wanInfo) :
        '''
        更新指定wan口的配置信息
        @name 指定的wan口名称
        @wanInfo WanInfo类型信息
        '''
        requestMethod = RequestMethod.POST
        data = "<wan_name>" + base64.b64encode(name) + "</wan_name>\n"
        data += WanInfo.wanInfoToXml(wanInfo)
        try :
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.updateWanURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("update wan: " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)

    def delWanInfo(self, name):
        '''
        删除wan口配置
        @name wan口配置名称
        '''
        requestMethod = RequestMethod.POST
        data = "<name>" + base64.b64encode(name) + "</name>\n"
        try :
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.deleteWanURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("del wan: " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)

    def createLanInfo(self, lanInfo):
        '''
        创建lan口配置
        @lanInfo LanInfo类型数据
        '''
        requestMethod = RequestMethod.POST
        data = LanInfo.lanInfoToXml(lanInfo)
        try :
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.createLanURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("create lan: " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)

    def updateLanInfo(self, name, lanInfo) :
        '''
        更新指定lan口的配置信息
        @name 指定的lan口名称
        @wanInfo LanInfo类型信息
        '''
        requestMethod = RequestMethod.POST
        data = "<lan_name>" + base64.b64encode(name) + "</lan_name>\n"
        data += LanInfo.lanInfoToXml(lanInfo)
        try :
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.updateLanURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("update lan: " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)

    def delLanInfo(self, name):
        '''
        删除lan口配置
        @name lan口配置名称
        '''
        requestMethod = RequestMethod.POST
        data = "<name>" + base64.b64encode(name) + "</name>\n"
        try :
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.deleteLanURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("del lan: " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)

    def getSysStatus(self):
        '''
        获取设备状态
        '''
        requestMethod = RequestMethod.GET
        params = self.authStr
        try :
            httpBody = self.DefaultHttpRequestRetryHandler(self.config.getSysStautsURI,params,requestMethod,'get')
            if httpBody == None :
                raise APIException(4, "unknown error")
            LogInfo.makeLogger("getSysStatus_httpBody : " + httpBody)
            sysInfo = SysInfo.generatingsysInfo(httpBody)
            return sysInfo
        except (HttpClientException, APIException) as e:
            reason = str(e.reason)
            LogInfo.makeLogger("getSysStatus : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def createAcl(self, acl) :
        '''
        创建高级ACL
        @param  acl    要创建的acl的信息
        @rtype AclInfo
        '''
        requestMethod = RequestMethod.POST
        data = AclInfo.aclinfoToXml(acl)
        try :
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.createAclURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("createAcl : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)            
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def delAcl(self, aclname) :
        '''
        删除高级ACL
        @param aclname 待删除高级ACL的名称
        @type str
        '''
        requestMethod = RequestMethod.POST
        data = "<acl_name>" + base64.b64encode(aclname) + "</acl_name>\n"
        try :
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.delAclURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("delAcl : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def updateAcl(self, aclname, acl) :
        '''
        更新指定高级ACL的配置信息
        @param aclname 高级ACL名称
        @type str
        @param  acl   要更新的高级ACL信息
        @type AclInfo
        '''
        requestMethod = RequestMethod.POST
        data = "<acl_name>" + base64.b64encode(aclname) + "</acl_name>\n"
        data += AclInfo.aclinfoToXml(acl)
        
        try :
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.updateAclURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("updateAcl : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def getAdvanceAclList(self):
        '''
        获取高级ACL列表
        '''
        requestMethod = RequestMethod.GET
        params = self.authStr
        try :
            httpBody = self.DefaultHttpRequestRetryHandler(self.config.getAdvanceAclListURI,params,requestMethod,'get')
            if httpBody == None :
                raise APIException(4, "unknown error")
            LogInfo.makeLogger("getAdvanceAclList_httpBody : " + httpBody)
            aclNodeList = AclInfo.generatingaclList(httpBody)
            return aclNodeList
        except (HttpClientException, APIException) as e:
            reason = str(e.reason)
            LogInfo.makeLogger("getAdvanceAclList : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def getAdvanceAclInfo(self, aclname):
        '''
            获取高级ACL具体信息
            @param aclname acl口名称
            @type str
        '''
        requestMethod = RequestMethod.GET
        params = 'name=' + urllib.quote_plus(aclname) + '&' + self.authStr
        try :
            httpBody = self.DefaultHttpRequestRetryHandler(self.config.getAdvanceAclInfoURI,params,requestMethod,'get')
            if httpBody == None :
                raise APIException(4, "unknown error")
            LogInfo.makeLogger("getAdvanceAclInfo_httpBody : " + httpBody)
            aclNodeInfo = AclInfo.generatingaclInfo(httpBody)
            return aclNodeInfo
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("getAdvanceAclInfo : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def addPoolMonitor(self, poolname, monitorname) :
        '''
        增量添加节点池的监视器
        @param  poolname 节点池名称
        @param  monitorname 待添加的监视器名称
        @rtype str,str
        '''
        requestMethod = RequestMethod.POST
        data = '<monitor_key>\n<pool_name>' + base64.b64encode(poolname)   \
              + '</pool_name>\n<monitor_name>' + base64.b64encode(monitorname)  \
              + '</monitor_name>\n</monitor_key>\n'
        try :
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.addPoolMonitorURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("addPoolMonitor : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def delPoolMonitor(self, poolname, monitorname) :
        '''
        增量删除节点池的监视器
        @param  poolname 节点池名称
        @param  monitorname 待删除的监视器名称
        @rtype str,str
        '''
        requestMethod = RequestMethod.POST
        data = '<monitor_key>\n<pool_name>' + base64.b64encode(poolname)   \
              + '</pool_name>\n<monitor_name>' + base64.b64encode(monitorname)  \
              + '</monitor_name>\n</monitor_key>\n'
        try :
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.delPoolMonitorURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("delPoolMonitor : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def createMySQLProfile(self, mysqlprofile) :
        '''
        创建mysql策略
        @param  mysqlprofile    要创建的mysql策略的信息
        @rtype MySQLProfileInfo
        '''
        requestMethod = RequestMethod.POST
        data = MySQLProfileInfo.make_xml_data(mysqlprofile, "create")
        try :
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.createMySQLProfile,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("createMySQLProfile : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)            
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def updateMySQLProfile(self, name, mysqlprofile) :
        '''
        更新指定mysql策略的配置信息
        @param name mysql策略名称
        @type str
        @param  mysqlprofile   要更新的mysql策略信息
        @type MySQLProfileInfo
        '''
        requestMethod = RequestMethod.POST
        data = "<name>" + base64.b64encode(name) + "</name>\n"
        data += MySQLProfileInfo.make_xml_data(mysqlprofile, "update")
        
        try :
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.updateMySQLProfile,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("updateMySQLProfile : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    def getMySQLProfileInfo(self, name):
        '''
            获取mysql策略具体信息
            @param aclname mysql策略名称
            @type str
        '''
        requestMethod = RequestMethod.GET
        params = 'name=' + urllib.quote_plus(name) + '&' + self.authStr
        try :
            httpBody = self.DefaultHttpRequestRetryHandler(self.config.getMySQLProfileInfoURI,params,requestMethod,'get')
            if httpBody == None :
                raise APIException(4, "unknown error")
            LogInfo.makeLogger("getMySQLProfileInfo_httpBody : " + httpBody)
            mysqlNodeInfo = MySQLProfileInfo.generatingMySQLProfileInfo(httpBody)
            return mysqlNodeInfo
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("getMySQLProfileInfo : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)

    def getSnatSetList(self):
        '''
        获取snat地址集名称列表
        '''
        requestMethod = RequestMethod.GET
        params = self.authStr
        try :
            httpBody = self.DefaultHttpRequestRetryHandler(self.config.getSnatSetListURI,params,requestMethod,'get')
            if httpBody == None :
                raise APIException(4, "unknown error")
            LogInfo.makeLogger("httpBody : " + httpBody)
            return SnatSet.generatingSnatSetList(httpBody)
        except (HttpClientException, APIException) as e:
            reason = str(e.reason)
            LogInfo.makeLogger("Info : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)

    def getSnatSet(self, name):
        '''
        获取snat地址集
        @name snat地址集名称
        '''
        requestMethod = RequestMethod.GET
        params = 'name=' + urllib.quote_plus(name) + '&' + self.authStr
        try :
            httpBody = self.DefaultHttpRequestRetryHandler(self.config.getSnatSetURI,params,requestMethod,'get')
            if httpBody == None :
                raise APIException(4, "unknown error")
            LogInfo.makeLogger("httpBody : " + httpBody)
            return SnatSet.generatingSnatSet(httpBody)
        except (HttpClientException, APIException) as e:
            reason = str(e.reason)
            LogInfo.makeLogger("Info : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)

    def createSnatSet(self, snatSet):
        '''
        创建snat地址集配置
        @snatSet SnatSet类型配置
        '''
        requestMethod = RequestMethod.POST
        data = SnatSet.snatSetToXml(snatSet)
        try :
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.createSnatSetURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("create wan: " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)

    def updateSnatSet(self, name, snatSet) :
        '''
        更新snat地址集配置
        @name snat地址集名称
        @snatSet SnatSet类型配置
        '''
        requestMethod = RequestMethod.POST
        data = "<snat_name>" + base64.b64encode(name) + "</snat_name>\n"
        data += SnatSet.snatSetToXml(snatSet)
        try :
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.updateSnatSetURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("update wan: " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)

    def deleteSnatSet(self, name):
        '''
        删除snat地址集配置
        @name snat地址集名称
        '''
        requestMethod = RequestMethod.POST
        data = "<snat_name>" + base64.b64encode(name) + "</snat_name>\n"
        try :
            params = self.make_Params(data)
            LogInfo.makeLogger("params : " + params)
            result = self.DefaultHttpRequestRetryHandler(self.config.deleteSnatSetURI,params,requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("del wan: " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)

    def api_is_avaliable(self, username, password, client=None) :
        '''
        测试Openstack验证用户名密码
        @username  测试的用户名
        @type str
        @password
        @client 统计openstack用户的标识参数
        @type str
        '''
        requestMethod = RequestMethod.GET
        authStr = "username=" + urllib.quote_plus(base64.b64encode(username))    \
                    + "&password=" + urllib.quote_plus(base64.b64encode(password))
        openstackClient = "";
        if client != None:
            openstackClient = "&client=" + urllib.quote_plus(client)
        try :
            url = self.config.testURI + "?" + authStr + openstackClient
            result = self.DefaultHttpRequestRetryHandler(url,'',requestMethod)
            return result
        except APIException, e:
            reason = str(e.reason)
            LogInfo.makeLogger("api_is_avaliable : " + str(e.code) + "," + reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("codeTransfer.code : " + str(code))
            LogInfo.makeLogger("codeTransfer.reason : " + reason)
            raise APIException(code, reason)
        except Exception, e:
            raise Exception(e)
    
if __name__ == "__main__":
    adapi = REST_ADAPI("admin", "root1234", "200.200.147.193", "443")
    adapi.api_is_avaliable('admin','root1234')
    
    #macvlan test
    macvlan = MacvlanInfo('')
    macvlan.name = 'openstack_test2'
    macvlan.enable = 'true'
    macvlan.ifname = 'eth2.222'
    macvlan.mac = 'fe:ff:22:33:11:02'
    macvlan.netns_id = 2
    #macvlan.macvlan_id = 1

    netns_info = adapi.getNetnsInfo('openstack_test21')
    print 'name is ' + netns_info.name
    print 'enable is ' + netns_info.enable
    print 'tenant is ' + netns_info.tenant
    print 'appg_id is ' + str(netns_info.appg_id)
    print 'netns_id is ' + str(netns_info.netns_id)

'''
    #macvlan test
    macvlan_info = adapi.getMacvlanInfo('openstack_test2')
    print 'name is ' + macvlan_info.name
    print 'enable is ' + macvlan_info.enable
    print 'ifname is ' + macvlan_info.ifname
    print 'device is ' + macvlan_info.device
    print 'mac is ' + macvlan_info.mac
    print 'netns_id is ' + str(macvlan_info.netns_id)

    #netns test
    netns = NetnsInfo('')
    netns.name = 'openstack_test21'
    netns.enable = 'false'
    netns.tenant = 'test1'
    netns.appg_id = 30
    #netns.netns_id = 1

    adapi.createNetnsInfo(netns)

    #vlan test
    #adapi.updateVlanInfo('test_vlan_2_123', vlan)
    adapi.delVlanInfo('openstack_2_123')

    vlan_info = adapi.getVlanInfo('eth2.222')
    print 'vlan_name is ' + vlan_info.name
    print 'vlan_device is ' + vlan_info.device
    print 'vlan_enable is ' + vlan_info.enable
'''


