# -*- coding: utf-8 -*-
# Copyright (c) 2008-2020, AD SANGFOR
# Filename: MADAPI.py
# 定义了 MADAPI PYTHON SDK 对外的接口
import urllib
import json
#引入代理机制，转换旧版新版api
from oldapi.vad_proxy_ctl import VadProxy
from api.Configuration import Configuration
from api.APIException import APIException
from api.http.HttpClient import HttpClient, RequestMethod, HttpClientException
from api.LogInfo import LogInfo
from api.StaticRouteInfo import StaticRouteInfo
from api.NetnsInfo import NetnsInfo
from api.MacvlanInfo import MacvlanInfo
from api.VlanInfo import VlanInfo
from api.BondInfo import BondInfo
from api.SwitchInfo import SwitchInfo
from api.VADInfo import VADInfo
from api.ImageInfo import ImageInfo
from api.ResInfo import ResInfo
from api.ServInfo import ServInfo
from api.IPGroup import IPGroup
from api.PersistInfo import PersistInfo
from api.MonitorInfo import MonitorInfo
from api.PoolInfo import PoolInfo
from api.NodeInfo import NodeInfo
from api.VSInfo import VSInfo
from api.WanInfo import WanInfo
from api.LanInfo import LanInfo
from api.VxlanInfo import VxlanInfo
from api.SrouteInfo import SrouteInfo
from api.NetifIP import NetifIP
from api.NetifInfo import NetifInfo
from api.SnatSet import SnatSet
from api.AclInfo import AclInfo
from api.ErrorInfo import ErrInfo

class ADAPI:
    '''
    应用jsontoxml方案的adapi接口，基本可以复用MADAPI的方法
    '''

    def __init__(self, username, password, ip, port, timeout=20):
        '''
        初始化类
        @username ： 用户名称
        @password ： 用户密码
        @ip       ： 设备IP
        @port     ： 设备端口
        @timeout  :  超时时间设置
        @return
        '''
        #config = Configuration(username, password, ip, port, timeout)
        #self.config = config
        self.addr = ip
        self.port = port
        self.username = username
        self.passwd = password

    @classmethod
    def getVersion(cls):
        '''
        获取MADAPI的版本信息
        '''
        import __init__
        return __init__.__version__

    def setConfig(self, configuration=None):
        '''
        用于初始化MADAPI SDK所需信息。
        包括AD IP、AD端口(若为None，默认设置为443)、用户名、密码
        @param configuration 初始化信息类。
        @type Configuration
        @return
        @rtype
        '''
        if configuration is None:
            return
        self.config = configuration

    def makeJson(self, data):
        '''
        将数据转换成json格式
        @data list类型数据
        @return json字符串
        '''
        return json.dumps(data, ensure_ascii=False)

    def makeParams(self, data):
        '''
        用于组合数据
        @data dict/list类型数据
        @rtype
        '''
        params = {
            'data': json.dumps(data, ensure_ascii=False)
        }
        return params

    def proxyProc(self, params, apiFunc):
        '''
        代理请求处理接口
        '''
        
        proxy = VadProxy(params)
        try:
            result = proxy.vadProxyHandle()
            print 'proxy handle end'
            return apiFunc(result);
        except Exception as e:
            print e

    def makeADParams(self, api, params=''):
        '''
        组装VAD代理接口信息
        @api 要调用的ADAPI接口名称
        @params 传给ADAPI的参数
        {
            'ad_name': VAD名称,
            'function': 调用的ADAPI，
            'args': 要给ADAPI接口的参数
        }
        '''
        adAuth = {
            'adaddr': self.addr,
            'adport': self.port,
            'adusername': self.username,
            'adpasswd': self.passwd,
            'function': api,
            'args': params
        }
        return adAuth

    def createServInfo(self, servInfo):
        '''
        新建服务配置
        @servInfo ServInfo类型数据
        '''
        key = ServInfo.servInfoToDict(servInfo)
        params = self.makeADParams('createServ', key)
        return self.proxyProc(
            params,
            ServInfo
            )

    def delServInfo(self, name):
        '''
        删除服务配置
        @name 要删除的服务配置名称
        '''
        key = {'name': name}
        params = self.makeADParams('delServ', key)
        return self.proxyProc(
            params,
            ServInfo
            )

    def addServPort(self, servInfo):
        '''
        往服务配置中添加端口
        @servInfo ServInfo类型数据
        '''
        key = ServInfo.servInfoToDict(servInfo)
        params = self.makeADParams('addServPort', key)
        return self.proxyProc(
            params,
            ServInfo
            )

    def delServPort(self, servInfo):
        '''
        从服务配置中删除端口
        @servInfo ServInfo类型数据
        '''
        key = ServInfo.servInfoToDict(servInfo)
        params = self.makeADParams('delServPort', key)
        return self.proxyProc(
            params,
            ServInfo
            )

    def getServInfo(self, name):
        '''
        根据服务名称获取服务
        @name 服务名称
        '''
        key = {'name': name}
        params = self.makeADParams('getServInfo', key)
        return self.proxyProc(
            params,
            ServInfo.generatingServInfo
            )

    def getServInfoList(self):
        '''
        获取服务信息列表
        '''
        params = self.makeADParams('getServList')
        return self.proxyProc(
            params,
            ServInfo.generatingServList
            )

    def createIPGroup(self, ipGroup):
        '''
        新建IP组配置
        @ipGroup IPGroup类型数据
        '''
        key = IPGroup.ipGroupToDict(ipGroup)
        params = self.makeADParams('createIpGroup', key)
        return self.proxyProc(
            params,
            IPGroup
            )

    def delIPGroup(self, name):
        '''
        删除IP组配置
        @name IP组名称
        '''
        key = {'name': name}
        params = self.makeADParams('delIpGroup', key)
        return self.proxyProc(
            params,
            IPGroup
            )

    def addIPInfo(self, ipInfo):
        '''
        往IP配置中添加ip
        @ipInfo IPInfo类型数据
        '''
        key = IPGroup.ipGroupToDict(ipInfo)
        params = self.makeADParams('addIp', key)
        return self.proxyProc(
            params,
            IPGroup
            )

    def delIPInfo(self, ipInfo):
        '''
        从IP配置中删除ip
        @ipInfo IPInfo类型数据
        '''
        key = IPGroup.ipGroupToDict(ipInfo)
        params = self.makeADParams('delIp', key)
        return self.proxyProc(
            params,
            IPGroup
            )

    def getIPGroup(self, name):
        '''
        根据名称获取IP组配置
        '''
        key = {'name': name}
        params = self.makeADParams('getIpGroupInfo', key)
        return self.proxyProc(
            params,
            IPGroup.generatingIPGroup
            )

    def getIPGroupList(self):
        '''
        获取IP组信息列表
        '''
        params = self.makeADParams('getIpGroupList')
        return self.proxyProc(
            params,
            IPGroup.generatingIPGroupList
            )

    def createPersist(self, pers):
        '''
        新建会话保持配置
        @pers PersistInfo类型数据
        '''
        key = PersistInfo.persistInfoToDict(pers)
        params = self.makeADParams('createPersist', key)
        return self.proxyProc(
            params,
            PersistInfo
            )

    def updatePersist(self, name, pers):
        '''
        更新会话保持配置
        @name 会话保持名称
        @pers PersistInfo类型数据
        '''
        key = PersistInfo.persistInfoToDict(pers)
        key['persist_name'] = name
        params = self.makeADParams('updatePersist', key)
        return self.proxyProc(
            params,
            PersistInfo
            )

    def delPersist(self, name):
        '''
        删除会话保持配置
        @name 会话保持名称
        '''
        key = {'name': name}
        params = self.makeADParams('delPersist', key)
        return self.proxyProc(
            params,
            PersistInfo
            )

    def getPersistInfo(self, name):
        '''
        获取会话保持信息
        @name 会话保持名称
        '''
        key = {'name': name}
        params = self.makeADParams('getPersistInfo', key)
        return self.proxyProc(
            params,
            PersistInfo.generatingPersistInfo
            )

    def getPersistList(self):
        '''
        获取会话保持信息列表
        '''
        params = self.makeADParams('getPersistList')
        return self.proxyProc(
            params,
            PersistInfo.generatingPersistList
            )

    def createMonitorInfo(self, monitor):
        '''
        新建监视器
        @monitor MonitorInfo类型信息
        '''
        key = MonitorInfo.monitorInfoToDict(monitor)
        params = self.makeADParams('createNodeMonitor', key)
        return self.proxyProc(
            params,
            MonitorInfo
            )

    def updateMonitorInfo(self, name, monitor):
        '''
        更新监视器
        @name 监视器名称
        @monitor MonitorInfo类型信息
        '''
        key = MonitorInfo.monitorInfoToDict(monitor)
        key['monitor_name'] = name
        params = self.makeADParams('updateNodeMonitor', key)
        return self.proxyProc(
            params,
            MonitorInfo
            )

    def delMonitorInfo(self, name):
        '''
        删除监视器配置
        @name 监视器名称
        '''
        key = {'name': name}
        params = self.makeADParams('delNodeMonitor', key)
        return self.proxyProc(
            params,
            MonitorInfo
            )

    def getMonitorInfo(self, name):
        '''
        获取监视器信息
        @name 监视器名称
        '''
        key = {'name': name}
        params = self.makeADParams('getNodeMonitorInfo', key)
        return self.proxyProc(
            params,
            MonitorInfo.generatingMonitorInfo
            )

    def getMonitorList(self):
        '''
        获取监视器信息列表
        '''
        params = self.makeADParams('getNodeMonitorList')
        return self.proxyProc(
            params,
            MonitorInfo.generatingMonitorList
            )

    def createPoolInfo(self, pool):
        '''
        新建节点池
        @pool PoolInfo类型信息
        '''
        key = PoolInfo.poolInfoToDict(pool)
        params = self.makeADParams('createNodePool', key)
        return self.proxyProc(
            params,
            PoolInfo
            )

    def updatePoolInfo(self, name, pool):
        '''
        更新节点池
        @name 要更新配置的节点池名称
        @pool PoolInfo类型信息
        '''
        key = PoolInfo.poolInfoToDict(pool)
        key['pool_name'] = name
        params = self.makeADParams('updateNodePool', key)
        return self.proxyProc(
            params,
            PoolInfo
            )

    def delPoolInfo(self, name):
        '''
        删除节点池配置
        @name 节点池名称
        '''
        key = {'name': name}
        params = self.makeADParams('delNodePool', key)
        return self.proxyProc(
            params,
            PoolInfo
            )

    def addMonitor(self, poolName, monitorName):
        '''
        往节点池添加监视器
        @poolName 节点池名称
        @monitorName 监视器名称
        '''
        key = {'name': poolName, 'monitor': monitorName}
        params = self.makeADParams('addPoolMonitor', key)
        return self.proxyProc(
            params,
            PoolInfo
            )

    def delMonitor(self, poolName, monitorName):
        '''
        从节点池中删除监视器
        @poolName 节点池名称
        @monitorName 监视器名称
        '''
        key = {'name': poolName, 'monitor': monitorName}
        params = self.makeADParams('delPoolMonitor', key)
        return self.proxyProc(
            params,
            PoolInfo
            )

    def getPoolInfo(self, name):
        '''
        获取节点池信息
        @name 节点池名称
        '''
        key = {'name': name}
        params = self.makeADParams('getNodePoolInfo', key)
        return self.proxyProc(
            params,
            PoolInfo.generatingPoolInfo
            )

    def getPoolList(self):
        '''
        获取节点池信息列表
        '''
        params = self.makeADParams('getNodePoolList')
        return self.proxyProc(
            params,
            PoolInfo.generatingPoolList
            )

    def createNode(self, poolName, node):
        '''
        往节点池添加节点
        @poolName 节点池名称
        @node NodeInfo类型信息
        '''
        key = NodeInfo.nodeInfoToDict(node)
        key['name'] = poolName
        params = self.makeADParams('createNode', key)
        return self.proxyProc(
            params,
            NodeInfo
            )

    def updateNode(self, poolName, nodeIP, nodePort, node):
        '''
        更新节点池中的节点
        @poolName 节点池名称
        @nodeIP 节点IP
        @nodePort 节点端口
        @node NodeInfo类型信息
        '''
        key = NodeInfo.nodeInfoToDict(node)
        key['name'] = poolName
        key['node_ip'] = nodeIP
        key['node_port'] = nodePort
        params = self.makeADParams('updateNode', key)
        return self.proxyProc(
            params,
            NodeInfo
            )

    def delNode(self, poolName, nodeIP, nodePort):
        '''
        从节点池删除节点
        @poolName 节点池名称
        @nodeIP 节点IP
        @nodePort 节点端口
        '''
        key = {'name': poolName, 'ip': nodeIP, 'port': nodePort}
        params = self.makeADParams('delNode', key)
        return self.proxyProc(
            params,
            NodeInfo
            )

    def getNodeInfo(self, poolName, nodeIP, nodePort):
        '''
        获取节点信息
        @poolName 节点池名称
        @nodeIP 节点IP
        @nodePort 节点端口
        '''
        key = {'name': poolName, 'ip': nodeIP, 'port': nodePort}
        params = self.makeADParams('getNodeInfo', key)
        return self.proxyProc(
            params,
            NodeInfo.generatingNodeInfo
            )

    def getNodeList(self, poolName):
        '''
        获取节点信息列表
        @poolName 节点池名称
        '''
        key = {'name': poolName}
        params = self.makeADParams('getNodeList', key)
        return self.proxyProc(
            params,
            NodeInfo.generatingNodeList
            )

    def getNodeStatus(self, poolName):
        '''
        获取节点状态列表
        @poolName 节点池名称
        '''
        key = {'name': poolName}
        params = self.makeADParams('getNodesStatus', key)
        return self.proxyProc(
            params,
            NodeInfo.generatingNodeStatus
            )

    def createVS(self, vs):
        '''
        新建虚拟服务
        @vs VSInfo类型数据
        '''
        key = VSInfo.vsInfoToDict(vs)
        params = self.makeADParams('createVs', key)
        return self.proxyProc(
            params,
            VSInfo
            )

    def updateVS(self, name, vs):
        '''
        更新虚拟服务
        @name 虚拟服务名称
        @vs VSInfo类型数据
        '''
        key = VSInfo.vsInfoToDict(vs)
        key['vs_name'] = name
        params = self.makeADParams('updateVs', key)
        return self.proxyProc(
            params,
            VSInfo
            )

    def delVS(self, name):
        '''
        删除虚拟服务
        @name 虚拟服务名称
        '''
        key = {'name': name}
        params = self.makeADParams('delVs', key)
        return self.proxyProc(
            params,
            VSInfo
            )

    def getVSInfo(self, name):
        '''
        获取虚拟服务信息
        @name 虚拟服务名称
        '''
        key = {'name': name}
        params = self.makeADParams('getVsInfo', key)
        return self.proxyProc(
            params,
            VSInfo.generatingVSInfo
            )

    def getVSStatus(self):
        '''
        获取虚拟服务状态
        '''
        params = self.makeADParams('getVsStatus')
        return self.proxyProc(
            params,
            VSInfo.generatingVSStatus
            )

    def getVSList(self):
        '''
        获取虚拟服务列表
        '''
        params = self.makeADParams('getVsList')
        return self.proxyProc(
            params,
            VSInfo.generatingVSList
            )

    def createWanInfo(self, wanInfo):
        '''
        新建wan口
        @wanInfo WanInfo类型数据
        '''
        key = WanInfo.wanInfoToDict(wanInfo)
        params = self.makeADParams('createWanInfo', key)
        print params
        return self.proxyProc(
            params,
            WanInfo
            )

    def updateWanInfo(self, name, wanInfo):
        '''
        更新wan口信息
        @name 需要更新的wan口名称
        @wanInfo WanInfo类型数据
        '''
        key = WanInfo.wanInfoToDict(wanInfo)
        key['wan_name'] = name
        params = self.makeADParams('updateWanInfo', key)
        return self.proxyProc(
            params,
            WanInfo
            )

    def deleteWanInfo(self, name):
        '''
        删除wan口配置
        @name 需要删除的wan口名称
        '''
        key = {'name': name}
        params = self.makeADParams('deleteWanInfo', key)
        return self.proxyProc(
            params,
            WanInfo
            )

    def getWanInfo(self, name):
        '''
        获取wan口配置ip信息列表
        @name wan口名称
        '''
        key = {'name': name}
        params = self.makeADParams('getWanInfo', key)
        return self.proxyProc(
            params,
            WanInfo.generatingWanInfo
            )

    def getWanList(self):
        '''
        获取wan口配置名称信息列表
        '''
        params = self.makeADParams('getWanList')
        return self.proxyProc(
            params,
            WanInfo.generatingWanList
            )

    def createLanInfo(self, lanInfo):
        '''
        新建lan口
        @lanInfo lanInfo类型数据
        '''
        key = LanInfo.lanInfoToDict(lanInfo)
        params = self.makeADParams('createLanInfo', key)
        return self.proxyProc(
            params,
            LanInfo
            )

    def updateLanInfo(self, name, lanInfo):
        '''
        更新lan口信息
        @name 需要更新的lan口名称
        @lanInfo LanInfo类型数据
        '''
        key = LanInfo.lanInfoToDict(lanInfo)
        key['lan_name'] = name
        params = self.makeADParams('updateLanInfo', key)
        return self.proxyProc(
            params,
            LanInfo
            )

    def deleteLanInfo(self, name):
        '''
        删除lan口配置
        @name 需要删除的lan口名称
        '''
        key = {'name': name}
        params = self.makeADParams('deleteLanInfo', key)
        return self.proxyProc(
            params,
            LanInfo
            )

    def getLanInfo(self, name):
        '''
        获取lan口配置ip信息列表
        @name lan口名称
        '''
        key = {'name': name}
        params = self.makeADParams('getLanInfo', key)
        return self.proxyProc(
            params,
            LanInfo.generatingLanInfo
            )

    def getLanList(self):
        '''
        获取lan口配置名称信息列表
        '''
        params = self.makeADParams('getLanList')
        return self.proxyProc(
            params,
            LanInfo.generatingLanList
            )

    def createSnatSet(self, snatSet):
        '''
        新建snat地址集
        @snatSet SnatSet类型数据
        '''
        key = SnatSet.snatSetToDict(snatSet)
        params = self.makeADParams('createSnatSet', key)
        return self.proxyProc(
            params,
            SnatSet
            )

    def updateSnatSet(self, name, snatSet):
        '''
        更新snat地址集配置
        @name 需要更新的snat地址集名称
        @snatSet SnatSet类型数据
        '''
        key = SnatSet.snatSetToDict(snatSet)
        key['snat_name'] = name
        params = self.makeADParams('updateSnatSet', key)
        return self.proxyProc(
            params,
            SnatSet
            )

    def deleteSnatSet(self, name):
        '''
        删除snat地址集配置
        @name 需要删除的snat地址集名称
        '''
        key = {'name': name}
        params = self.makeADParams('deleteSnatSet', key)
        return self.proxyProc(
            params,
            SnatSet
            )

    def getSnatSet(self, name):
        '''
        获取snat地址集
        @name snat地址集名称
        '''
        key = {'name': name}
        params = self.makeADParams('getSnatSet', key)
        return self.proxyProc(
            params,
            SnatSet.generatingSnatSet
            )

    def getSnatSetList(self):
        '''
        获取snat地址集名称信息列表
        '''
        params = self.makeADParams('getSnatSetList')
        return self.proxyProc(
            params,
            SnatSet.generatingSnatSetList
            )

    def createAcl(self, aclInfo):
        '''
        创建高级ACL
        @AclInfo AclInfo类型数据
        '''
        key = AclInfo.aclInfoToDict(aclInfo)
        params = self.makeADParams('createAcl', key)
        return self.proxyProc(
            params,
            AclInfo
            )

    def updateAcl(self, name, aclInfo):
        '''
        更新高级ACL
        @name  高级ACL名称
        @AclInfo AclInfo类型数据
        '''
        key = AclInfo.aclInfoToDict(aclInfo)
        key['acl_name'] = name
        params = self.makeADParams('updateAcl', key)
        return self.proxyProc(
            params,
            AclInfo
            )

    def deleteAcl(self, name):
        '''
        删除高级ACL
        @name  高级ACL名称
        '''
        key = {'name': name}
        params = self.makeADParams('deleteAcl', key)
        return self.proxyProc(
            params,
            AclInfo
            )

    def getAclInfo(self, name):
        '''
        获取高级ACL配置
        @name 高级ACL名称
        '''
        key = {'name': name}
        params = self.makeADParams('getAclInfo', key)
        return self.proxyProc(
            params,
            AclInfo.generatingAclInfo
            )

    def getAclList(self):
        '''
        获取高级ACL配置列表
        '''
        params = self.makeADParams('getAclList')
        return self.proxyProc(
            params,
            AclInfo.generatingAclList
            )

    def createVlan(self, vlanInfo):
        '''
        新建vlan
        @vlanInfo VlanInfo类型数据
        '''
        key = VlanInfo.vlanInfoToDict(vlanInfo)
        params = self.makeADParams('createVlanInfo', key)
        return self.proxyProc(
            params,
            VlanInfo
            )

    def updateVlan(self, name, vlanInfo):
        '''
        更新vlan
        @name vlan名称
        @vlanInfo VlanInfo类型数据
        '''
        key = VlanInfo.vlanInfoToDict(vlanInfo)
        key['vlan_name'] = name
        params = self.makeADParams('updateVlanInfo', key)
        return self.proxyProc(
            params,
            VlanInfo
            )

    def deleteVlan(self, name):
        '''
        删除vlan
        @name 要删除的配置名称
        '''
        key = {'vlan_name': name}
        params = self.makeADParams('deleteVlanInfo', key)
        return self.proxyProc(
            params,
            VlanInfo
            )

    def getVlanInfo(self, name):
        '''
        获取vlan信息
        @name vlan名称
        '''
        key = {'vlan_name': name}
        params = self.makeADParams('getVlanInfo', key)
        return self.proxyProc(
            params,
            VlanInfo.generatingVlanInfo
            )

    def createMacvlan(self, macvlanInfo):
        '''
        新建macvlan
        @macvlanInfo MacvlanInfo类型数据
        '''
        key = MacvlanInfo.macvlanInfoToDict(macvlanInfo)
        params = self.makeADParams('createMacvlanInfo', key)
        return self.proxyProc(
            params,
            MacvlanInfo
            )

    def updateMacvlan(self, name, macvlanInfo):
        '''
        更新macvlan
        @name macvlan名称
        @macvlanInfo MacvlanInfo类型数据
        '''
        key = MacvlanInfo.macvlanInfoToDict(macvlanInfo)
        key['macvlan_name'] = name
        params = self.makeADParams('updateMacvlanInfo', key)
        return self.proxyProc(
            params,
            MacvlanInfo
            )

    def deleteMacvlan(self, name):
        '''
        删除macvlan
        @name 要删除的配置名称
        '''
        key = {'macvlan_name': name}
        params = self.makeADParams('deleteMacvlanInfo', key)
        return self.proxyProc(
            params,
            MacvlanInfo
            )

    def getMacvlanInfo(self, name):
        '''
        获取macvlan信息
        @name macvlan名称
        '''
        key = {'macvlan_name': name}
        params = self.makeADParams('getMacvlanInfo', key)
        return self.proxyProc(
            params,
            MacvlanInfo.generatingMacvlanInfo
            )

    def createNetns(self, netnsInfo):
        '''
        新建netns
        @netnsInfo NetnsInfo类型数据
        '''
        key = NetnsInfo.netnsInfoToDict(netnsInfo)
        params = self.makeADParams('createNetnsInfo', key)
        return self.proxyProc(
            params,
            NetnsInfo
            )

    def updateNetns(self, name, netnsInfo):
        '''
        更新netns
        @name netns名称
        @netnsInfo NetnsInfo类型数据
        '''
        key = NetnsInfo.netnsInfoToDict(netnsInfo)
        key['netns_name'] = name
        params = self.makeADParams('updateNetnsInfo', key)
        return self.proxyProc(
            params,
            NetnsInfo
            )

    def deleteNetns(self, name):
        '''
        删除netns
        @name 要删除的配置名称
        '''
        key = {'netns_name': name}
        params = self.makeADParams('deleteNetnsInfo', key)
        return self.proxyProc(
            params,
            NetnsInfo
            )

    def getNetnsInfo(self, name):
        '''
        获取netns信息
        @name netns名称
        '''
        key = {'netns_name': name}
        params = self.makeADParams('getNetnsInfo', key)
        return self.proxyProc(
            params,
            NetnsInfo.generatingNetnsInfo
            )

    def createStaticRoute(self, route):
        '''
        创建静态路由
        @route StaticRouteInfo类型信息
        '''
        try:
            key = StaticRouteInfo.routeInfoToDict(route)
            params = self.makeADParams('createStaticRoute', key)
            print 'params ' + str(params)
            return self.proxyProc(
                params,
                StaticRouteInfo
                )
        except Exception as e:
            print 'createStaticRoute fail'
            print e

    def updateStaticRoute(self, net, mask, netns_id, route):
        '''
        更新静态路由
        @net 网络号
        @mask 掩码
        @netns_id 对应netns的id
        @route StaticRouteInfo类型信息
        '''
        key = StaticRouteInfo.routeInfoToDict(route)
        key['old_net'] = net
        key['old_mask'] = mask
        key['old_netns_id'] = netns_id
        params = self.makeADParams('updateStaticRoute', key)
        return self.proxyProc(
            params,
            StaticRouteInfo
            )

    def delStaticRoute(self, net, mask, netns_id):
        '''
        删除静态路由
        @net 网络号
        @mask 掩码
        @netns_id 对应netns的id
        '''
        key = {}
        key['net'] = net
        key['mask'] = mask
        key['netns_id'] = netns_id
        params = self.makeADParams('delStaticRoute', key)
        return self.proxyProc(
            params,
            StaticRouteInfo
            )

    def getStaticRouteInfo(self, net, mask, netns_id):
        '''
        获取静态路由信息
        @net 网络号
        @mask 掩码
        @netns_id 对应netns的id
        '''
        key = {}
        key['net'] = net
        key['mask'] = mask
        key['netns_id'] = netns_id
        params = self.makeADParams('getStaticRouteInfo', key)
        return self.proxyProc(
            params,
            StaticRouteInfo.generatingStaticRouteInfo
            )

if __name__ == '__main__':
    api = ADAPI('admin', 'root1234', '200.200.147.193', '443')

    route_info = StaticRouteInfo()
    route_info.net = '34.22.44.0'
    route_info.mask = 24
    route_info.netns_id = 11
    route_info.gw_addr = '192.168.117.2'

    #result = api.createStaticRoute(route_info)
    result = api.delStaticRoute('34.22.44.0', 24, 11)
    print result.isFailed()
    print result.getErrCode()
    print result.getErrStr()


    '''
    macvlan = api.getMacvlanInfo('test123')
    print 'success:',True if not macvlan.isFailed() else False
    print 'name:',macvlan.name
    print 'ifname:',macvlan.ifname
    print 'device:',macvlan.device
    print 'mac:',macvlan.mac
    print 'netns_id:',str(macvlan.netnsId)
    print 'orgin_response:',macvlan

    netns = api.getNetnsInfo('test123')
    print 'success:',True if not netns.isFailed() else False
    print 'name:',netns.name
    print 'tenant:',netns.tenant
    print 'netns_id:',str(netns.netnsId)
    print 'appg_id:',str(netns.appgId)
    print 'orgin_response:',netns

    vlan = api.getVlanInfo('eth2.222')
    print 'fail:',vlan.isFailed()
    print 'name:',vlan.name
    print 'ifname:',vlan.ifname
    print 'device:',vlan.device
    print 'vlan_id:',str(vlan.vlanId)
    print 'orgin_response:',vlan

    vlan_info = VlanInfo()
    vlan_info.name = 'openstack_test'
    vlan_info.ifname = 'eth2'
    vlan_info.vlanId = 234

    vlan_result = api.deleteVlan('openstack_test')
    print vlan_result.isFailed()
    print vlan_result.getErrCode()
    print vlan_result.getErrStr()

    netns = NetnsInfo('')
    netns.name = 'test123'
    netns.tenant = 'test321'
    netns.appgId = 2
    macvlan = MacvlanInfo('')
    macvlan.name = 'test123'
    macvlan.ifname = 'eth2.222'
    macvlan.mac = 'f3:f2:f1:ff:01:23'
    macvlan.netnsId = 123

    #print api.updateNetns('test123', netns);
    print api.updateMacvlan('test123', macvlan);
    '''

