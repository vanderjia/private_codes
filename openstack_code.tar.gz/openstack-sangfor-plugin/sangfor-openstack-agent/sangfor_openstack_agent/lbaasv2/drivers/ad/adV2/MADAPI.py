# -*- coding: utf-8 -*-
# Copyright (c) 2008-2020, AD SANGFOR
# Filename: MADAPI.py
# 定义了 MADAPI PYTHON SDK 对外的接口
import urllib
import json
#引入代理机制，转换旧版新版api
from oldapi.vad_proxy_ctl import VadProxy
from api.Configuration import Configuration
from api.APIException import APIException
from api.http.HttpClient import HttpClient, RequestMethod, HttpClientException
from api.LogInfo import LogInfo
from api.VlanInfo import VlanInfo
from api.BondInfo import BondInfo
from api.SwitchInfo import SwitchInfo
from api.VADInfo import VADInfo
from api.ImageInfo import ImageInfo
from api.ResInfo import ResInfo
from api.ServInfo import ServInfo
from api.IPGroup import IPGroup
from api.PersistInfo import PersistInfo
from api.MonitorInfo import MonitorInfo
from api.PoolInfo import PoolInfo
from api.NodeInfo import NodeInfo
from api.VSInfo import VSInfo
from api.WanInfo import WanInfo
from api.LanInfo import LanInfo
from api.VxlanInfo import VxlanInfo
from api.SrouteInfo import SrouteInfo
from api.NetifIP import NetifIP
from api.NetifInfo import NetifInfo
from api.SnatSet import SnatSet
from api.AclInfo import AclInfo
from api.ErrorInfo import ErrInfo

class ADAPI:
    '''
    应用jsontoxml方案的adapi接口，基本可以复用MADAPI的方法
    '''

    def __init__(self, username, password, ip, port, timeout=20):
        '''
        初始化类
        @username ： 用户名称
        @password ： 用户密码
        @ip       ： 设备IP
        @port     ： 设备端口
        @timeout  :  超时时间设置
        @return
        '''
        #config = Configuration(username, password, ip, port, timeout)
        #self.config = config
        self.addr = ip
        self.port = port
        self.username = username
        self.passwd = password

    @classmethod
    def getVersion(cls):
        '''
        获取MADAPI的版本信息
        '''
        import __init__
        return __init__.__version__

    def setConfig(self, configuration=None):
        '''
        用于初始化MADAPI SDK所需信息。
        包括AD IP、AD端口(若为None，默认设置为443)、用户名、密码
        @param configuration 初始化信息类。
        @type Configuration
        @return
        @rtype
        '''
        if configuration is None:
            return
        self.config = configuration

    def makeJson(self, data):
        '''
        将数据转换成json格式
        @data list类型数据
        @return json字符串
        '''
        return json.dumps(data, ensure_ascii=False)

    def makeParams(self, data):
        '''
        用于组合数据
        @data dict/list类型数据
        @rtype
        '''
        params = {
            'data': json.dumps(data, ensure_ascii=False)
        }
        return params

    def proxyProc(self, params, apiFunc):
        '''
        代理请求处理接口
        '''
        
        proxy = VadProxy(params)
        try:
            result = proxy.vadProxyHandle()
            return apiFunc(result);
        except Exeption as e:
            print e

    def makeADParams(self, api, params=''):
        '''
        组装VAD代理接口信息
        @api 要调用的ADAPI接口名称
        @params 传给ADAPI的参数
        {
            'ad_name': VAD名称,
            'function': 调用的ADAPI，
            'args': 要给ADAPI接口的参数
        }
        '''
        adAuth = {
            'adaddr': self.addr,
            'adport': self.port,
            'adusername': self.username,
            'adpasswd': self.passwd,
            'function': api,
            'args': params
        }
        return adAuth

    def createServInfo(self, servInfo):
        '''
        新建服务配置
        @servInfo ServInfo类型数据
        '''
        key = ServInfo.servInfoToDict(servInfo)
        params = self.makeADParams('createServ', key)
        return self.proxyProc(
            params,
            ServInfo
            )

    def delServInfo(self, name):
        '''
        删除服务配置
        @name 要删除的服务配置名称
        '''
        key = {'name': name}
        params = self.makeADParams('delServ', key)
        return self.proxyProc(
            params,
            ServInfo
            )

    def addServPort(self, servInfo):
        '''
        往服务配置中添加端口
        @servInfo ServInfo类型数据
        '''
        key = ServInfo.servInfoToDict(servInfo)
        params = self.makeADParams('addServPort', key)
        return self.proxyProc(
            params,
            ServInfo
            )

    def delServPort(self, servInfo):
        '''
        从服务配置中删除端口
        @servInfo ServInfo类型数据
        '''
        key = ServInfo.servInfoToDict(servInfo)
        params = self.makeADParams('delServPort', key)
        return self.proxyProc(
            params,
            ServInfo
            )

    def getServInfo(self, name):
        '''
        根据服务名称获取服务
        @name 服务名称
        '''
        key = {'name': name}
        params = self.makeADParams('getServInfo', key)
        return self.proxyProc(
            params,
            ServInfo.generatingServInfo
            )

    def getServInfoList(self):
        '''
        获取服务信息列表
        '''
        params = self.makeADParams('getServList')
        return self.proxyProc(
            params,
            ServInfo.generatingServList
            )

    def createIPGroup(self, ipGroup):
        '''
        新建IP组配置
        @ipGroup IPGroup类型数据
        '''
        key = IPGroup.ipGroupToDict(ipGroup)
        params = self.makeADParams('createIpGroup', key)
        return self.proxyProc(
            params,
            IPGroup
            )

    def delIPGroup(self, name):
        '''
        删除IP组配置
        @name IP组名称
        '''
        key = {'name': name}
        params = self.makeADParams('delIpGroup', key)
        return self.proxyProc(
            params,
            IPGroup
            )

    def addIPInfo(self, ipInfo):
        '''
        往IP配置中添加ip
        @ipInfo IPInfo类型数据
        '''
        key = IPGroup.ipGroupToDict(ipInfo)
        params = self.makeADParams('addIp', key)
        return self.proxyProc(
            params,
            IPGroup
            )

    def delIPInfo(self, ipInfo):
        '''
        从IP配置中删除ip
        @ipInfo IPInfo类型数据
        '''
        key = IPGroup.ipGroupToDict(ipInfo)
        params = self.makeADParams('delIp', key)
        return self.proxyProc(
            params,
            IPGroup
            )

    def getIPGroup(self, name):
        '''
        根据名称获取IP组配置
        '''
        key = {'name': name}
        params = self.makeADParams('getIpGroupInfo', key)
        return self.proxyProc(
            params,
            IPGroup.generatingIPGroup
            )

    def getIPGroupList(self):
        '''
        获取IP组信息列表
        '''
        params = self.makeADParams('getIpGroupList')
        return self.proxyProc(
            params,
            IPGroup.generatingIPGroupList
            )

    def createPersist(self, pers):
        '''
        新建会话保持配置
        @pers PersistInfo类型数据
        '''
        key = PersistInfo.persistInfoToDict(pers)
        params = self.makeADParams('createPersist', key)
        return self.proxyProc(
            params,
            PersistInfo
            )

    def updatePersist(self, name, pers):
        '''
        更新会话保持配置
        @name 会话保持名称
        @pers PersistInfo类型数据
        '''
        key = PersistInfo.persistInfoToDict(pers)
        key['persist_name'] = name
        params = self.makeADParams('updatePersist', key)
        return self.proxyProc(
            params,
            PersistInfo
            )

    def delPersist(self, name):
        '''
        删除会话保持配置
        @name 会话保持名称
        '''
        key = {'name': name}
        params = self.makeADParams('delPersist', key)
        return self.proxyProc(
            params,
            PersistInfo
            )

    def getPersistInfo(self, name):
        '''
        获取会话保持信息
        @name 会话保持名称
        '''
        key = {'name': name}
        params = self.makeADParams('getPersistInfo', key)
        return self.proxyProc(
            params,
            PersistInfo.generatingPersistInfo
            )

    def getPersistList(self):
        '''
        获取会话保持信息列表
        '''
        params = self.makeADParams('getPersistList')
        return self.proxyProc(
            params,
            PersistInfo.generatingPersistList
            )

    def createMonitorInfo(self, monitor):
        '''
        新建监视器
        @monitor MonitorInfo类型信息
        '''
        key = MonitorInfo.monitorInfoToDict(monitor)
        params = self.makeADParams('createNodeMonitor', key)
        return self.proxyProc(
            params,
            MonitorInfo
            )

    def updateMonitorInfo(self, name, monitor):
        '''
        更新监视器
        @name 监视器名称
        @monitor MonitorInfo类型信息
        '''
        key = MonitorInfo.monitorInfoToDict(monitor)
        key['monitor_name'] = name
        params = self.makeADParams('updateNodeMonitor', key)
        return self.proxyProc(
            params,
            MonitorInfo
            )

    def delMonitorInfo(self, name):
        '''
        删除监视器配置
        @name 监视器名称
        '''
        key = {'name': name}
        params = self.makeADParams('delNodeMonitor', key)
        return self.proxyProc(
            params,
            MonitorInfo
            )

    def getMonitorInfo(self, name):
        '''
        获取监视器信息
        @name 监视器名称
        '''
        key = {'name': name}
        params = self.makeADParams('getNodeMonitorInfo', key)
        return self.proxyProc(
            params,
            MonitorInfo.generatingMonitorInfo
            )

    def getMonitorList(self):
        '''
        获取监视器信息列表
        '''
        params = self.makeADParams('getNodeMonitorList')
        return self.proxyProc(
            params,
            MonitorInfo.generatingMonitorList
            )

    def createPoolInfo(self, pool):
        '''
        新建节点池
        @pool PoolInfo类型信息
        '''
        key = PoolInfo.poolInfoToDict(pool)
        params = self.makeADParams('createNodePool', key)
        return self.proxyProc(
            params,
            PoolInfo
            )

    def updatePoolInfo(self, name, pool):
        '''
        更新节点池
        @name 要更新配置的节点池名称
        @pool PoolInfo类型信息
        '''
        key = PoolInfo.poolInfoToDict(pool)
        key['pool_name'] = name
        params = self.makeADParams('updateNodePool', key)
        return self.proxyProc(
            params,
            PoolInfo
            )

    def delPoolInfo(self, name):
        '''
        删除节点池配置
        @name 节点池名称
        '''
        key = {'name': name}
        params = self.makeADParams('delNodePool', key)
        return self.proxyProc(
            params,
            PoolInfo
            )

    def addMonitor(self, poolName, monitorName):
        '''
        往节点池添加监视器
        @poolName 节点池名称
        @monitorName 监视器名称
        '''
        key = {'name': poolName, 'monitor': monitorName}
        params = self.makeADParams('addPoolMonitor', key)
        return self.proxyProc(
            params,
            PoolInfo
            )

    def delMonitor(self, poolName, monitorName):
        '''
        从节点池中删除监视器
        @poolName 节点池名称
        @monitorName 监视器名称
        '''
        key = {'name': poolName, 'monitor': monitorName}
        params = self.makeADParams('delPoolMonitor', key)
        return self.proxyProc(
            params,
            PoolInfo
            )

    def getPoolInfo(self, name):
        '''
        获取节点池信息
        @name 节点池名称
        '''
        key = {'name': name}
        params = self.makeADParams('getNodePoolInfo', key)
        return self.proxyProc(
            params,
            PoolInfo.generatingPoolInfo
            )

    def getPoolList(self):
        '''
        获取节点池信息列表
        '''
        params = self.makeADParams('getNodePoolList')
        return self.proxyProc(
            params,
            PoolInfo.generatingPoolList
            )

    def createNode(self, poolName, node):
        '''
        往节点池添加节点
        @poolName 节点池名称
        @node NodeInfo类型信息
        '''
        key = NodeInfo.nodeInfoToDict(node)
        key['name'] = poolName
        params = self.makeADParams('createNode', key)
        return self.proxyProc(
            params,
            NodeInfo
            )

    def updateNode(self, poolName, nodeIP, nodePort, node):
        '''
        更新节点池中的节点
        @poolName 节点池名称
        @nodeIP 节点IP
        @nodePort 节点端口
        @node NodeInfo类型信息
        '''
        key = NodeInfo.nodeInfoToDict(node)
        key['name'] = poolName
        key['node_ip'] = nodeIP
        key['node_port'] = nodePort
        params = self.makeADParams('updateNode', key)
        return self.proxyProc(
            params,
            NodeInfo
            )

    def delNode(self, poolName, nodeIP, nodePort):
        '''
        从节点池删除节点
        @poolName 节点池名称
        @nodeIP 节点IP
        @nodePort 节点端口
        '''
        key = {'name': poolName, 'ip': nodeIP, 'port': nodePort}
        params = self.makeADParams('delNode', key)
        return self.proxyProc(
            params,
            NodeInfo
            )

    def getNodeInfo(self, poolName, nodeIP, nodePort):
        '''
        获取节点信息
        @poolName 节点池名称
        @nodeIP 节点IP
        @nodePort 节点端口
        '''
        key = {'name': poolName, 'ip': nodeIP, 'port': nodePort}
        params = self.makeADParams('getNodeInfo', key)
        return self.proxyProc(
            params,
            NodeInfo.generatingNodeInfo
            )

    def getNodeList(self, poolName):
        '''
        获取节点信息列表
        @poolName 节点池名称
        '''
        key = {'name': poolName}
        params = self.makeADParams('getNodeList', key)
        return self.proxyProc(
            params,
            NodeInfo.generatingNodeList
            )

    def getNodeStatus(self, poolName):
        '''
        获取节点状态列表
        @poolName 节点池名称
        '''
        key = {'name': poolName}
        params = self.makeADParams('getNodesStatus', key)
        return self.proxyProc(
            params,
            NodeInfo.generatingNodeStatus
            )

    def createVS(self, vs):
        '''
        新建虚拟服务
        @vs VSInfo类型数据
        '''
        key = VSInfo.vsInfoToDict(vs)
        params = self.makeADParams('createVs', key)
        return self.proxyProc(
            params,
            VSInfo
            )

    def updateVS(self, name, vs):
        '''
        更新虚拟服务
        @name 虚拟服务名称
        @vs VSInfo类型数据
        '''
        key = VSInfo.vsInfoToDict(vs)
        key['vs_name'] = name
        params = self.makeADParams('updateVs', key)
        return self.proxyProc(
            params,
            VSInfo
            )

    def delVS(self, name):
        '''
        删除虚拟服务
        @name 虚拟服务名称
        '''
        key = {'name': name}
        params = self.makeADParams('delVs', key)
        return self.proxyProc(
            params,
            VSInfo
            )

    def getVSInfo(self, name):
        '''
        获取虚拟服务信息
        @name 虚拟服务名称
        '''
        key = {'name': name}
        params = self.makeADParams('getVsInfo', key)
        return self.proxyProc(
            params,
            VSInfo.generatingVSInfo
            )

    def getVSStatus(self):
        '''
        获取虚拟服务状态
        '''
        params = self.makeADParams('getVsStatus')
        return self.proxyProc(
            params,
            VSInfo.generatingVSStatus
            )

    def getVSList(self):
        '''
        获取虚拟服务列表
        '''
        params = self.makeADParams('getVsList')
        return self.proxyProc(
            params,
            VSInfo.generatingVSList
            )

    def createWanInfo(self, wanInfo):
        '''
        新建wan口
        @wanInfo WanInfo类型数据
        '''
        key = WanInfo.wanInfoToDict(wanInfo)
        params = self.makeADParams('createWanInfo', key)
        return self.proxyProc(
            params,
            WanInfo
            )

    def updateWanInfo(self, name, wanInfo):
        '''
        更新wan口信息
        @name 需要更新的wan口名称
        @wanInfo WanInfo类型数据
        '''
        key = WanInfo.wanInfoToDict(wanInfo)
        key['wan_name'] = name
        params = self.makeADParams('updateWanInfo', key)
        return self.proxyProc(
            params,
            WanInfo
            )

    def deleteWanInfo(self, name):
        '''
        删除wan口配置
        @name 需要删除的wan口名称
        '''
        key = {'name': name}
        params = self.makeADParams('deleteWanInfo', key)
        return self.proxyProc(
            params,
            WanInfo
            )

    def getWanInfo(self, name):
        '''
        获取wan口配置ip信息列表
        @name wan口名称
        '''
        key = {'name': name}
        params = self.makeADParams('getWanInfo', key)
        return self.proxyProc(
            params,
            WanInfo.generatingWanInfo
            )

    def getWanList(self):
        '''
        获取wan口配置名称信息列表
        '''
        params = self.makeADParams('getWanList')
        return self.proxyProc(
            params,
            WanInfo.generatingWanList
            )

    def createLanInfo(self, lanInfo):
        '''
        新建lan口
        @lanInfo lanInfo类型数据
        '''
        key = LanInfo.lanInfoToDict(lanInfo)
        params = self.makeADParams('createLanInfo', key)
        return self.proxyProc(
            params,
            LanInfo
            )

    def updateLanInfo(self, name, lanInfo):
        '''
        更新lan口信息
        @name 需要更新的lan口名称
        @lanInfo LanInfo类型数据
        '''
        key = LanInfo.lanInfoToDict(lanInfo)
        key['lan_name'] = name
        params = self.makeADParams('updateLanInfo', key)
        return self.proxyProc(
            params,
            LanInfo
            )

    def deleteLanInfo(self, name):
        '''
        删除lan口配置
        @name 需要删除的lan口名称
        '''
        key = {'name': name}
        params = self.makeADParams('deleteLanInfo', key)
        return self.proxyProc(
            params,
            LanInfo
            )

    def getLanInfo(self, name):
        '''
        获取lan口配置ip信息列表
        @name lan口名称
        '''
        key = {'name': name}
        params = self.makeADParams('getLanInfo', key)
        return self.proxyProc(
            params,
            LanInfo.generatingLanInfo
            )

    def getLanList(self):
        '''
        获取lan口配置名称信息列表
        '''
        params = self.makeADParams('getLanList')
        return self.proxyProc(
            params,
            LanInfo.generatingLanList
            )

    def createSnatSet(self, snatSet):
        '''
        新建snat地址集
        @snatSet SnatSet类型数据
        '''
        key = SnatSet.snatSetToDict(snatSet)
        params = self.makeADParams('createSnatSet', key)
        return self.proxyProc(
            params,
            SnatSet
            )

    def updateSnatSet(self, name, snatSet):
        '''
        更新snat地址集配置
        @name 需要更新的snat地址集名称
        @snatSet SnatSet类型数据
        '''
        key = SnatSet.snatSetToDict(snatSet)
        key['snat_name'] = name
        params = self.makeADParams('updateSnatSet', key)
        return self.proxyProc(
            params,
            SnatSet
            )

    def deleteSnatSet(self, name):
        '''
        删除snat地址集配置
        @name 需要删除的snat地址集名称
        '''
        key = {'name': name}
        params = self.makeADParams('deleteSnatSet', key)
        return self.proxyProc(
            params,
            SnatSet
            )

    def getSnatSet(self, name):
        '''
        获取snat地址集
        @name snat地址集名称
        '''
        key = {'name': name}
        params = self.makeADParams('getSnatSet', key)
        return self.proxyProc(
            params,
            SnatSet.generatingSnatSet
            )

    def getSnatSetList(self):
        '''
        获取snat地址集名称信息列表
        '''
        params = self.makeADParams('getSnatSetList')
        return self.proxyProc(
            params,
            SnatSet.generatingSnatSetList
            )

    def createAcl(self, aclInfo):
        '''
        创建高级ACL
        @AclInfo AclInfo类型数据
        '''
        key = AclInfo.aclInfoToDict(aclInfo)
        params = self.makeADParams('createAcl', key)
        return self.proxyProc(
            params,
            AclInfo
            )

    def updateAcl(self, name, aclInfo):
        '''
        更新高级ACL
        @name  高级ACL名称
        @AclInfo AclInfo类型数据
        '''
        key = AclInfo.aclInfoToDict(aclInfo)
        key['acl_name'] = name
        params = self.makeADParams('updateAcl', key)
        return self.proxyProc(
            params,
            AclInfo
            )

    def deleteAcl(self, name):
        '''
        删除高级ACL
        @name  高级ACL名称
        '''
        key = {'name': name}
        params = self.makeADParams('deleteAcl', key)
        return self.proxyProc(
            params,
            AclInfo
            )

    def getAclInfo(self, name):
        '''
        获取高级ACL配置
        @name 高级ACL名称
        '''
        key = {'name': name}
        params = self.makeADParams('getAclInfo', key)
        return self.proxyProc(
            params,
            AclInfo.generatingAclInfo
            )

    def getAclList(self):
        '''
        获取高级ACL配置列表
        '''
        params = self.makeADParams('getAclList')
        return self.proxyProc(
            params,
            AclInfo.generatingAclList
            )

class MADAPI:
    '''
    包含 MADAPI PYTHON SDK 对外的接口
    '''

    def __init__(self, username, password, ip, port, timeout=20):
        '''
        初始化类
        @username ： 用户名称
        @password ： 用户密码
        @ip       ： 设备IP
        @port     ： 设备端口
        @timeout  :  超时时间设置
        @return
        '''
        config = Configuration(username, password, ip, port, timeout)
        self.config = config

    @classmethod
    def getVersion(cls):
        '''
        获取MADAPI的版本信息
        '''
        import __init__
        return __init__.__version__

    def setConfig(self, configuration=None):
        '''
        用于初始化MADAPI SDK所需信息。
        包括AD IP、AD端口(若为None，默认设置为443)、用户名、密码
        @param configuration 初始化信息类。
        @type Configuration
        @return
        @rtype
        '''
        if configuration is None:
            return
        self.config = configuration

    def makeJson(self, data):
        '''
        将数据转换成json格式
        @data list类型数据
        @return json字符串
        '''
        return json.dumps(data, ensure_ascii=False)

    def makeParams(self, data):
        '''
        用于组合数据
        @data dict/list类型数据
        @rtype
        '''
        params = {
            'data': json.dumps(data, ensure_ascii=False)
        }
        return params

    def httpRequest(
        self,
        url,
        params,
        requestMethod):
        '''
        用于发送数据并且接收数据
        @url 发送链接
        @params 发送的数据
        @requestMethod 请求方式
        @rtype
        '''
        httpBody = None
        try:
            httpBody = HttpClient.httpClient(
                url,
                params,
                self.config,
                requestMethod
            )
            if httpBody is None:
                raise APIException(4, "unknown error")
            return httpBody
        except (HttpClientException, APIException) as e:
            raise APIException(e.code, e.reason)
        except Exception as e:
            raise Exception(e)

    def mapiProc(self, params, url, requestMethod, apiFunc):
        '''
        发送http请求，并获取结果
        @params 要发送的数据，post接口时为dict/list类型数据
                get接口时为url参数
        @url 为每个接口对应的uri
        @requestMethod 请求方法， POST/GET
        @apiFunc GET/POST接口时，返回数据的处理
        '''
        # POST接口的数据要组装
        if requestMethod == RequestMethod.POST:
            params = self.makeParams(params)
        LogInfo.makeLogger(params)
        try:
            # 发送请求，并获取结果
            result = self.httpRequest(
                url,
                params,
                requestMethod
            )
            LogInfo.makeLogger(result)
            if result is None or apiFunc is None:
                raise APIException(4, "unknown error")
            else:
                return apiFunc(result)
        except APIException as e:
            reason = str(e.reason)
            code = APIException.codeTransfer(e)
            LogInfo.makeLogger("mapiProc: " + str(code) + "," + reason)
            raise APIException(code, reason)
        except Exception as e:
            raise Exception(e)

    def createVlan(self, vlanInfo):
        '''
        新建vlan
        @vlanInfo VlanInfo类型数据
        '''
        return self.mapiProc(
            VlanInfo.vlanInfoToDict(vlanInfo),
            self.config.createVlanURI,
            RequestMethod.POST,
            VlanInfo
            )

    def updateVlan(self, name, vlanInfo):
        '''
        更新vlan
        @name vlan名称
        @vlanInfo VlanInfo类型数据
        '''
        params = {}
        params['name'] = name
        params['args'] = VlanInfo.vlanInfoToDict(vlanInfo)
        return self.mapiProc(
            params,
            self.config.updateVlanURI,
            RequestMethod.POST,
            VlanInfo
            )

    def deleteVlan(self, name):
        '''
        删除vlan
        @name 要删除的配置名称
        '''
        params = {}
        params['name'] = name
        return self.mapiProc(
            params,
            self.config.deleteVlanURI,
            RequestMethod.POST,
            VlanInfo
            )

    def getVlanInfo(self, name):
        '''
        获取vlan信息
        @name vlan名称
        '''
        params = 'name=' + urllib.quote_plus(name)
        return self.mapiProc(
            params,
            self.config.getVlanURI,
            RequestMethod.GET,
            VlanInfo.generatingVlanInfo
            )

    def getVlanList(self):
        '''
        获取vlan列表
        '''
        return self.mapiProc(
            None,
            self.config.getVlanListURI,
            RequestMethod.GET,
            VlanInfo.generatingVlanInfoList
            )

    def listNetVlan(self):
        '''
        获取哪些网口可以被vlan引用
        '''
        return self.mapiProc(
            None,
            self.config.listNetVlanURI,
            RequestMethod.GET,
            NetifInfo
            )

    def createBond(self, bondInfo):
        '''
        新建bond
        @bondInfo BondInfo类型数据
        '''
        return self.mapiProc(
            BondInfo.bondInfoToDict(bondInfo),
            self.config.createBondURI,
            RequestMethod.POST,
            BondInfo
            )

    def updateBond(self, name, bondInfo):
        '''
        更新bond
        @name bond名称
        @bondInfo BondInfo类型数据
        '''
        params = {}
        params['name'] = name
        params['args'] = BondInfo.bondInfoToDict(bondInfo)
        return self.mapiProc(
            params,
            self.config.updateBondURI,
            RequestMethod.POST,
            BondInfo
            )

    def deleteBond(self, name):
        '''
        删除bond
        @name 要删除的配置名称
        '''
        params = {}
        params['name'] = name
        return self.mapiProc(
            params,
            self.config.deleteBondURI,
            RequestMethod.POST,
            BondInfo
            )

    def getBondInfo(self, name):
        '''
        获取bond信息
        @name bond名称
        '''
        params = 'name=' + urllib.quote_plus(name)
        return self.mapiProc(
            params,
            self.config.getBondURI,
            RequestMethod.GET,
            BondInfo.generatingBondInfo
            )

    def getBondList(self):
        '''
        获取Bond列表
        '''
        return self.mapiProc(
            None,
            self.config.getBondListURI,
            RequestMethod.GET,
            BondInfo.generatingBondInfoList
            )

    def listNetBond(self):
        '''
        获取哪些网口可以被bond引用
        '''
        return self.mapiProc(
            None,
            self.config.listNetBondURI,
            RequestMethod.GET,
            NetifInfo
            )

    def createSwitch(self, switchInfo):
        '''
        新建switch
        @switchInfo SwitchInfo类型数据
        '''
        return self.mapiProc(
            SwitchInfo.switchInfoToDict(switchInfo),
            self.config.createSwitchURI,
            RequestMethod.POST,
            SwitchInfo
            )

    def updateSwitch(self, name, switchInfo):
        '''
        更新switch
        @switchInfo SwitchInfo类型数据
        '''
        params = {}
        params['name'] = name
        params['args'] = SwitchInfo.switchInfoToDict(switchInfo)
        return self.mapiProc(
            params,
            self.config.updateSwitchURI,
            RequestMethod.POST,
            SwitchInfo
            )

    def deleteSwitch(self, name):
        '''
        删除switch
        @name 需要删除的配置名称
        '''
        params = {}
        params['name'] = name
        return self.mapiProc(
            params,
            self.config.deleteSwitchURI,
            RequestMethod.POST,
            SwitchInfo
            )

    def getSwitchInfo(self, name):
        '''
        获取switch信息
        @name switch名称
        '''
        params = 'name=' + urllib.quote_plus(name)
        return self.mapiProc(
            params,
            self.config.getSwitchURI,
            RequestMethod.GET,
            SwitchInfo.generatingSwitchInfo
            )

    def getSwitchList(self):
        '''
        获取switch列表
        '''
        return self.mapiProc(
            None,
            self.config.getSwitchListURI,
            RequestMethod.GET,
            SwitchInfo.generatingSwitchInfoList
            )

    def listNetSwitch(self):
        '''
        获取哪些网口可以被switch引用
        '''
        return self.mapiProc(
            None,
            self.config.listNetSwitchURI,
            RequestMethod.GET,
            NetifInfo
            )

    def createVxlan(self, vxlanInfo):
        '''
        新建vxlan信息
        @vxlanInfo VxlanInfo类型数据
        '''
        return self.mapiProc(
            VxlanInfo.vxlanInfoToDict(vxlanInfo),
            self.config.createVxlanURI,
            RequestMethod.POST,
            VxlanInfo
            )

    def updateVxlan(self, name, vxlanInfo):
        '''
        更新vxlan信息
        @name vxlan配置名称
        @vxlanInfo VxlanInfo类型数据
        '''
        params = {}
        params['name'] = name
        params['args'] = VxlanInfo.vxlanInfoToDict(vxlanInfo)
        return self.mapiProc(
            params,
            self.config.updateVxlanURI,
            RequestMethod.POST,
            VxlanInfo
            )

    def deleteVxlan(self, name):
        '''
        删除vxlan
        @id 需要删除的配置id
        '''
        params = {}
        params['name'] = name
        return self.mapiProc(
            params,
            self.config.deleteVxlanURI,
            RequestMethod.POST,
            VxlanInfo
            )

    def getVxlan(self, name):
        '''
        获取vxlan信息
        @name vxlan名称
        '''
        params = 'name=' + urllib.quote_plus(name)
        return self.mapiProc(
            params,
            self.config.getVxlanURI,
            RequestMethod.GET,
            VxlanInfo.generatingVxlanInfo
            )

    def getVxlanList(self):
        '''
        获取vxlan列表
        '''
        return self.mapiProc(
            None,
            self.config.getVxlanListURI,
            RequestMethod.GET,
            VxlanInfo.generatingVxlanList
            )

    def listNetVxlan(self):
        '''
        获取哪些网口可以被vxlan引用
        '''
        return self.mapiProc(
            None,
            self.config.listNetVxlanURI,
            RequestMethod.GET,
            NetifInfo
            )

    def createSroute(self, srouteInfo):
        '''
        新建静态路由信息
        @srouteInfo SrouteInfo类型数据
        '''
        return self.mapiProc(
            SrouteInfo.srouteInfoToDict(srouteInfo),
            self.config.createSrouteURI,
            RequestMethod.POST,
            SrouteInfo
            )

    def updateSroute(self, srouteInfo):
        '''
        更新静态路由信息
        @srouteInfo SrouteInfo类型数据
        '''
        return self.mapiProc(
            SrouteInfo.srouteInfoToDict(srouteInfo),
            self.config.updateSrouteURI,
            RequestMethod.POST,
            SrouteInfo
            )

    def deleteSroute(self, id):
        '''
        删除静态路由
        @id 需要删除的配置id
        '''
        idList = []
        idList.append(id)
        return self.mapiProc(
            idList,
            self.config.deleteSrouteURI,
            RequestMethod.POST,
            SrouteInfo
            )

    def getSrouteList(self):
        '''
        获取静态路由列表
        '''
        return self.mapiProc(
            None,
            self.config.getSrouteListURI,
            RequestMethod.GET,
            SrouteInfo.generatingSrouteList
            )

    def createNetifIP(self, netifIP):
        '''
        新建接口IP信息
        @netifInfo NetifIP类型数据
        '''
        return self.mapiProc(
            NetifIP.netifIPToDict(netifIP),
            self.config.createNetifIPURI,
            RequestMethod.POST,
            NetifIP
            )

    def updateNetifIP(self, ifname, netifIP):
        '''
        更新接口IP信息
        @ifname 应用物理接口，如eth1
        @netifIP NetifIP类型数据
        '''
        params = {}
        params['name'] = ifname
        params['args'] = NetifIP.netifIPToDict(netifIP)
        return self.mapiProc(
            params,
            self.config.updateNetifIPURI,
            RequestMethod.POST,
            NetifIP
            )

    def deleteNetifIP(self, ifname):
        '''
        删除接口IP
        @ifname 需要删除的配置物理网口名称
        '''
        params = {}
        params['name'] = ifname
        return self.mapiProc(
            params,
            self.config.deleteNetifIPURI,
            RequestMethod.POST,
            NetifIP
            )

    def getNetifIPList(self):
        '''
        获取接口IP列表
        '''
        return self.mapiProc(
            None,
            self.config.getNetifIPListURI,
            RequestMethod.GET,
            NetifIP.generatingNetifIPList
            )

    def listNetNetifIP(self):
        '''
        获取哪些网口可以被接口IP引用
        '''
        return self.mapiProc(
            None,
            self.config.listNetNetifIPURI,
            RequestMethod.GET,
            NetifInfo
            )

    def createVAD(self, vadInfo):
        '''
        新建VAD
        @vadInfo VADInfo类型数据
        '''
        return self.mapiProc(
            VADInfo.VADInfoToDict(vadInfo),
            self.config.createVadURI,
            RequestMethod.POST,
            VADInfo
            )

    def updateVAD(self, name, vadInfo):
        '''
        更新VAD
        @name VAD名称
        @vadInfo VADInfo类型数据
        '''
        params = {}
        params['name'] = name
        params['args'] = VADInfo.VADInfoToDict(vadInfo)
        return self.mapiProc(
            params,
            self.config.updateVadURI,
            RequestMethod.POST,
            VADInfo
            )

    def deleteVAD(self, name):
        '''
        删除VAD
        @name 要删除的配置名称
        '''
        params = {}
        params['name'] = name
        return self.mapiProc(
            params,
            self.config.deleteVadURI,
            RequestMethod.POST,
            VADInfo
            )

    def startVAD(self, name):
        '''
        启动VAD
        @name 要启动的VAD配置名称
        '''
        params = {}
        params['name'] = name
        return self.mapiProc(
            params,
            self.config.startVadURI,
            RequestMethod.POST,
            VADInfo
            )

    def stopVAD(self, name):
        '''
        关闭VAD
        @name 要关闭的VAD配置名称
        '''
        params = {}
        params['name'] = name
        return self.mapiProc(
            params,
            self.config.stopVadURI,
            RequestMethod.POST,
            VADInfo
            )

    def closeVAD(self, name):
        '''
        强制关闭VAD
        @name 要关闭的VAD配置名称
        '''
        params = {}
        params['name'] = name
        return self.mapiProc(
            params,
            self.config.closeVadURI,
            RequestMethod.POST,
            VADInfo
            )

    def restartVAD(self, name):
        '''
        重启VAD
        @name 要重启的VAD配置名称
        '''
        params = {}
        params['name'] = name
        return self.mapiProc(
            params,
            self.config.restartVadURI,
            RequestMethod.POST,
            VADInfo
            )

    def getVADInfo(self, name):
        '''
        获取VAD信息
        @name VAD名称
        '''
        params = 'name=' + urllib.quote_plus(name)
        return self.mapiProc(
            params,
            self.config.getVadURI,
            RequestMethod.GET,
            VADInfo.generatingVADInfo
            )

    def getVADInfoList(self):
        '''
        获取VAD列表
        '''
        return self.mapiProc(
            None,
            self.config.getVadListURI,
            RequestMethod.GET,
            VADInfo.generatingVADInfoList
            )

    def listNetVAD(self):
        '''
        获取哪些网口可以被vlan引用
        '''
        return self.mapiProc(
            None,
            self.config.listNetVadURI,
            RequestMethod.GET,
            NetifInfo
            )

    def getMadResInfo(self):
        '''
        获取MAD资源信息
        '''
        return self.mapiProc(
            None,
            self.config.getMadResInfoURI,
            RequestMethod.GET,
            ResInfo.generatingResInfo
            )

    def getImageInfoList(self):
        '''
        获取镜像信息列表
        '''
        return self.mapiProc(
            None,
            self.config.getImageListURI,
            RequestMethod.GET,
            ImageInfo.generatingImageInfoList
            )

    def setVADAuthInfo(self, name):
        '''
        设置VAD身份验证信息
        @name VAD名称
        '''
        self.authInfo = name

    def makeVADParams(self, api, params=''):
        '''
        组装VAD代理接口信息
        @api 要调用的ADAPI接口名称
        @params 传给ADAPI的参数
        {
            'ad_name': VAD名称,
            'function': 调用的ADAPI，
            'args': 要给ADAPI接口的参数
        }
        '''
        vadAuth = {
            'ad_name': self.authInfo,
            'function': api,
            'args': params
        }
        return vadAuth

    def vadProc(self, params, url, method, apiFunc):
        '''
        VAD代理接口
        @params 要发送的数据
        @url url
        @method GET/POST接口
        @apiFunc   GET/POST接口时的返回数据处理接口
        '''
        retData = self.mapiProc(
            params,
            url,
            method,
            apiFunc
            )
        if retData is None or apiFunc is None:
                raise APIException(4, "unknown error")
        else:
            return retData

    def createServInfo(self, servInfo):
        '''
        新建服务配置
        @servInfo ServInfo类型数据
        '''
        key = ServInfo.servInfoToDict(servInfo)
        params = self.makeVADParams('createServ', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            ServInfo
            )

    def delServInfo(self, name):
        '''
        删除服务配置
        @name 要删除的服务配置名称
        '''
        key = {'name': name}
        params = self.makeVADParams('delServ', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            ServInfo
            )

    def addServPort(self, servInfo):
        '''
        往服务配置中添加端口
        @servInfo ServInfo类型数据
        '''
        key = ServInfo.servInfoToDict(servInfo)
        params = self.makeVADParams('addServPort', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            ServInfo
            )

    def delServPort(self, servInfo):
        '''
        从服务配置中删除端口
        @servInfo ServInfo类型数据
        '''
        key = ServInfo.servInfoToDict(servInfo)
        params = self.makeVADParams('delServPort', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            ServInfo
            )

    def getServInfo(self, name):
        '''
        根据服务名称获取服务
        @name 服务名称
        '''
        key = {'name': name}
        params = self.makeVADParams('getServInfo', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            ServInfo.generatingServInfo
            )

    def getServInfoList(self):
        '''
        获取服务信息列表
        '''
        params = self.makeVADParams('getServList')
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            ServInfo.generatingServList
            )

    def createIPGroup(self, ipGroup):
        '''
        新建IP组配置
        @ipGroup IPGroup类型数据
        '''
        key = IPGroup.ipGroupToDict(ipGroup)
        params = self.makeVADParams('createIpGroup', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            IPGroup
            )

    def delIPGroup(self, name):
        '''
        删除IP组配置
        @name IP组名称
        '''
        key = {'name': name}
        params = self.makeVADParams('delIpGroup', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            IPGroup
            )

    def addIPInfo(self, ipInfo):
        '''
        往IP配置中添加ip
        @ipInfo IPInfo类型数据
        '''
        key = IPGroup.ipGroupToDict(ipInfo)
        params = self.makeVADParams('addIp', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            IPGroup
            )

    def delIPInfo(self, ipInfo):
        '''
        从IP配置中删除ip
        @ipInfo IPInfo类型数据
        '''
        key = IPGroup.ipGroupToDict(ipInfo)
        params = self.makeVADParams('delIp', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            IPGroup
            )

    def getIPGroup(self, name):
        '''
        根据名称获取IP组配置
        '''
        key = {'name': name}
        params = self.makeVADParams('getIpGroupInfo', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            IPGroup.generatingIPGroup
            )

    def getIPGroupList(self):
        '''
        获取IP组信息列表
        '''
        params = self.makeVADParams('getIpGroupList')
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            IPGroup.generatingIPGroupList
            )

    def createPersist(self, pers):
        '''
        新建会话保持配置
        @pers PersistInfo类型数据
        '''
        key = PersistInfo.persistInfoToDict(pers)
        params = self.makeVADParams('createPersist', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            PersistInfo
            )

    def updatePersist(self, name, pers):
        '''
        更新会话保持配置
        @name 会话保持名称
        @pers PersistInfo类型数据
        '''
        key = PersistInfo.persistInfoToDict(pers)
        key['persist_name'] = name
        params = self.makeVADParams('updatePersist', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            PersistInfo
            )

    def delPersist(self, name):
        '''
        删除会话保持配置
        @name 会话保持名称
        '''
        key = {'name': name}
        params = self.makeVADParams('delPersist', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            PersistInfo
            )

    def getPersistInfo(self, name):
        '''
        获取会话保持信息
        @name 会话保持名称
        '''
        key = {'name': name}
        params = self.makeVADParams('getPersistInfo', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            PersistInfo.generatingPersistInfo
            )

    def getPersistList(self):
        '''
        获取会话保持信息列表
        '''
        params = self.makeVADParams('getPersistList')
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            PersistInfo.generatingPersistList
            )

    def createMonitorInfo(self, monitor):
        '''
        新建监视器
        @monitor MonitorInfo类型信息
        '''
        key = MonitorInfo.monitorInfoToDict(monitor)
        params = self.makeVADParams('createNodeMonitor', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            MonitorInfo
            )

    def updateMonitorInfo(self, name, monitor):
        '''
        更新监视器
        @name 监视器名称
        @monitor MonitorInfo类型信息
        '''
        key = MonitorInfo.monitorInfoToDict(monitor)
        key['monitor_name'] = name
        params = self.makeVADParams('updateNodeMonitor', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            MonitorInfo
            )

    def delMonitorInfo(self, name):
        '''
        删除监视器配置
        @name 监视器名称
        '''
        key = {'name': name}
        params = self.makeVADParams('delNodeMonitor', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            MonitorInfo
            )

    def getMonitorInfo(self, name):
        '''
        获取监视器信息
        @name 监视器名称
        '''
        key = {'name': name}
        params = self.makeVADParams('getNodeMonitorInfo', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            MonitorInfo.generatingMonitorInfo
            )

    def getMonitorList(self):
        '''
        获取监视器信息列表
        '''
        params = self.makeVADParams('getNodeMonitorList')
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            MonitorInfo.generatingMonitorList
            )

    def createPoolInfo(self, pool):
        '''
        新建节点池
        @pool PoolInfo类型信息
        '''
        key = PoolInfo.poolInfoToDict(pool)
        params = self.makeVADParams('createNodePool', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            PoolInfo
            )

    def updatePoolInfo(self, name, pool):
        '''
        更新节点池
        @name 要更新配置的节点池名称
        @pool PoolInfo类型信息
        '''
        key = PoolInfo.poolInfoToDict(pool)
        key['pool_name'] = name
        params = self.makeVADParams('updateNodePool', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            PoolInfo
            )

    def delPoolInfo(self, name):
        '''
        删除节点池配置
        @name 节点池名称
        '''
        key = {'name': name}
        params = self.makeVADParams('delNodePool', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            PoolInfo
            )

    def addMonitor(self, poolName, monitorName):
        '''
        往节点池添加监视器
        @poolName 节点池名称
        @monitorName 监视器名称
        '''
        key = {'name': poolName, 'monitor': monitorName}
        params = self.makeVADParams('addPoolMonitor', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            PoolInfo
            )

    def delMonitor(self, poolName, monitorName):
        '''
        从节点池中删除监视器
        @poolName 节点池名称
        @monitorName 监视器名称
        '''
        key = {'name': poolName, 'monitor': monitorName}
        params = self.makeVADParams('delPoolMonitor', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            PoolInfo
            )

    def getPoolInfo(self, name):
        '''
        获取节点池信息
        @name 节点池名称
        '''
        key = {'name': name}
        params = self.makeVADParams('getNodePoolInfo', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            PoolInfo.generatingPoolInfo
            )

    def getPoolList(self):
        '''
        获取节点池信息列表
        '''
        params = self.makeVADParams('getNodePoolList')
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            PoolInfo.generatingPoolList
            )

    def createNode(self, poolName, node):
        '''
        往节点池添加节点
        @poolName 节点池名称
        @node NodeInfo类型信息
        '''
        key = NodeInfo.nodeInfoToDict(node)
        key['name'] = poolName
        params = self.makeVADParams('createNode', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            NodeInfo
            )

    def updateNode(self, poolName, nodeIP, nodePort, node):
        '''
        更新节点池中的节点
        @poolName 节点池名称
        @nodeIP 节点IP
        @nodePort 节点端口
        @node NodeInfo类型信息
        '''
        key = NodeInfo.nodeInfoToDict(node)
        key['name'] = poolName
        key['node_ip'] = nodeIP
        key['node_port'] = nodePort
        params = self.makeVADParams('updateNode', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            NodeInfo
            )

    def delNode(self, poolName, nodeIP, nodePort):
        '''
        从节点池删除节点
        @poolName 节点池名称
        @nodeIP 节点IP
        @nodePort 节点端口
        '''
        key = {'name': poolName, 'ip': nodeIP, 'port': nodePort}
        params = self.makeVADParams('delNode', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            NodeInfo
            )

    def getNodeInfo(self, poolName, nodeIP, nodePort):
        '''
        获取节点信息
        @poolName 节点池名称
        @nodeIP 节点IP
        @nodePort 节点端口
        '''
        key = {'name': poolName, 'ip': nodeIP, 'port': nodePort}
        params = self.makeVADParams('getNodeInfo', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            NodeInfo.generatingNodeInfo
            )

    def getNodeList(self, poolName):
        '''
        获取节点信息列表
        @poolName 节点池名称
        '''
        key = {'name': poolName}
        params = self.makeVADParams('getNodeList', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            NodeInfo.generatingNodeList
            )

    def getNodeStatus(self, poolName):
        '''
        获取节点状态列表
        @poolName 节点池名称
        '''
        key = {'name': poolName}
        params = self.makeVADParams('getNodesStatus', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            NodeInfo.generatingNodeStatus
            )

    def createVS(self, vs):
        '''
        新建虚拟服务
        @vs VSInfo类型数据
        '''
        key = VSInfo.vsInfoToDict(vs)
        params = self.makeVADParams('createVs', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            VSInfo
            )

    def updateVS(self, name, vs):
        '''
        更新虚拟服务
        @name 虚拟服务名称
        @vs VSInfo类型数据
        '''
        key = VSInfo.vsInfoToDict(vs)
        key['vs_name'] = name
        params = self.makeVADParams('updateVs', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            VSInfo
            )

    def delVS(self, name):
        '''
        删除虚拟服务
        @name 虚拟服务名称
        '''
        key = {'name': name}
        params = self.makeVADParams('delVs', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            VSInfo
            )

    def getVSInfo(self, name):
        '''
        获取虚拟服务信息
        @name 虚拟服务名称
        '''
        key = {'name': name}
        params = self.makeVADParams('getVsInfo', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            VSInfo.generatingVSInfo
            )

    def getVSStatus(self):
        '''
        获取虚拟服务状态
        '''
        params = self.makeVADParams('getVsStatus')
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            VSInfo.generatingVSStatus
            )

    def getVSList(self):
        '''
        获取虚拟服务列表
        '''
        params = self.makeVADParams('getVsList')
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            VSInfo.generatingVSList
            )

    def createWanInfo(self, wanInfo):
        '''
        新建wan口
        @wanInfo WanInfo类型数据
        '''
        key = WanInfo.wanInfoToDict(wanInfo)
        params = self.makeVADParams('createWanInfo', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            WanInfo
            )

    def updateWanInfo(self, name, wanInfo):
        '''
        更新wan口信息
        @name 需要更新的wan口名称
        @wanInfo WanInfo类型数据
        '''
        key = WanInfo.wanInfoToDict(wanInfo)
        key['wan_name'] = name
        params = self.makeVADParams('updateWanInfo', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            WanInfo
            )

    def deleteWanInfo(self, name):
        '''
        删除wan口配置
        @name 需要删除的wan口名称
        '''
        key = {'name': name}
        params = self.makeVADParams('deleteWanInfo', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            WanInfo
            )

    def getWanInfo(self, name):
        '''
        获取wan口配置ip信息列表
        @name wan口名称
        '''
        key = {'name': name}
        params = self.makeVADParams('getWanInfo', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            WanInfo.generatingWanInfo
            )

    def getWanList(self):
        '''
        获取wan口配置名称信息列表
        '''
        params = self.makeVADParams('getWanList')
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            WanInfo.generatingWanList
            )

    def createLanInfo(self, lanInfo):
        '''
        新建lan口
        @lanInfo lanInfo类型数据
        '''
        key = LanInfo.lanInfoToDict(lanInfo)
        params = self.makeVADParams('createLanInfo', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            LanInfo
            )

    def updateLanInfo(self, name, lanInfo):
        '''
        更新lan口信息
        @name 需要更新的lan口名称
        @lanInfo LanInfo类型数据
        '''
        key = LanInfo.lanInfoToDict(lanInfo)
        key['lan_name'] = name
        params = self.makeVADParams('updateLanInfo', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            LanInfo
            )

    def deleteLanInfo(self, name):
        '''
        删除lan口配置
        @name 需要删除的lan口名称
        '''
        key = {'name': name}
        params = self.makeVADParams('deleteLanInfo', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            LanInfo
            )

    def getLanInfo(self, name):
        '''
        获取lan口配置ip信息列表
        @name lan口名称
        '''
        key = {'name': name}
        params = self.makeVADParams('getLanInfo', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            LanInfo.generatingLanInfo
            )

    def getLanList(self):
        '''
        获取lan口配置名称信息列表
        '''
        params = self.makeVADParams('getLanList')
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            LanInfo.generatingLanList
            )

    def createSnatSet(self, snatSet):
        '''
        新建snat地址集
        @snatSet SnatSet类型数据
        '''
        key = SnatSet.snatSetToDict(snatSet)
        params = self.makeVADParams('createSnatSet', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            SnatSet
            )

    def updateSnatSet(self, name, snatSet):
        '''
        更新snat地址集配置
        @name 需要更新的snat地址集名称
        @snatSet SnatSet类型数据
        '''
        key = SnatSet.snatSetToDict(snatSet)
        key['snat_name'] = name
        params = self.makeVADParams('updateSnatSet', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            SnatSet
            )

    def deleteSnatSet(self, name):
        '''
        删除snat地址集配置
        @name 需要删除的snat地址集名称
        '''
        key = {'name': name}
        params = self.makeVADParams('deleteSnatSet', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            SnatSet
            )

    def getSnatSet(self, name):
        '''
        获取snat地址集
        @name snat地址集名称
        '''
        key = {'name': name}
        params = self.makeVADParams('getSnatSet', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            SnatSet.generatingSnatSet
            )

    def getSnatSetList(self):
        '''
        获取snat地址集名称信息列表
        '''
        params = self.makeVADParams('getSnatSetList')
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            SnatSet.generatingSnatSetList
            )

    def createAcl(self, aclInfo):
        '''
        创建高级ACL
        @AclInfo AclInfo类型数据
        '''
        key = AclInfo.aclInfoToDict(aclInfo)
        params = self.makeVADParams('createAcl', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            AclInfo
            )

    def updateAcl(self, name, aclInfo):
        '''
        更新高级ACL
        @name  高级ACL名称
        @AclInfo AclInfo类型数据
        '''
        key = AclInfo.aclInfoToDict(aclInfo)
        key['acl_name'] = name
        params = self.makeVADParams('updateAcl', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            AclInfo
            )

    def deleteAcl(self, name):
        '''
        删除高级ACL
        @name  高级ACL名称
        '''
        key = {'name': name}
        params = self.makeVADParams('deleteAcl', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            AclInfo
            )

    def getAclInfo(self, name):
        '''
        获取高级ACL配置
        @name 高级ACL名称
        '''
        key = {'name': name}
        params = self.makeVADParams('getAclInfo', key)
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            AclInfo.generatingAclInfo
            )

    def getAclList(self):
        '''
        获取高级ACL配置列表
        '''
        params = self.makeVADParams('getAclList')
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            AclInfo.generatingAclList
            )

    def resetVADConfig(self):
        '''
        清除VAD上配置
        '''
        params = self.makeVADParams('resetConfig')
        return self.vadProc(
            params,
            self.config.vadProxyURI,
            RequestMethod.POST,
            ErrInfo
            )


if __name__ == '__main__':
    api = ADAPI('admin', 'root1234', '200.200.147.193', '443')
    serv = api.getServInfo('http')
    print 'fail:',serv.isFailed()
    print serv
