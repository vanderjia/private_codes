# -*- coding: utf-8 -*-
# Copyright (c) 2008-2016, AD SANGFOR, [Version 6.3.0]
# Filename: VlanInfo.py

from Configuration import Configuration
from APIException import APIException
from ErrorInfo import ErrInfo
from urllib2 import base64
import XMLObject as xmlo
import urllib
from ParentList import ParentList
from AddrElement import AddrElement


class VlanInfo (ErrInfo) :
    def __init__(self, httpBody = None) :
        ErrInfo.__init__(self, httpBody)
        self.name = None
        self.enable = None
        self.device = None
        self.ifname = None
        self.vlan_id = None
        if httpBody == "" or httpBody == None :
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0 :
            return
        if not isinstance(httpBody, unicode) :
                httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)
            if self.xmlObj.hasTag("name") :
                self.name = urllib.unquote(Configuration.base64decode(self.xmlObj["name"][0].getChildValue()))
            if self.xmlObj.hasTag("ifname") :
                self.ifname = urllib.unquote(Configuration.base64decode(self.xmlObj['ifname'][0].getChildValue()))
            if self.xmlObj.hasTag("device") :
                self.device = urllib.unquote(Configuration.base64decode(self.xmlObj['device'][0].getChildValue()))
            if self.xmlObj.hasTag("enable") :
                self.enable = self.xmlObj['enable'][0].getChildValue()
            if self.xmlObj.hasTag("vlan_id") :
                self.vlan_id = self.xmlObj['vlan_id'][0].getChildValue()
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)

    def __str__(self) :
        return self.originStr

    @classmethod
    def vlanInfoToXml(cls, vlanInfo):
        '''
        拼接发送信息
        '''
        params = ''
        if vlanInfo is not None:
            params += '<vlan_info>'
            if vlanInfo.name is not None:
                params += '<name>' + base64.b64encode(vlanInfo.name) + '</name>'
            if vlanInfo.enable is not None:
                params += '<enable>' + vlanInfo.enable + '</enable>'
            if vlanInfo.device is not None:
                params += '<device>' + base64.b64encode(vlanInfo.device) + '</device>'
            if vlanInfo.ifname is not None:
                params += '<ifname>' + base64.b64encode(vlanInfo.ifname) + '</ifname>'
            if vlanInfo.vlan_id is not None:
                params += '<vlan_id>' + str(vlanInfo.vlan_id) + '</vlan_id>'
            params += '</vlan_info>'
        return params

    @classmethod
    def generatingVlanInfo(cls, httpBody) :
        return VlanInfo(httpBody)

