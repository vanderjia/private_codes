# -*- coding: utf-8 -*-
# Copyright (c) 2008-2020, AD SANGFOR
# Filename: VlanInfo.py
# 定义vlan信息
from Configuration import Configuration
from APIException import APIException
from ErrorInfo import ErrInfo
from http.HttpClient import HttpClient
from ParentList import ParentList
from urllib2 import base64
import JSONObj as jsono
import urllib
import json


class MacvlanInfo(ErrInfo):
    def __init__(self, httpBody=None):
        ErrInfo.__init__(self, httpBody)
        self.name = None
        self.device = None      # 生成的Macvlan网口
        self.ifname = None      # 引用物理网口
        self.mac = None         # 对应mac地址
        self.netnsId = 0        # netns id [1, 65000]
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('MacvlanInfoType'):
                jsonMacvlanInfo = self.jsonObj['MacvlanInfoType']
                if 'name' in jsonMacvlanInfo:
                    self.name = urllib.unquote(
                        base64.b64decode(jsonMacvlanInfo['name']))
                if 'ifname' in jsonMacvlanInfo:
                    self.ifname = urllib.unquote(
                        base64.b64decode(jsonMacvlanInfo['ifname']))
                if 'device' in jsonMacvlanInfo:
                    self.device = urllib.unquote(
                        base64.b64decode(jsonMacvlanInfo['device']))
                if 'mac' in jsonMacvlanInfo:
                    self.mac = urllib.unquote(
                        base64.b64decode(jsonMacvlanInfo['mac']))
                if 'netns_id' in jsonMacvlanInfo:
                    self.netnsId = int(jsonMacvlanInfo['netns_id'])
        except jsono.JSONObjException, e:
            raise APIException(3, e.reason)

    @classmethod
    def macvlanInfoToDict(cls, macvlanInfo):
        macvlanDict = {}
        macvlanDict['netns_id'] = macvlanInfo.netnsId
        if macvlanInfo.name is None:
            macvlanDict['name'] = ''
        else:
            macvlanDict['name'] = macvlanInfo.name
        if macvlanInfo.ifname is None:
            macvlanDict['ifname'] = ''
        else:
            macvlanDict['ifname'] = macvlanInfo.ifname
        if macvlanInfo.mac is None:
            macvlanDict['mac'] = ''
        else:
            macvlanDict['mac'] = macvlanInfo.mac
        return macvlanDict

    @classmethod
    def generatingMacvlanInfo(cls, httpBody):
        return MacvlanInfo(httpBody)


class VlanInfoList(ParentList):
    def __init__(self, httpBody=None):
        ParentList.__init__(self, httpBody)
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if not self.jsonObj.hasTag('data'):
                return
            for item in self.jsonObj['data']:
                vlan = VlanInfo(json.dumps(item, ensure_ascii=False))
                self.elements.append(vlan)
        except jsono.JSONObjException, e:
            raise APIException(3, e.reason)
