#!/usr/bin/python
# coding: utf-8

import os
import sys
import json
import urllib
import traceback
import xmltodict
import logging
from ad.REST_ADAPI import REST_ADAPI
from ad.api.Servconfig import ServInfo, portInfo
from ad.api.Ipgroup import IpgroupInfo, ipNode
from ad.api.Persist import PersistInfo
from ad.api.Monitor import MonitorInfo
from ad.api.NodeInfoV2 import NodeInfoV2
from ad.api.NodePoolV2 import NodePoolV2
from ad.api.VsInfo import VsInfo
from ad.api.NetnsInfo import NetnsInfo
from ad.api.MacvlanInfo import MacvlanInfo
from ad.api.VlanInfo import VlanInfo
from ad.api.WanInfo import WanInfo
from ad.api.LanInfo import LanInfo
from ad.api.AddrElement import AddrElement
from ad.api.SnatSet import SnatSet
from ad.api.AclInfo import AclInfo
from ad.api.StaticRoute import StaticRouteInfo

__version__ = '2.0.0'
__author__ = 'ad.sangfor.com'

logging.basicConfig(level=None)
LOG = logging.getLogger(__name__)

VAD_PROXY_ERR_CODE = 322
VAD_PROXY_ERR_INFO = 'vAD proxy ctl failed'

ARGS_ERR_CODE = 401
ARGS_ERR_INFO = 'Request parameter error'

CMD_VAD_PROXY_CTL = 203  # vAD代理ADAPI


def vad_err_info(err, strerr):
    errinfo = {}
    errinfo["err_code"] = err
    errinfo["err_info"] = strerr
    return errinfo


# 过程出错，退出处理
def err_exit(err, strerr):
    return json.dumps(vad_err_info(err, strerr), ensure_ascii=False)
    #sys.exit(1)


# 请求参数错误退出处理
def args_err_exit():
    return err_exit(ARGS_ERR_CODE, ARGS_ERR_INFO)


# 服务
def buildServArg(args):
    srv = ServInfo()
    if 'name' not in args or 'port_scope' not in args:
        args_err_exit()
    srv.name = args['name'].encode('utf-8')
    portArr = args['port_scope']
    for port in portArr:
        # 一定会有from字段
        if 'from' not in port:
            args_err_exit()
        p = portInfo()
        if 'from'in port:
            p.from_port = int(port['from'])
        if 'to' in port:
            p.to_port = int(port['to'])
        srv.port.append(p)
    return srv


def createServ(adapi, args):
    '''
    {'name': , 'type': , 'port_scope':[{'from': , 'to': }]}
    '''
    # 解析json字符串，封装参数
    if 'type' not in args or 'name' not in args or 'port_scope' not in args:
        args_err_exit()
    srv = buildServArg(args)
    srv.type = args['type']
    return adapi.createServ(srv)


def addServPort(adapi, args):
    '''
    {'name': , 'port_scope':[{'from': , 'to': }]}
    '''
    # 解析json字符串，封装参数
    if 'name' not in args or 'port_scope' not in args:
        args_err_exit()
    srv = buildServArg(args)
    return adapi.addServPort(srv)


def delServPort(adapi, args):
    '''
    {'name': , 'port_scope':[{'from': , 'to': }]}
    '''
    # 解析json字符串，封装参数
    if 'name' not in args or 'port_scope' not in args:
        args_err_exit()
    srv = buildServArg(args)
    return adapi.delServPort(srv)


def delServ(adapi, args):
    '''
    {'name': }
    '''
    if 'name' not in args:
        args_err_exit()
    return adapi.delServ(args['name'].encode('utf-8'))


def getServList(adapi, args):
    '''
    {}
    '''
    return adapi.getServList()


def getServInfo(adapi, args):
    '''
    {'name': }
    '''
    if 'name' not in args:
        args_err_exit()
    return adapi.getServInfo(args['name'].encode('utf-8'))


# IP组
def buildIpGroup(args):
    ipg = IpgroupInfo()
    if 'name' not in args or 'ip_info' not in args:
        args_err_exit()
    ipArr = args['ip_info']
    for ipVec in ipArr:
        ipnode = ipNode()
        if 'ip_addr' not in ipVec:
            args_err_exit()
        if 'netif_name' in ipVec:
            ipnode.netif_name = ipVec['netif_name']
        ips = ipVec['ip_addr']
        for ip in ips:
            ipnode.addr.append(ip)
        ipg.ipg.append(ipnode)
    return ipg


def createIpGroup(adapi, args):
    '''
    {'name': , 'ip_info': [{'netif_name': , 'ip_addr': []}]}
    '''
    # 解析json字符串，封装参数
    ipg = buildIpGroup(args)
    return adapi.createIpGroup(args['name'].encode('utf-8'), ipg)


def addIp(adapi, args):
    '''
    {'name': , 'ip_info': [{'netif_name': , 'ip_addr': []}]}
    '''
    # 解析json字符串，封装参数
    ipg = buildIpGroup(args)
    return adapi.addIp(args['name'].encode('utf-8'), ipg)


def delIp(adapi, args):
    '''
    {'name': , 'ip_info': [{'netif_name': , 'ip_addr': []}]}
    '''
    # 解析json字符串，封装参数
    ipg = buildIpGroup(args)
    return adapi.delIp(args['name'].encode('utf-8'), ipg)


def delIpGroup(adapi, args):
    '''
    {'name': }
    '''
    if 'name' not in args:
        args_err_exit()
    return adapi.delIpGroup(args['name'].encode('utf-8'))


def getIpGroupList(adapi, args):
    '''
    {}
    '''
    return adapi.getIpGroupList()


def getIpGroupInfo(adapi, args):
    '''
    {'name': }
    '''
    if 'name' not in args:
        args_err_exit()
    return adapi.getIpGroupInfo(args['name'].encode('utf-8'))


# 会话保持
def createPersist(adapi, args):
    '''
    {
        'name': ,
        'type': ,
        'prior_to_connect': ,
        'source_ip': {
            'mask_v4': ,
            'mask_v6': ,
            'timeout':
        },
        'cookie': {
            'cookie_type': ,
            'cookie_name': ,
            'cookie_domain': ,
            'cookie_path': ,
            'cookie_timeout':
        }
    }
    '''
    persist = PersistInfo()
    if 'name' not in args or 'type' not in args \
       or 'prior_to_connect' not in args:
        args_err_exit()
    persist.name = args['name'].encode('utf-8')
    persist.p_type = args['type']
    persist.prior_to_connect = args['prior_to_connect']
    # source ip会话保持
    if persist.p_type == 'PERSIST_SOURCE_IP':
        if 'source_ip' in args:
            sourceIp = args['source_ip']
            if 'mask_v4' in sourceIp:
                persist.mask_v4 = sourceIp['mask_v4']
            if 'mask_v6' in sourceIp:
                persist.mask_v6 = sourceIp['mask_v6']
            if 'timeout' in sourceIp:
                persist.sourceip_timeout = int(sourceIp['timeout'])
    # cookie会话保持
    elif persist.p_type == 'PERSIST_COOKIE':
        if 'cookie' not in args:
            args_err_exit()
        cookie = args['cookie']
        if 'cookie_type' not in cookie or 'cookie_name' not in cookie:
            args_err_exit()
        persist.cookie_type = cookie['cookie_type']
        persist.cookie_name = cookie['cookie_name'].encode('utf-8')
        # 插入会话保持有domain/path字段
        if persist.cookie_type == 'PERSIST_COOKIE_INSERT':
            if 'cookie_domain' in cookie:
                persist.cookie_domain = cookie['cookie_domain'].encode('utf-8')
            if 'cookie_path' not in cookie:
                args_err_exit()
            persist.cookie_path = cookie['cookie_path'].encode('utf-8')
        # 插入/被动cookie时，有超时
        if persist.cookie_type != 'PERSIST_COOKIE_REWRITE':
            if 'cookie_timeout' not in cookie:
                args_err_exit()
            persist.cookie_timeout = int(cookie['cookie_timeout'])
    else:  # 只支持SOURCE_IP/COOKIE会话保持
        args_err_exit()
    return adapi.createPersist(persist)


def updatePersist(adapi, args):
    '''
    {
        'persist_name': ,
        'name': ,
        'prior_to_connect': ,
        'source_ip': {
            'mask_v4': ,
            'mask_v6': ,
            'timeout':
        },
        'cookie': {
            'cookie_type': ,
            'cookie_name': ,
            'cookie_domain': ,
            'cookie_path': ,
            'cookie_timeout':
        }
    }
    '''
    persist = PersistInfo()
    if 'persist_name' not in args:
        args_err_exit()
    if 'prior_to_connect' in args:
        persist.prior_to_connect = args['prior_to_connect']
    if 'name' in args:
        persist.name = args['name'].encode('utf-8')
    # source ip会话保持
    if 'source_ip' in args:
        sourceIp = args['source_ip']
        if 'mask_v4' in sourceIp:
            persist.mask_v4 = sourceIp['mask_v4']
        if 'mask_v6' in sourceIp:
            persist.mask_v6 = sourceIp['mask_v6']
        if 'timeout' in sourceIp:
            persist.sourceip_timeout = int(sourceIp['timeout'])
    # cookie会话保持
    elif 'cookie' not in args:
        cookie = args['cookie']
        if 'cookie_type' in cookie:
            persist.cookie_type = cookie['cookie_type']
        if 'cookie_name' in cookie:
            persist.cookie_name = cookie['cookie_name'].encode('utf-8')
        if 'cookie_domain' in cookie:
            persist.cookie_domain = cookie['cookie_domain'].encode('utf-8')
        if 'cookie_path' in cookie:
            persist.cookie_path = cookie['cookie_path'].encode('utf-8')
        if 'cookie_timeout' in cookie:
            persist.cookie_timeout = int(cookie['cookie_timeout'])
    return adapi.updatePersist(args['persist_name'].encode('utf-8'), persist)


def delPersist(adapi, args):
    '''
    {'name': }
    '''
    if 'name' not in args:
        args_err_exit()
    return adapi.delPersist(args['name'].encode('utf-8'))


def getPersistList(adapi, args):
    '''
    {}
    '''
    return adapi.getPersistList()


def getPersistInfo(adapi, args):
    '''
    {'name': }
    '''
    if 'name' not in args:
        args_err_exit()
    return adapi.getPersistInfo(args['name'].encode('utf-8'))


# 节点监视器
def buildNodeMonitor(args):
    monitor = MonitorInfo()
    if 'name' in args:
        monitor.name = args['name'].encode('utf-8')
    if 'type' in args:
        monitor.type = args['type']
    if 'interval' in args:
        monitor.interval = int(args['interval'])
    if 'timeout' in args:
        monitor.timeout = int(args['timeout'])
    if 'tryout' in args:
        monitor.tryout = int(args['tryout'])
    if 'debug' in args:
        monitor.debug = args['debug']
    if 'addr' in args:
        monitor.addr = args['addr']
    if 'port' in args:
        monitor.port = str(args['port'])
    if 'is_firewall' in args:
        monitor.is_firewall = args['is_firewall']
    if 'connect_ext' not in args:
        return monitor
    ext = args['connect_ext']
    if 'recv_buf_max' in ext:
        monitor.recv_buf_max = int(ext['recv_buf_max'])
    if 'recv_include' in ext:
        monitor.recv_include = ext['recv_include'].encode('utf-8')
    if 'send_msg' in ext:
        monitor.send_msg = ext['send_msg'].encode('utf-8')
    if 'close_send_msg' in ext:
        monitor.close_send_msg = ext['close_send_msg'].encode('utf-8')
    if 'resp_code' in ext:
        monitor.resp_code = ext['resp_code']
    if 'url_msg' in ext:
        monitor.url_msg = ext['url_msg'].encode('utf-8')
    if 'hex' in ext:
        monitor.hex = ext['hex']
    return monitor


def createNodeMonitor(adapi, args):
    '''
    {
        'name': ,
        'type': ,
        'interval': ,
        'timeout': ,
        'tryout': ,
        'addr': ,
        'port': ,
        'debug': ,
        'is_firewall': ,
        'connect_ext': {
            'recv_buf_max': ,
            'send_msg': ,
            'recv_include': ,
            'close_send_msg': ,
            'resp_code': ,
            'url_msg': ,
            'hex':
        }
    }
    '''
    if 'name' not in args or 'type' not in args or 'interval' not in args \
       or 'timeout' not in args or 'tryout' not in args \
       or 'debug' not in args or 'addr' not in args:
        args_err_exit()
    monitor = buildNodeMonitor(args)
    return adapi.createNodeMonitor(monitor)


def updateNodeMonitor(adapi, args):
    '''
    {
        'monitor_name': ,
        'name': ,
        'type': ,
        'interval': ,
        'timeout': ,
        'tryout': ,
        'addr': ,
        'port': ,
        'debug': ,
        'is_firewall': ,
        'connect_ext': {
            'recv_buf_max': ,
            'send_msg': ,
            'recv_include': ,
            'close_send_msg': ,
            'resp_code': ,
            'url_msg': ,
            'hex':
        }
    }
    '''
    if 'monitor_name' not in args:
        args_err_exit()
    monitor = buildNodeMonitor(args)
    return adapi.updateNodeMonitor(args['monitor_name'].encode('utf-8'), monitor)


def delNodeMonitor(adapi, args):
    '''
    {'name': }
    '''
    if 'name' not in args:
        args_err_exit()
    return adapi.delNodeMonitor(args['name'].encode('utf-8'))


def getNodeMonitorList(adapi, args):
    '''
    {}
    '''
    return adapi.getNodeMonitorList()


def getNodeMonitorInfo(adapi, args):
    '''
    {'name': }
    '''
    if 'name' not in args:
        args_err_exit()
    return adapi.getNodeMonitorInfo(args['name'].encode('utf-8'))


# 节点池
def buildNodeV2(args):
    node = NodeInfoV2()
    if 'status' in args:
        node.confStatus = args['status']
    if 'ratio' in args:
        node.ratio = int(args['ratio'])
    if 'max_connects' in args:
        node.maxConnects = args['max_connects']
    if 'new_connects' in args:
        node.newConnects = args['new_connects']
    if 'max_request' in args:
        node.maxRequest = args['max_request']
    if 'ip' in args:
        node.nodeIP = args['ip']
    if 'port' in args:
        node.nodePort = args['port']
    if 'rs_val1' in args:
        node.rsVal1 = args['rs_val1'].encode('utf-8')
    return node


def createNodeV2(adapi, args):
    '''
    {
        'name': ,
        'status': ,
        'ratio': ,
        'max_connects': ,
        'new_connects': ,
        'max_request': ,
        'rs_val1': ,
        'ip': ,
        'port':,
    }
    '''
    if 'name' not in args or 'status' not in args or 'ratio' not in args \
       or 'max_connects' not in args or 'new_connects' not in args \
       or 'max_request' not in args or 'ip' not in args or 'port' not in args:
        args_err_exit()
    node = buildNodeV2(args)
    return adapi.createNodeV2(args['name'].encode('utf-8'), node)


def updateNodeV2(adapi, args):
    '''
    {
        'name': ,
        'node_ip': ,
        'node_port': ,
        'status': ,
        'ratio': ,
        'max_connects': ,
        'new_connects': ,
        'max_request': ,
        'rs_val1': ,
        'port':,
    }
    '''
    if 'name' not in args or 'node_ip' not in args or 'node_port' not in args:
        args_err_exit()
    node = buildNodeV2(args)
    return adapi.updateNodeV2(args['name'].encode('utf-8'),
                              args['node_ip'],
                              args['node_port'],
                              node)


def delNodeV2(adapi, args):
    '''
    {'name': , 'ip': , 'port': }
    '''
    if 'name' not in args or 'ip' not in args or 'port' not in args:
        args_err_exit()
    return adapi.delNodeV2(args['name'].encode('utf-8'),
                            args['ip'],
                            args['port'])


def getNodeListV2(adapi, args):
    '''
    {'name': }
    '''
    if 'name' not in args:
        args_err_exit()
    return adapi.getNodeListV2(args['name'].encode('utf-8'))


def getNodeV2Info(adapi, args):
    '''
    {'name': , 'ip': , 'port': }
    '''
    if 'name' not in args or 'ip' not in args or 'port' not in args:
        args_err_exit()
    return adapi.getNodeV2Info(args['name'].encode('utf-8'),
                            args['ip'],
                            args['port'])


def getNodesV2Status(adapi, args):
    '''
    {'name': }
    '''
    if 'name' not in args:
        args_err_exit()
    return adapi.getNodesV2Status(args['name'].encode('utf-8'))


def buildNodePool(args):
    nodepool = NodePoolV2()
    if 'name' in args:
        nodepool.name = args['name'].encode('utf-8')
    if 'lb_method' in args:
        nodepool.lbMethod = args['lb_method']
    if 'hash_type' in args:
        nodepool.hashType = args['hash_type']
    if 'persist1_name' in args:
        nodepool.persist1Name = args['persist1_name'].encode('utf-8')
    if 'persist2_name' in args:
        nodepool.persist2Name = args['persist2_name'].encode('utf-8')
    if 'monitors' in args:
        monitorList = []
        for monitor in args['monitors']:
            monitorList.append(monitor.encode('utf-8'))
        nodepool.monitors = ';'.join(monitorList)
    if 'min_monitors' in args:
        nodepool.minMonitors = args['min_monitors']
    if 'recover_inter' in args:
        nodepool.recoverInterval = args['recover_inter']
    if 'stepper_inter' in args:
        nodepool.stepperInterval = args['stepper_inter']
    if 'sched_method' in args:
        nodepool.schedMethod = args['sched_method']
    if 'conn_stat_all' in args:
        nodepool.connStatAll = args['conn_stat_all']
    if 'queue_length' in args:
        nodepool.queueLength = args['queue_length']
    if 'queue_timeout' in args:
        nodepool.queueTimeout = args['queue_timeout']
    if 'netns_id' in args:
        nodepool.netnsId = args['netns_id']
    return nodepool


def createNodePool(adapi, args):
    '''
    {
        'name': ,
        'lb_method': ,
        'hash_type': ,
        'persist1_name': ,
        'persist2_name': ,
        'monitors': [],
        'min_monitors': ,
        'recover_inter': ,
        'stepper_inter': ,
        'sched_method': ,
        'conn_stat_all': ,
        'queue_length': ,
        'queue_timeout':
    }
    '''
    if 'name' not in args or 'lb_method' not in args \
       or 'persist1_name' not in args or 'persist2_name' not in args \
       or 'min_monitors' not in args or 'recover_inter' not in args \
       or 'stepper_inter' not in args or 'sched_method' not in args \
       or 'conn_stat_all' not in args or 'netns_id' not in args:
        args_err_exit()
    if args['lb_method'] == 'NODE_LB_HASH':
        if 'hash_type' not in args:
            args_err_exit()
    if args['sched_method'] == 'SCHED_METHOD_QUEUE':
        if 'queue_length' not in args or 'queue_timeout' not in args:
            args_err_exit()
    nodepool = buildNodePool(args)
    return adapi.createNodePool(nodepool)


def updateNodePool(adapi, args):
    '''
    {
        'pool_name': ,
        'name': ,
        'lb_method': ,
        'hash_type': ,
        'persist1_name': ,
        'persist2_name': ,
        'monitors': [],
        'min_monitors': ,
        'recover_inter': ,
        'stepper_inter': ,
        'sched_method': ,
        'conn_stat_all': ,
        'queue_length': ,
        'queue_timeout':
    }
    '''
    if 'pool_name' not in args:
        args_err_exit()
    nodepool = buildNodePool(args)
    return adapi.updateNodePool(args['pool_name'].encode('utf-8'), nodepool)


def delNodePool(adapi, args):
    '''
    {'name': }
    '''
    if 'name' not in args:
        args_err_exit()
    return adapi.delNodePool(args['name'].encode('utf-8'))


def addPoolMonitor(adapi, args):
    '''
    {'name': , 'monitor': }
    '''
    if 'name' not in args or 'monitor' not in args:
        args_err_exit()
    return adapi.addPoolMonitor(args['name'].encode('utf-8'),
                                args['monitor'].encode('utf-8'))


def delPoolMonitor(adapi, args):
    '''
    {'name': , 'monitor': }
    '''
    if 'name' not in args or 'monitor' not in args:
        args_err_exit()
    return adapi.delPoolMonitor(args['name'].encode('utf-8'),
                                args['monitor'].encode('utf-8'))


def getNodePoolListV2(adapi, args):
    '''
    {}
    '''
    return adapi.getNodePoolListV2()


def getNodePoolInfoV2(adapi, args):
    '''
    {'name': }
    '''
    if 'name' not in args:
        args_err_exit()
    return adapi.getNodePoolInfoV2(args['name'].encode('utf-8'))


# 策略


# 虚拟服务
def buildVs(args):
    vs = VsInfo()
    if 'name' in args:
        vs.vsName = args['name'].encode('utf-8')
    if 'enable' in args:
        vs.enable = args['enable']
    if 'mode' in args:
        vs.mode = args['mode']
    if 'http_sched_mode' in args:
        vs.httpschedMode = args['http_sched_mode']
    if 'tcp_cache_stream' in args:
        vs.tcpCacheStream = args['tcp_cache_stream'].encode('utf-8')
    if 'tcp_cache_num' in args:
        vs.tcpCacheNum = args['tcp_cache_num']
    if 'end_str' in args:
        vs.endStr = args['end_str'].encode('utf-8')
    if 'pre_rule' in args:
        vs.preProfile = args['pre_rule'].encode('utf-8')
    if 'service_name' in args:
        vs.serviceName = args['service_name'].encode('utf-8')
    if 'ip_group_name' in args:
        vs.ipgName = args['ip_group_name'].encode('utf-8')
    if 'node_pool_name' in args:
        vs.poolName = args['node_pool_name'].encode('utf-8')
    if 'auto_snat' in args:
        vs.autoSnat = args['auto_snat']
    if 'snat_pool' in args:
        vs.snatPool = args['snat_pool'].encode('utf-8')
    if 'dnat_enable' in args:
        vs.dnatEnable = args['dnat_enable']
    if 'netns_id' in args:
        vs.netnsId = args['netns_id']
    if 'ssl' in args:
        ssl = args['ssl']
        if 'ssl_profile' in ssl:
            vs.sslProfile = ssl['ssl_profile'].encode('utf-8')
        if 'http_redir_enable' in ssl:
            vs.httpRedirEnable = ssl['http_redir_enable']
        if 'port' in ssl:
            vs.port = int(ssl['port'])
    return vs


def createVs(adapi, args):
    '''
    {
        'name': ,
        'enable': ,
        'mode': ,
        'http_sched_mode': ,
        'tcp_cache_stream': ,
        'tcp_cache_num': ,
        'end_str': ,
        'pre_rule': ,
        'service_name': ,
        'ip_group_name': ,
        'node_pool_name': ,
        'auto_snat': ,
        'snat_pool': ,
        'dnat_enable': ,
        'ssl': {
            'ssl_profile': ,
            'http_redir_enable': ,
            'port':
        }
    }
    '''
    if 'name' not in args or 'enable' not in args or 'mode' not in args \
       or 'service_name' not in args or 'ip_group_name' not in args \
       or 'node_pool_name' not in args or 'netns_id' not in args:
        args_err_exit()
    vs = buildVs(args)
    return adapi.createVs(vs)


def updateVs(adapi, args):
    '''
    {
        'vs_name' ,
        'name': ,
        'enable': ,
        'mode': ,
        'http_sched_mode': ,
        'tcp_cache_stream': ,
        'tcp_cache_num': ,
        'end_str': ,
        'pre_rule': ,
        'service_name': ,
        'ip_group_name': ,
        'node_pool_name': ,
        'auto_snat': ,
        'snat_pool': ,
        'dnat_enable': ,
        'ssl': {
            'ssl_profile': ,
            'http_redir_enable': ,
            'port':
        }
    }
    '''
    if 'vs_name' not in args:
        args_err_exit()
    vs = buildVs(args)
    return adapi.updateVs(args['vs_name'].encode('utf-8'), vs)


def delVs(adapi, args):
    '''
    {'name': }
    '''
    if 'name' not in args:
        args_err_exit()
    return adapi.delVs(args['name'].encode('utf-8'))


def getVsList(adapi, args):
    '''
    {}
    '''
    return adapi.getVsList()


def getVsInfo(adapi, args):
    '''
    {'name': }
    '''
    if 'name' not in args:
        args_err_exit()
    return adapi.getVsInfo(args['name'].encode('utf-8'))


def getVsStatus(adapi, args):
    '''
    {}
    '''
    return adapi.getVsStatus()

# 静态路由
def buildStaticRoute(args):
    route = StaticRouteInfo()
    if 'net' in args:
        route.net = args['net']
    if 'mask' in args:
        route.mask = args['mask']
    if 'netns_id' in args:
        route.netns_id = args['netns_id']
    gw_dev = args['gw_dev']
    if 'dev_id' in gw_dev:
        route.dev_id = gw_dev['dev_id']
    if 'gw_addr' in gw_dev:
        route.gw_addr = gw_dev['gw_addr']
    return route


def createStaticRoute(adapi, args):
    '''
    {
        'net':,
        'mask',
        'netns_id',
        'dev_id',
        'gw_addr',
    }
    '''
    if 'net' not in args or 'mask' not in args or 'netns_id' not in args \
            or 'dev_id' not in args or 'gw_addr' not in args:
        args_err_exit()
    route = buildStaticRoute(args)
    return adapi.createStaticRoute(route)


def updateStaticRoute(adapi, args):
    '''
    {
        'old_net':,
        'old_mask',
        'old_netns_id',
        'net':,
        'mask',
        'netns_id',
        'dev_id',
        'gw_addr',
    }
    '''
    if 'old_net' not in args or 'old_mask' not in args or 'old_netns_id' not in args \
       or 'net' not in args or 'mask' not in args or 'netns_id' not in args \
            or 'dev_id' not in args or 'gw_addr' not in args:
        args_err_exit()
    route = buildStaticRoute(args)
    return adapi.updateStaticRoute(args['old_net'],
                              args['old_mask'],
                              args['old_netns_id'],
                              route)


def delStaticRoute(adapi, args):
    '''
    {'net': , 'mask': , 'netns_id': }
    '''
    if 'net' not in args or 'mask' not in args or 'netns_id' not in args:
        args_err_exit()
    return adapi.delStaticRoute(args['net'],
                            args['mask'],
                            args['netns_id'])

def getStaticRouteInfo(adapi, args):
    '''
    {'net': , 'mask': , 'netns_id': }
    '''
    if 'net' not in args or 'mask' not in args or 'netns_id' not in args:
        args_err_exit()
    return adapi.getStaticRouteInfo(args['net'],
                            args['mask'],
                            args['netns_id'])

# TODO:Netns配置
def buildNetnsInfo(args):
    netns_info = NetnsInfo();
    netns_info.enable = 'true'
    netns_info.name = args['name']
    netns_info.tenant = args['tenant']
    netns_info.appg_id = args['appg_id']
    
    return netns_info


def createNetnsInfo(adapi, args):
    '''
    创建netns
    {'name':, 'enable':, 'tenant':, 'appg_id':,}
    '''
    if ('name' not in args) or ('tenant' not in args) or ('appg_id' not in args):
        args_err_exit()
    netns_info = buildNetnsInfo(args)
    return adapi.createNetnsInfo(netns_info)
    
def updateNetnsInfo(adapi, args):
    '''
    更新netns
    {'netns_name':, 'name':, 'enable':, 'tenant':, 'appg_id':,}
    '''
    if ('netns_name' not in args):
        args_err_exit()
    if ('name' not in args) or ('tenant' not in args) or ('appg_id' not in args):
        args_err_exit()
    netns_info = buildNetnsInfo(args)
    return adapi.updateNetnsInfo(args['netns_name'], netns_info)

def deleteNetnsInfo(adapi, args):
    '''
    删除netns
    {'netns_name':,}
    '''
    if ('netns_name' not in args):
        args_err_exit()
    return adapi.delNetnsInfo(args['netns_name'])

def getNetnsInfo(adapi, args):
    '''
    获取netns信息
    '''
    if 'netns_name' not in args:
        args_err_exit()
    return adapi.getNetnsInfo(args['netns_name'].encode('utf-8'))

# TODO:Macvlan配置
def buildMacvlanInfo(args):
    macvlan_info = MacvlanInfo();
    macvlan_info.enable = 'true'
    macvlan_info.name = args['name']
    macvlan_info.ifname = args['ifname']
    macvlan_info.mac = args['mac']
    macvlan_info.netns_id = args['netns_id']
    
    return macvlan_info


def createMacvlanInfo(adapi, args):
    '''
    创建macvlan接口
    {'name':, 'enable':, 'ifname':, 'mac':, 'netns_id':,}
    '''
    if ('name' not in args) or ('ifname' not in args) \
        or ('mac' not in args) or ('netns_id' not in args):
        args_err_exit()
    macvlan_info = buildMacvlanInfo(args)
    return adapi.createMacvlanInfo(macvlan_info)
    
def updateMacvlanInfo(adapi, args):
    '''
    更新macvlan接口
    {'macvlan_name':, 'name':, 'enable':, 'ifname':, 'mac':, 'netns_id':,}
    '''
    if ('macvlan_name' not in args):
        args_err_exit()
    if ('name' not in args) or ('ifname' not in args)\
        or ('mac' not in args) or ('netns_id' not in args):
        args_err_exit()
    macvlan_info = buildMacvlanInfo(args)
    return adapi.updateMacvlanInfo(args['macvlan_name'], macvlan_info)

def deleteMacvlanInfo(adapi, args):
    '''
    删除macvlan接口
    {'macvlan_name':,}
    '''
    if ('macvlan_name' not in args):
        args_err_exit()
    return adapi.delMacvlanInfo(args['macvlan_name'])

def getMacvlanInfo(adapi, args):
    '''
    获取macvlan信息
    '''
    if 'macvlan_name' not in args:
        args_err_exit()
    return adapi.getMacvlanInfo(args['macvlan_name'].encode('utf-8'))

# vlan配置
def buildVlanInfo(args):
    vlan_info = VlanInfo();
    vlan_info.enable = 'true'
    vlan_info.name = args['name']
    vlan_info.ifname = args['ifname']
    vlan_info.vlan_id = args['vlan_id']
    
    return vlan_info


def createVlanInfo(adapi, args):
    '''
    创建vlan接口
    {'name':, 'enable':, 'ifname':, 'vlan_id':,}
    '''
    if ('name' not in args) or ('ifname' not in args) or ('vlan_id' not in args):
        args_err_exit()
    vlan_info = buildVlanInfo(args)
    return adapi.createVlanInfo(vlan_info)
    
def updateVlanInfo(adapi, args):
    '''
    更新vlan接口
    {'vlan_name':, 'name':, 'enable':, 'ifname':, 'vlan_id':,}
    '''
    if ('vlan_name' not in args):
        args_err_exit()
    if ('name' not in args) or ('ifname' not in args) or ('vlan_id' not in args):
        args_err_exit()
    vlan_info = buildVlanInfo(args)
    return adapi.updateVlanInfo(args['vlan_name'], vlan_info)

def deleteVlanInfo(adapi, args):
    '''
    删除vlan接口
    {'vlan_name':,}
    '''
    if ('vlan_name' not in args):
        args_err_exit()
    return adapi.delVlanInfo(args['vlan_name'])

def getVlanInfo(adapi, args):
    '''
    获取vlan信息
    '''
    if 'vlan_name' not in args:
        args_err_exit()
    return adapi.getVlanInfo(args['vlan_name'].encode('utf-8'))

# wan配置
def buildAddrElement(addr):
    info = None
    info_id = 1
    # 一定会有info字段
    if 'info' not in addr:
        args_err_exit()
    info = addr['info']
    # info_id字段
    if 'info_id' in addr:
        info_id = int(addr['info_id'])
    addr_map = AddrElement(info, info_id)
    return addr_map


def buildWanInfo(args):
    wan = WanInfo()
    if 'name' in args:
        wan.wan_name = args['name'].encode('utf-8')
    if 'inet_addr' in args:
        for addr in args['inet_addr']:
            addr_map = buildAddrElement(addr)
            wan.inet_addr_map.append(addr_map)
    if 'enable_detect' in args:
        wan.enable_detect = args['enable_detect']
    if 'arp_detect' in args:
        wan.arp_detect = args['arp_detect']
    if 'monitor' in args:
        for monitor in args['monitor']:
            wan.monitor.append(monitor.encode('utf-8'))
    if 'detect_host' in args:
        for host in args['detect_host']:
            wan.detect_host.append(host)
    if 'enable_nic_check' in args:
        wan.enable_nic_check = args['enable_nic_check']
    if 'netif' in args:
        netif = args['netif']
        if 'ifname' in netif:
            wan.ifname = netif['ifname'].encode('utf-8')
        if 'enable' in netif:
            wan.enable = netif['enable']
        if 'ip_addr' in netif:
            for addr in netif['ip_addr']:
                addr_map = buildAddrElement(addr)
                wan.ip_addr_map.append(addr_map)
        if 'gw_addr' in netif:
            for addr in netif['gw_addr']:
                addr_map = buildAddrElement(addr)
                wan.gw_addr_map.append(addr_map)
        if 'gw_addr_v6' in netif:
            addr_map = buildAddrElement(netif['gw_addr_v6'])
            wan.gw_addr_v6_map = addr_map
        if 'max_up_bandwidth' in netif:
            wan.max_up_bandwidth = int(netif['max_up_bandwidth'])
        if 'max_down_bandwidth' in netif:
            wan.max_down_bandwidth = int(netif['max_down_bandwidth'])
        if 'up_busy_rate' in netif:
            wan.up_busy_rate = int(netif['up_busy_rate'])
        if 'down_busy_rate' in netif:
            wan.down_busy_rate = int(netif['down_busy_rate'])
    return wan


def createWanInfo(adapi, args):
    '''
    {
        'name': ,
        'inet_addr':[] ,
        'enable_detect': ,
        'arp_detect': ,
        'monitor':[] ,
        'detect_host':[] ,
        'enable_nic_check': ,
        'netif': {
            'ifname': ,
            'enable': ,
            'ip_addr': ,
            'gw_addr': ,
            'gw_addr_v6': ,
            'max_up_bandwidth': ,
            'max_down_bandwidth': ,
            'up_busy_rate': ,
            'down_busy_rate':
        }
    }
    '''
    # 新建wan口，必要参数
    if 'name' not in args or 'enable_detect' not in args \
       or 'enable_nic_check' not in args or 'netif' not in args:
        args_err_exit()
    # netif字段必要参数
    if 'ifname' not in args['netif'] or 'enable' not in args['netif'] \
       or 'ip_addr' not in args['netif']:
        args_err_exit()
    # gw_addr与gw_addr_v6必须有一个不为空
    if 'gw_addr' not in args['netif'] and 'gw_addr_v6' not in args['netif']:
        args_err_exit()
    wan = buildWanInfo(args)
    return adapi.createWanInfo(wan)


def updateWanInfo(adapi, args):
    '''
    {
        'wan_name': ,
        'name': ,
        'inet_addr':[] ,
        'enable_detect': ,
        'arp_detect': ,
        'monitor':[] ,
        'detect_host':[] ,
        'enable_nic_check': ,
        'netif': {
            'ifname': ,
            'enable': ,
            'ip_addr': ,
            'gw_addr': ,
            'gw_addr_v6': ,
            'max_up_bandwidth': ,
            'max_down_bandwidth': ,
            'up_busy_rate': ,
            'down_busy_rate':
        }
    }
    '''
    if 'wan_name' not in args:
        args_err_exit()
    wan = buildWanInfo(args)
    return adapi.updateWanInfo(args['wan_name'].encode('utf-8'), wan)


def deleteWanInfo(adapi, args):
    '''
    {'name':}
    '''
    if 'name' not in args:
        args_err_exit()
    return adapi.delWanInfo(args['name'].encode('utf-8'))


def getWanList(adapi, args):
    '''
    {}
    '''
    return adapi.getWanList()


def getWanInfo(adapi, args):
    '''
    {'name': }
    '''
    if 'name' not in args:
        args_err_exit()
    return adapi.getWanInfo(args['name'].encode('utf-8'))


# lan配置
def buildLanInfo(args):
    lan = LanInfo()
    if 'name' in args:
        lan.lan_name = args['name'].encode('utf-8')
    if 'enable_detect' in args:
        lan.enable_detect = args['enable_detect']
    if 'arp_detect' in args:
        lan.arp_detect = args['arp_detect']
    if 'detect_ip' in args:
            lan.detect_ip = args['detect_ip']
    if 'enable_nic_detect' in args:
        lan.enable_nic_detect = args['enable_nic_detect']
    if 'netif' in args:
        netif = args['netif']
        if 'ifname' in netif:
            lan.ifname = netif['ifname'].encode('utf-8')
        if 'enable' in netif:
            lan.enable = netif['enable']
        if 'ip_addr' in netif:
            for addr in netif['ip_addr']:
                info = None
                info_id = 1
                # 一定会有info字段
                if 'info' not in addr:
                    args_err_exit()
                info = addr['info']
                # info_id字段
                if 'info_id' in addr:
                    info_id = int(addr['info_id'])
                addr_map = AddrElement(info, info_id)
                lan.ip_addr_map.append(addr_map)
    return lan


def createLanInfo(adapi, args):
    '''
    {
        'name': ,
        'enable_detect': ,
        'arp_detect': ,
        'detect_ip': ,
        'enable_nic_detect': ,
        'netif': {
            'ifname': ,
            'enable': ,
            'ip_addr':
        }
    }
    '''
    # 新建lan口，必要参数
    if 'name' not in args or 'enable_detect' not in args \
       or 'netif' not in args:
        args_err_exit()
    # netif字段必要参数
    if 'ifname' not in args['netif'] or 'enable' not in args['netif'] \
       or 'ip_addr' not in args['netif']:
        args_err_exit()
    lan = buildLanInfo(args)
    return adapi.createLanInfo(lan)


def updateLanInfo(adapi, args):
    '''
    {
        'lan_name': ,
        'name': ,
        'enable_detect': ,
        'arp_detect': ,
        'detect_ip': ,
        'enable_nic_detect': ,
        'netif': {
            'ifname': ,
            'enable': ,
            'ip_addr':
        }
    }
    '''
    if 'lan_name' not in args:
        args_err_exit()
    lan = buildLanInfo(args)
    return adapi.updateLanInfo(args['lan_name'].encode('utf-8'), lan)


def deleteLanInfo(adapi, args):
    '''
    {'name':}
    '''
    if 'name' not in args:
        args_err_exit()
    return adapi.delLanInfo(args['name'].encode('utf-8'))


def getLanList(adapi, args):
    '''
    {}
    '''
    return adapi.getLanList()


def getLanInfo(adapi, args):
    '''
    {'name': }
    '''
    if 'name' not in args:
        args_err_exit()
    return adapi.getLanInfo(args['name'].encode('utf-8'))


# snat地址集
def buildSnatSet(args):
    snat = SnatSet()
    if 'name' in args:
        snat.name = args['name'].encode('utf-8')
    if 'ip_range' in args:
        for ipRange in args['ip_range']:
            addrType = None
            ipInfo = None
            if 'type' in ipRange:
                addrType = ipRange['type']
            if 'info' in ipRange:
                ipInfo = ipRange['info']
            snat.ip_range.append(AddrElement(ipInfo, 0, addrType))
    return snat


def createSnatSet(adapi, args):
    '''
    {
        'name': ,
        'ip_range': [
            {
                'type': ,
                'info':
            }
        ]
    }
    '''
    if 'name' not in args or 'ip_range' not in args:
        args_err_exit()
    snat = buildSnatSet(args)
    return adapi.createSnatSet(snat)


def updateSnatSet(adapi, args):
    '''
    {
        'snat_name': ,
        'name': ,
        'ip_range': [
            {
                'type': ,
                'info':
            }
        ]
    }
    '''
    if 'snat_name' not in args:
        args_err_exit()
    snat = buildSnatSet(args)
    return adapi.updateSnatSet(args['snat_name'].encode('utf-8'), snat)


def deleteSnatSet(adapi, args):
    '''
    {'name': }
    '''
    if 'name' not in args:
        args_err_exit()
    return adapi.deleteSnatSet(args['name'].encode('utf-8'))


def getSnatSet(adapi, args):
    '''
    {'name': }
    '''
    if 'name' not in args:
        args_err_exit()
    return adapi.getSnatSet(args['name'].encode('utf-8'))


def getSnatSetList(adapi, args):
    '''
    {}
    '''
    return adapi.getSnatSetList()


# 高级ACL
def buildAcl(args):
    acl = AclInfo()
    if 'name' in args:
        acl.name = args['name'].encode('utf-8')
    if 'enable' in args:
        acl.enable = args['enable']
    if 'vsname' in args:
        acl.vsname = args['vsname'].encode('utf-8')
    if 'connect_limit' in args:
        acl.connect_limit = int(args['connect_limit'])
    if 'src_addr' in args:
        addr = args['src_addr']
        if 'type' in addr:
            acl.type = addr['type']
        if 'info' in addr:
            acl.info = addr['info'].encode('utf-8')
    return acl


def createAcl(adapi, args):
    '''
    {
        'name': xx,
        'enable': xx,
        'vsname':xx,
        'connect_limit':xx,
        'src_addr': xx,
    }
    '''
    if 'name' not in args or 'enable' not in args or \
       'vsname' not in args or 'connect_limit' not in args or \
       'src_addr' not in args:
        args_err_exit()
    if 'type' not in args['src_addr']:
        args_err_exit()
    acl = buildAcl(args)
    return adapi.createAcl(acl)


def updateAcl(adapi, args):
    '''
    {
        'acl_name': xxx,
        xxxxx
    }
    '''
    if 'acl_name' not in args:
        args_err_exit()
    acl = buildAcl(args)
    return adapi.updateAcl(args['acl_name'].encode('utf-8'), acl)


def deleteAcl(adapi, args):
    '''
    {'name': xxx}
    '''
    if 'name' not in args:
        args_err_exit()
    return adapi.delAcl(args['name'].encode('utf-8'))


def getAclInfo(adapi, args):
    '''
    {'name': xxx}
    '''
    if 'name' not in args:
        args_err_exit()
    return adapi.getAdvanceAclInfo(args['name'].encode('utf-8'))


def getAclList(adapi, args):
    '''
    {}
    '''
    return adapi.getAdvanceAclList()


# 清除VAD配置
def resetConfig(adapi, args):
    '''
    {}
    '''
    return adapi.resetConfig()


callfunc = {
    # 服务
    'createServ': createServ,
    'addServPort': addServPort,
    'delServ': delServ,
    'delServPort': delServPort,
    'getServList': getServList,
    'getServInfo': getServInfo,
    # IP组
    'createIpGroup': createIpGroup,
    'addIp': addIp,
    'delIp': delIp,
    'delIpGroup': delIpGroup,
    'getIpGroupList': getIpGroupList,
    'getIpGroupInfo': getIpGroupInfo,
    # 会话保持
    'createPersist': createPersist,
    'updatePersist': updatePersist,
    'delPersist': delPersist,
    'getPersistList': getPersistList,
    'getPersistInfo': getPersistInfo,
    # 节点监视器
    'createNodeMonitor': createNodeMonitor,
    'updateNodeMonitor': updateNodeMonitor,
    'delNodeMonitor': delNodeMonitor,
    'getNodeMonitorList': getNodeMonitorList,
    'getNodeMonitorInfo': getNodeMonitorInfo,
    # 节点池
    'createNode': createNodeV2,
    'updateNode': updateNodeV2,
    'delNode': delNodeV2,
    'getNodeList': getNodeListV2,
    'getNodeInfo': getNodeV2Info,
    'getNodesStatus': getNodesV2Status,
    'createNodePool': createNodePool,
    'updateNodePool': updateNodePool,
    'delNodePool': delNodePool,
    'addPoolMonitor': addPoolMonitor,
    'delPoolMonitor': delPoolMonitor,
    'getNodePoolList': getNodePoolListV2,
    'getNodePoolInfo': getNodePoolInfoV2,
    # 策略
    # 虚拟服务
    'createVs': createVs,
    'updateVs': updateVs,
    'delVs': delVs,
    'getVsList': getVsList,
    'getVsInfo': getVsInfo,
    'getVsStatus': getVsStatus,
    # 静态路由配置
    'createStaticRoute': createStaticRoute,
    'updateStaticRoute': updateStaticRoute,
    'delStaticRoute': delStaticRoute,
    'getStaticRouteInfo': getStaticRouteInfo,
    # netns配置
    'createNetnsInfo': createNetnsInfo,
    'updateNetnsInfo': updateNetnsInfo,
    'deleteNetnsInfo': deleteNetnsInfo,
    'getNetnsInfo': getNetnsInfo,
    # macvlan配置
    'createMacvlanInfo': createMacvlanInfo,
    'updateMacvlanInfo': updateMacvlanInfo,
    'deleteMacvlanInfo': deleteMacvlanInfo,
    'getMacvlanInfo': getMacvlanInfo,
    # vlan配置
    'createVlanInfo': createVlanInfo,
    'updateVlanInfo': updateVlanInfo,
    'deleteVlanInfo': deleteVlanInfo,
    'getVlanInfo': getVlanInfo,
    # wan配置
    'createWanInfo': createWanInfo,
    'updateWanInfo': updateWanInfo,
    'deleteWanInfo': deleteWanInfo,
    'getWanList': getWanList,
    'getWanInfo': getWanInfo,
    # lan配置
    'createLanInfo': createLanInfo,
    'updateLanInfo': updateLanInfo,
    'deleteLanInfo': deleteLanInfo,
    'getLanList': getLanList,
    'getLanInfo': getLanInfo,
    # snat地址集
    'createSnatSet': createSnatSet,
    'updateSnatSet': updateSnatSet,
    'deleteSnatSet': deleteSnatSet,
    'getSnatSet': getSnatSet,
    'getSnatSetList': getSnatSetList,
    # 高级ACL
    'createAcl': createAcl,
    'updateAcl': updateAcl,
    'deleteAcl': deleteAcl,
    'getAclInfo': getAclInfo,
    'getAclList': getAclList,
    # 清除VAD配置
    'resetConfig': resetConfig
}


class VadProxy:
    '''
    vAD代理处理类
    '''
    def __init__(self, jsonData):
        self.jsonData = jsonData
        self.args = []
        self.apiFunc = None
        self.apiName = None
        self.vadAddr = None
        self.vadPort = None
        self.vadUname = None
        self.vadPasswd = None

    def parseJsonArgs(self):
        if 'adaddr' in self.jsonData:
            self.vadAddr = self.jsonData['adaddr']
        if 'adport' in self.jsonData:
            self.vadPort = int(self.jsonData['adport'])
        if 'adusername' in self.jsonData:
            self.vadUname = self.jsonData['adusername']
        if 'adpasswd' in self.jsonData:
            self.vadPasswd = self.jsonData['adpasswd']
        if 'function' in self.jsonData:
            self.apiName = self.jsonData['function']
        if 'args' in self.jsonData:
            self.args = self.jsonData['args']
        if self.vadAddr is None or self.vadPort is None or \
           self.vadUname is None or \
           self.vadPasswd is None or self.apiName is None:
            #err_exit(VAD_PROXY_ERR_CODE, 'Less args')
            return False

        return True

    def vadProxyHandle(self):
        # 先解析json，获取vad信息
        if not self.parseJsonArgs():
            return err_exit(VAD_PROXY_ERR_CODE, 'Less args')

        # 解析获取api函数
        adapi = REST_ADAPI(self.vadUname,
                           self.vadPasswd,
                           self.vadAddr,
                           self.vadPort)
        if self.apiName in callfunc:
            self.apiFunc = callfunc[self.apiName]
        else:
            return err_exit(VAD_PROXY_ERR_CODE, 'function name error')
        # 调用指定api
        retData = None
        try:
            retData = self.apiFunc(adapi, self.args)
        except Exception, e:
            return err_exit(e.code, e.reason)
        # POST接口返回值
        if type(retData) == dict:
            return json.dumps(retData, ensure_ascii=False)
            #sys.exit(0)
        # GET接口数据返回
        xmlStr = retData.originStr.encode('utf-8')
        retJson = None
        try:
            retDict = xmltodict.parse(xmlStr)
            retJson = json.dumps(retDict, ensure_ascii=False)
        except Exception:
            return err_exit(VAD_PROXY_ERR_CODE, VAD_PROXY_ERR_INFO)
        LOG.error("vadProxyHandle retjson %s"%retJson)
        return retJson
        #sys.exit(0)


def main():
    '''
    CMD_VAD_PROXY_CTL = 202 # vAD代理ADAPI
    '''
    try:
        with open("/tmp/vad_proxy_ctl.tmp", "a+") as f:
            if len(sys.argv) >= 3:
                f.write(sys.argv[2]+"\n")
            else:
                f.write("len less than 3\m")
        if len(sys.argv) != 3:
            strerr = 'vad_proxy_ctl parameter error.number of ' \
                     'parameter:%d' % len(sys.argv)
            err_exit(VAD_PROXY_ERR_CODE, strerr)
        jsonData = json.loads(sys.argv[2])
        apiProxy = VadProxy(jsonData)
        apiProxy.vadProxyHandle()
    except Exception:
        err_exit(VAD_PROXY_ERR_CODE, traceback.format_exc())


if __name__ == "__main__":
    main()
    
