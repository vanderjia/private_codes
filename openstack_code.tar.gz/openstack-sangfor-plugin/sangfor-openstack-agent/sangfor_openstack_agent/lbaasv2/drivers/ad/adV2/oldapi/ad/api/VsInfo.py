# -*- coding: utf-8 -*-
# Copyright (c) 2008-2016, AD SANGFOR, [Version 6.3.0]
# Filename: VsInfo.py

from Configuration import Configuration
from APIException import APIException
from ErrorInfo import ErrInfo
from http.HttpClient import HttpClient
from urllib2 import base64
import XMLObject as xmlo
import urllib
from ParentList import ParentList

class VsInfoStatus (ErrInfo) :
    def __init__(self, httpBody = None) :
        ErrInfo.__init__(self, httpBody)
        self.name = None
        self.inbytes = -1
        self.outbyte = -1
        self.inpackets = -1
        self.outpackets = -1
        self.curconns = -1
        self.newconns = -1
        self.maxconns = -1
        self.totalconns = -1
        self.requests = -1
        self.mysqlreadrate = -1
        self.mysqlwriterate = -1
        if httpBody == "" or httpBody == None :
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0 :
            return
        if not isinstance(httpBody, unicode) :
                httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)
            if self.xmlObj.hasTag("name") :
                self.name = urllib.unquote(Configuration.base64decode(self.xmlObj["name"][0].getChildValue()))
            if self.xmlObj.hasTag("inbytes") :
                self.inbytes = self.xmlObj["inbytes"][0].getChildValue()
            if self.xmlObj.hasTag("outbyte") :
               self.outbyte = self.xmlObj["outbyte"][0].getChildValue()
            if self.xmlObj.hasTag("inpackets") :
               self.inpackets = self.xmlObj["inpackets"][0].getChildValue()
            if self.xmlObj.hasTag("outpackets") :
                self.outpackets = self.xmlObj["outpackets"][0].getChildValue()
            if self.xmlObj.hasTag("curconns") :
               self.curconns = self.xmlObj["curconns"][0].getChildValue()
            if self.xmlObj.hasTag("newconns") :
               self.newconns = self.xmlObj["newconns"][0].getChildValue()
            if self.xmlObj.hasTag("maxconns") :
                self.maxconns = self.xmlObj["maxconns"][0].getChildValue()
            if self.xmlObj.hasTag("totalconns") :
               self.totalconns = self.xmlObj["totalconns"][0].getChildValue()
            if self.xmlObj.hasTag("requests") :
               self.requests = self.xmlObj["requests"][0].getChildValue()
            if self.xmlObj.hasTag("mysqlreadrate") :
               self.mysqlreadrate = self.xmlObj["mysqlreadrate"][0].getChildValue()
            if self.xmlObj.hasTag("mysqlwriterate") :
               self.mysqlwriterate = self.xmlObj["mysqlwriterate"][0].getChildValue()
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)
    def __str__(self) :
        return self.originStr
class VsInfo (ErrInfo) :
    def __init__(self, httpBody = None) :
        ErrInfo.__init__(self, httpBody)
        self.vsName = None
        self.enable = None
        self.mode = None
        self.httpschedMode = None
        self.tcpCacheStream = None
        self.tcpCacheNum = -1
        self.endStr = None
        self.preProfile = None
        self.serviceName = None
        self.ipgName = None
        self.poolName = None
        self.autoSnat = None
        self.snatPool = None
        self.dnat_enable = None
        self.sslProfile = None
        self.httpRedirEnable = None
        self.port = -1
        self.separate_enable = None
        self.read_pool = None
        self.mysql_profile = None
        self.netnsId = -1
        if httpBody == "" or httpBody == None :
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0 :
            return
        if not isinstance(httpBody, unicode) :
                httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)
            if self.xmlObj.hasTag("name") :
                self.vsName = urllib.unquote(Configuration.base64decode(self.xmlObj["name"][0].getChildValue()))
            if self.xmlObj.hasTag("enable") :
                self.enable = self.xmlObj["enable"][0].getChildValue()
            if self.xmlObj.hasTag("mode") :
               self.mode = self.xmlObj["mode"][0].getChildValue()
            if self.xmlObj.hasTag("service_name") :
               self.serviceName = urllib.unquote(Configuration.base64decode(self.xmlObj["service_name"][0].getChildValue()))
            if self.xmlObj.hasTag("ip_group_name") :
                self.ipgName = urllib.unquote(Configuration.base64decode(self.xmlObj["ip_group_name"][0].getChildValue()))
            if self.xmlObj.hasTag("node_pool_name") :
                self.poolName = urllib.unquote(Configuration.base64decode(self.xmlObj["node_pool_name"][0].getChildValue()))
            if self.xmlObj.hasTag("tcp_cache_stream") :
                self.tcpCacheStream = self.xmlObj["tcp_cache_stream"][0].getChildValue()
            if self.xmlObj.hasTag("auto_snat") :
               self.autoSnat = self.xmlObj["auto_snat"][0].getChildValue()
            if self.xmlObj.hasTag("snat_pool") :
               self.snatPool = urllib.unquote(Configuration.base64decode(self.xmlObj["snat_pool"][0].getChildValue()))
            if self.xmlObj.hasTag("dnat_enable") :
                self.dnat_enable = urllib.unquote(self.xmlObj["dnat_enable"][0].getChildValue())
            if self.xmlObj.hasTag("http_sched_mode") :
                self.httpschedMode = self.xmlObj["http_sched_mode"][0].getChildValue()
            if self.xmlObj.hasTag("tcp_cache_num") :
                self.tcpCacheNum = self.xmlObj["tcp_cache_num"][0].getChildValue()
            if self.xmlObj.hasTag("end_str") :
                self.endStr = self.xmlObj["end_str"][0].getChildValue()
            if self.xmlObj.hasTag("preProfile") :
                self.pre_rule = urllib.unquote(Configuration.base64decode(self.xmlObj["preProfile"][0].getChildValue()))
            if self.xmlObj.hasTag("ssl_profile") :
                self.sslProfile = urllib.unquote(Configuration.base64decode(self.xmlObj["ssl_profile"][0].getChildValue()))
            if self.xmlObj.hasTag("httpRedirEnable") :
                self.http_redir_enable = self.xmlObj["httpRedirEnable"][0].getChildValue()
            if self.xmlObj.hasTag("port") :
                self.port = self.xmlObj["port"][0].getChildValue()
            if self.xmlObj.hasTag("separate_enable"):
                self.separate_enable = self.xmlObj["separate_enable"][0].getChildValue()
            if self.xmlObj.hasTag("read_pool") :
                self.read_pool = urllib.unquote(Configuration.base64decode(self.xmlObj["read_pool"][0].getChildValue()))
            if self.xmlObj.hasTag("mysql_profile") :
                self.mysql_profile = urllib.unquote(Configuration.base64decode(self.xmlObj["mysql_profile"][0].getChildValue()))
            
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)
    def __str__(self) :
        return self.originStr
        
    @classmethod
    def sslinfoToXml(cls, vs) :
        params = ""
        if vs.sslProfile != None :
            params += "<ssl_profile>" + base64.b64encode(vs.sslProfile) + "</ssl_profile>\n"
        if vs.httpRedirEnable != None :
            params += "<http_redir_enable>" + str(vs.httpRedirEnable) + "</http_redir_enable>\n"
        if vs.port != -1 :
            params += "<port>" + str(vs.port) + "</port>\n"
        return params
    
    @classmethod
    def vsinfoToXml(cls, vs, action) :
        params = "<vs_info>\n"
        if vs.vsName != None :
            params += "<name>" + base64.b64encode(vs.vsName) + "</name>\n"
        if vs.enable != None :
            params += "<enable>" + str(vs.enable) + "</enable>\n"
        if (vs.mode != None) and (action == "create") :
            params += "<mode>" + vs.mode + "</mode>\n"
        if vs.httpschedMode != None :
            params += "<http_sched_mode>" + vs.httpschedMode + "</http_sched_mode>\n"
        if vs.tcpCacheStream != None :
            params += "<tcp_cache_stream>" + str(vs.tcpCacheStream) + "</tcp_cache_stream>\n"
        if vs.tcpCacheNum != -1 :
            params += "<tcp_cache_num>" + str(vs.tcpCacheNum) + "</tcp_cache_num>\n"
        if vs.endStr != None :
            params += "<end_str>" + vs.endStr + "</end_str>\n"
        if vs.preProfile != None :
            pre_array = vs.preProfile.split(';')
            for pre in pre_array :
                params += "<pre_rule>" + base64.b64encode(pre) + "</pre_rule>\n"
        if vs.serviceName != None :
            params += "<service_name>" + base64.b64encode(vs.serviceName) + "</service_name>\n"
        if vs.ipgName != None :
            params += "<ip_group_name>" + base64.b64encode(vs.ipgName) + "</ip_group_name>\n"
        if vs.poolName != None :
            params += "<node_pool_name>" + base64.b64encode(vs.poolName) + "</node_pool_name>\n"
        if vs.autoSnat != None :
            params += "<auto_snat>" + str(vs.autoSnat) + "</auto_snat>\n"
        if vs.snatPool != None :
            params += "<snat_pool>" + base64.b64encode(vs.snatPool) + "</snat_pool>\n"
        if vs.dnat_enable != None :
            params += "<dnat_enable>" + str(vs.dnat_enable) + "</dnat_enable>\n"
        ssl = VsInfo.sslinfoToXml(vs)
        if ssl != "" :
            params += "<ssl>\n" + ssl + "</ssl>\n"
        if vs.separate_enable != None:
            params += "<separate_enable>" + str(vs.separate_enable) + "</separate_enable>\n"
        if vs.read_pool != None :
            params += "<read_pool>" + base64.b64encode(vs.read_pool) + "</read_pool>\n"
        if (vs.mysql_profile != None) and (action == "create") :
            params += "<mysql_profile>" + base64.b64encode(vs.mysql_profile) + "</mysql_profile>\n"
        if (vs.netnsId != -1) and (action == "create") :
            params += "<netns_id>" + str(vs.netnsId) + "</netns_id>\n"
        params += "</vs_info>\n"
        return params
    @classmethod
    def generatingvsList(cls, httpBody) :
        return VsList(httpBody)
    @classmethod
    def generatingvsInfo(cls, httpBody) :
        return VsInfo(httpBody)
    @classmethod
    def generatingvsStatus(cls, httpBody) :
        return VsList(httpBody)
        
class VsList (ParentList) :
    '''
    从xml中获取节点列表
    '''
    def __init__(self, httpBody = None) :
        ParentList.__init__(self, httpBody)
        # self.vsList = []
        # self.length = 0
        if httpBody == None or httpBody == "" :
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0 :
            return
        if not isinstance(httpBody, unicode) :
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)
            if self.xmlObj.hasTag("VsBaseInfoListType"):
                if not self.xmlObj.hasTag("vs_base_info"):
                    return
                vsListXmlObj = self.xmlObj["vs_base_info"]
            elif self.xmlObj.hasTag("VsViewInfoType") :
                vsListXmlObj = self.xmlObj["VsViewInfoType"]
            elif self.xmlObj.hasTag("VsStatusListType") :
                if not self.xmlObj.hasTag("vs_status"):
                    return
                vsListXmlObj = self.xmlObj["vs_status"]
            else:
                return
            #print len(vsListXmlObj)
            if self.xmlObj.hasTag("VsStatusListType") :
                for i in range(len(vsListXmlObj)) :
                    #print vsListXmlObj[i].toxml()
                    node = VsInfoStatus(vsListXmlObj[i].toxml())
                    self.elementList.append(node)
                    self.length += 1
            else:
                for i in range(len(vsListXmlObj)) :
                    #print vsListXmlObj[i].toxml()
                    node = VsInfo(vsListXmlObj[i].toxml())
                    self.elementList.append(node)
                    self.length += 1
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)
