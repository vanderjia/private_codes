# -*- coding: utf-8 -*-
# Copyright (c) 2008-2020, AD SANGFOR
# Filename: VSInfo.py
# 定义虚拟服务配置信息
from APIException import APIException
from ErrorInfo import ErrInfo
from ParentList import ParentList
from urllib2 import base64
import JSONObj as jsono
import urllib
import json
import codecs


class VSStatus(ErrInfo):
    def __init__(self, httpBody=None):
        ErrInfo.__init__(self, httpBody)
        self.name = None
        self.inbytes = -1
        self.outbytes = -1
        self.inpackets = -1
        self.outpackets = -1
        self.curconns = -1
        self.newconns = -1
        self.maxconns = -1
        self.totalconns = -1
        self.requests = -1
        self.mysqlreadrate = -1
        self.mysqlwriterate = -1
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
                httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('name'):
                self.name = urllib.unquote(
                    base64.b64decode(self.jsonObj['name']))
            if self.jsonObj.hasTag('inbytes'):
                self.inbytes = self.jsonObj['inbytes']
            if self.jsonObj.hasTag('outbytes'):
                self.outbytes = int(self.jsonObj['outbytes'])
            if self.jsonObj.hasTag('inpackets'):
                self.inpackets = int(self.jsonObj['inpackets'])
            if self.jsonObj.hasTag('outpackets'):
                self.outpackets = int(self.jsonObj['outpackets'])
            if self.jsonObj.hasTag('curconns'):
                self.curconns = int(self.jsonObj['curconns'])
            if self.jsonObj.hasTag('newconns'):
                self.newconns = int(self.jsonObj['newconns'])
            if self.jsonObj.hasTag('maxconns'):
                self.maxconns = int(self.jsonObj['maxconns'])
            if self.jsonObj.hasTag('totalconns'):
                self.totalconns = int(self.jsonObj['totalconns'])
            if self.jsonObj.hasTag('requests'):
                self.requests = int(self.jsonObj['requests'])
            if self.jsonObj.hasTag('mysqlreadrate'):
                self.mysqlreadrate = int(self.jsonObj['mysqlreadrate'])
            if self.jsonObj.hasTag('mysqlwriterate'):
                self.mysqlwriterate = int(self.jsonObj['mysqlwriterate'])
        except jsono.JSONObjException as e:
            raise APIException(3, e.reason)


class VSInfo(ErrInfo):
    def __init__(self, httpBody=None):
        ErrInfo.__init__(self, httpBody)
        self.name = None
        self.enable = None
        self.mode = None
        self.httpSchedMode = None
        self.tcpCacheStream = None
        self.tcpCacheNum = -1
        self.endStr = None
        self.preProfile = []
        self.serviceName = None
        self.ipgName = None
        self.poolName = None
        self.autoSnat = None
        self.snatPool = None
        self.dnatEnable = None
        self.sslProfile = None
        self.httpRedirEnable = None
        self.port = -1
        self.separateEnable = None
        self.readPool = None
        self.mysqlProfile = None
        self.netnsId = -1
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
                httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            # VSList
            if self.jsonObj.hasTag('name'):
                self.name = urllib.unquote(
                    base64.b64decode(self.jsonObj['name']))
            if self.jsonObj.hasTag('enable'):
                self.enable = self.jsonObj['enable']
            if self.jsonObj.hasTag('mode'):
                self.mode = self.jsonObj['mode']
            if self.jsonObj.hasTag('service_name'):
                self.serviceName = urllib.unquote(
                    base64.b64decode(self.jsonObj['service_name']))
            if self.jsonObj.hasTag('ip_group_name'):
                self.ipgName = urllib.unquote(
                    base64.b64decode(self.jsonObj['ip_group_name']))
            if self.jsonObj.hasTag('node_pool_name'):
                self.poolName = urllib.unquote(
                    base64.b64decode(self.jsonObj['node_pool_name']))
            # VSInfo
            if self.jsonObj.hasTag('VsViewInfoType'):
                vsInfo = self.jsonObj['VsViewInfoType']
                if 'name' in vsInfo:
                    self.name = urllib.unquote(
                        base64.b64decode(vsInfo['name']))
                if 'enable' in vsInfo:
                    self.enable = vsInfo['enable']
                if 'mode' in vsInfo:
                    self.mode = vsInfo['mode']
                if 'http_sched_mode' in vsInfo:
                    self.httpSchedMode = vsInfo['http_sched_mode']
                if 'tcp_cache_stream' in vsInfo:
                    self.tcpCacheStream = vsInfo['tcp_cache_stream']
                if 'service_name' in vsInfo:
                    self.serviceName = urllib.unquote(
                        base64.b64decode(vsInfo['service_name']))
                if 'ip_group_name' in vsInfo:
                    self.ipgName = urllib.unquote(
                        base64.b64decode(vsInfo['ip_group_name']))
                if 'node_pool_name' in vsInfo:
                    self.poolName = urllib.unquote(
                        base64.b64decode(vsInfo['node_pool_name']))
                if 'auto_snat' in vsInfo:
                    self.autoSnat = vsInfo['auto_snat']
                if 'snat_pool' in vsInfo:
                    self.snatPool = urllib.unquote(
                        base64.b64decode(vsInfo['snat_pool']))
                if 'dnat_enable' in vsInfo:
                    self.dnatEnable = urllib.unquote(
                        vsInfo['dnat_enable'])
                if 'tcp_cache_num' in vsInfo:
                    self.tcpCacheNum = int(vsInfo['tcp_cache_num'])
                if 'end_str' in vsInfo:
                    self.endStr = vsInfo['end_str']
                if 'pre_rule' in vsInfo:
                    preProfile = vsInfo['pre_rule']
                    if isinstance(preProfile, list):
                        for pre in preProfile:
                            self.preProfile.append(urllib.unquote(pre))
                    else:
                        self.preProfile.append(urllib.unquote(preProfile))
                if 'ssl_profile' in vsInfo:
                    self.sslProfile = urllib.unquote(vsInfo['ssl_profile'])
                if 'http_redir_enable' in vsInfo:
                    self.httpRedirEnable = vsInfo['http_redir_enable']
                if 'port' in vsInfo:
                    self.port = int(vsInfo['port'])
                if 'separate_enable' in vsInfo:
                    self.separateEnable = vsInfo['separate_enable']
                if 'read_pool' in vsInfo:
                    self.readPool = urllib.unquote(
                        base64.b64decode(vsInfo['read_pool']))
                if 'mysql_profile' in vsInfo:
                    self.mysqlProfile = urllib.unquote(
                        base64.b64decode(vsInfo['mysql_profile']))
        except jsono.JSONObjException as e:
            raise APIException(3, e.reason)

    def __str__(self):
        return self.originStr

    @classmethod
    def sslToDict(cls, vs):
        sslDict = {}
        if vs.sslProfile is not None:
            sslDict['ssl_profile'] = vs.sslProfile
        if vs.httpRedirEnable is not None:
            sslDict['http_redir_enable'] = vs.httpRedirEnable
        if vs.port != -1:
            sslDict['port'] = vs.port

    @classmethod
    def vsInfoToDict(cls, vs):
        vsDict = {}
        if vs.name is not None:
            vsDict['name'] = vs.name
        if vs.enable is not None:
            vsDict['enable'] = vs.enable
        if vs.mode is not None:
            vsDict['mode'] = vs.mode
        if vs.httpSchedMode is not None:
            vsDict['http_sched_mode'] = vs.httpSchedMode
        if vs.tcpCacheStream is not None:
            vsDict['tcp_cache_stream'] = vs.tcpCacheStream
        if vs.tcpCacheNum != -1:
            vsDict['tcp_cache_num'] = vs.tcpCacheNum
        if vs.endStr is not None:
            vsDict['end_str'] = vs.endStr
        if len(vs.preProfile) != 0:
            vsDict['pre_rule'] = ';'.join(sv.preProfile)
        if vs.serviceName is not None:
            vsDict['service_name'] = vs.serviceName
        if vs.ipgName is not None:
            vsDict['ip_group_name'] = vs.ipgName
        if vs.poolName is not None:
            vsDict['node_pool_name'] = vs.poolName
        if vs.autoSnat is not None:
            vsDict['auto_snat'] = vs.autoSnat
        if vs.snatPool is not None:
            vsDict['snat_pool'] = vs.snatPool
        if vs.dnatEnable is not None:
            vsDict['dnat_enable'] = vs.dnatEnable
        if vs.netnsId != -1:
            vsDict['netns_id'] = vs.netnsId
        sslRule = VSInfo.sslToDict(vs)
        if sslRule:
            vsDict['ssl'] = sslRule
        return vsDict

    @classmethod
    def generatingVSList(cls, httpBody):
        return VSList(httpBody)

    @classmethod
    def generatingVSInfo(cls, httpBody):
        return VSInfo(httpBody)

    @classmethod
    def generatingVSStatus(cls, httpBody):
        return VSList(httpBody)


class VSList(ParentList):
    def __init__(self, httpBody=None):
        ParentList.__init__(self, httpBody)
        if httpBody is None or httpBody == "":
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            # VSList
            if self.jsonObj.hasTag('VsBaseInfoListType'):
                if self.jsonObj['VsBaseInfoListType'] is None:
                    return
                vsList = self.jsonObj['VsBaseInfoListType']
                if 'vs_base_info' in vsList:
                    vsInfo = vsList['vs_base_info']
                    if isinstance(vsInfo, list):
                        for vs in vsInfo:
                            item = VSInfo(json.dumps(vs, ensure_ascii=False))
                            self.elements.append(item)
                    else:
                        item = VSInfo(json.dumps(vsInfo, ensure_ascii=False))
                        self.elements.append(item)
            # VSStatus
            if self.jsonObj.hasTag('VsStatusListType'):
                if self.jsonObj['VsStatusListType'] is None:
                    return
                vsList = self.jsonObj['VsStatusListType']
                if 'vs_status' in vsList:
                    vsStatus = vsList['vs_status']
                    if isinstance(vsStatus, list):
                        for status in vsStatus:
                            item = VSStatus(json.dumps(status,
                                ensure_ascii=False))
                            self.elements.append(item)
                    else:
                        item = VSStatus(json.dumps(vsStatus,
                            ensure_ascii=False))
                        self.elements.append(item)
        except jsono.JSONObjException as e:
            raise APIException(3, e.reason)
