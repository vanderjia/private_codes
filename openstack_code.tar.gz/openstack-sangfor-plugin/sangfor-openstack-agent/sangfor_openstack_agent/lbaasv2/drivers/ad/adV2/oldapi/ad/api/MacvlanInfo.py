# -*- coding: utf-8 -*-
# Copyright (c) 2008-2016, AD SANGFOR, [Version 6.3.0]
# Filename: MacvlanInfo.py

from Configuration import Configuration
from APIException import APIException
from ErrorInfo import ErrInfo
from urllib2 import base64
import XMLObject as xmlo
import urllib
from ParentList import ParentList
from AddrElement import AddrElement


class MacvlanInfo (ErrInfo) :
    def __init__(self, httpBody = None) :
        ErrInfo.__init__(self, httpBody)
        self.name = None
        self.enable = None
        self.device = None
        self.ifname = None
        self.mac = None
        self.netns_id = 0
        if httpBody == "" or httpBody == None :
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0 :
            return
        if not isinstance(httpBody, unicode) :
                httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)
            if self.xmlObj.hasTag("name") :
                self.name = urllib.unquote(Configuration.base64decode(self.xmlObj["name"][0].getChildValue()))
            if self.xmlObj.hasTag("ifname") :
                self.ifname = urllib.unquote(Configuration.base64decode(self.xmlObj['ifname'][0].getChildValue()))
            if self.xmlObj.hasTag("device") :
                self.device = urllib.unquote(Configuration.base64decode(self.xmlObj['device'][0].getChildValue()))
            if self.xmlObj.hasTag("mac") :
                self.mac = urllib.unquote(Configuration.base64decode(self.xmlObj['mac'][0].getChildValue()))
            if self.xmlObj.hasTag("enable") :
                self.enable = self.xmlObj['enable'][0].getChildValue()
            if self.xmlObj.hasTag("netns_id") :
                self.netns_id = self.xmlObj['netns_id'][0].getChildValue()
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)

    def __str__(self) :
        return self.originStr

    @classmethod
    def macvlanInfoToXml(cls, macvlanInfo):
        '''
        拼接发送信息
        '''
        params = ''
        if macvlanInfo is not None:
            params += '<macvlan_info>'
            if macvlanInfo.name is not None:
                params += '<name>' + base64.b64encode(macvlanInfo.name) + '</name>'
            if macvlanInfo.enable is not None:
                params += '<enable>' + macvlanInfo.enable + '</enable>'
            if macvlanInfo.ifname is not None:
                params += '<ifname>' + base64.b64encode(macvlanInfo.ifname) + '</ifname>'
            if macvlanInfo.mac is not None:
                params += '<mac>' + base64.b64encode(macvlanInfo.mac) + '</mac>'
            if macvlanInfo.netns_id is not None:
                params += '<netns_id>' + str(macvlanInfo.netns_id) + '</netns_id>'
            params += '</macvlan_info>'
        return params

    @classmethod
    def generatingMacvlanInfo(cls, httpBody) :
        return MacvlanInfo(httpBody)

