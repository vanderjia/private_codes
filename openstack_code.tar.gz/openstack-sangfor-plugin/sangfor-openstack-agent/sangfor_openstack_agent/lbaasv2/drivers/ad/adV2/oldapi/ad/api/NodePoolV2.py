# -*- coding: utf-8 -*-
# Copyright (c) 2008-2016, AD SANGFOR, [Version 6.3.0]
# Filename: NodePoolV2.py

import XMLObject as xmlo
from APIException import APIException
from ErrorInfo import ErrInfo
from urllib2 import base64
import urllib
from Configuration import Configuration
from ParentList import ParentList

class NodePoolV2 (ErrInfo) :
    '''
    从xml中获取节点池信息
    '''
    def __init__(self, httpBody = None) :
        ErrInfo.__init__(self, httpBody)
        self.name = None
        self.lbMethod = None
        self.hashType = None
        self.persist1Name = None
        self.persist2Name = None
        self.monitors = None
        self.minMonitors = -1
        self.recoverInterval = -1
        self.stepperInterval = -1
        self.schedMethod = None
        self.connStatAll = None
        self.queueLength = -1
        self.queueTimeout = -1
        self.nodeNumber = -1
        self.netnsId = -1
        
        if httpBody == None or httpBody == "":
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0 :
            return
        if not isinstance(httpBody, unicode) :
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)
            if self.xmlObj.hasTag("node_pool_name") :
                self.name = urllib.unquote(Configuration.base64decode(self.xmlObj["node_pool_name"][0].getChildValue()))
            if self.xmlObj.hasTag("node_number") :
                self.nodeNumber = self.xmlObj["node_number"][0].getChildValue()
            if self.xmlObj.hasTag("node_lb_method") :
                self.lbMethod = self.xmlObj["node_lb_method"][0].getChildValue()
            if self.xmlObj.hasTag("hash_type") :
                self.hashType = self.xmlObj["hash_type"][0].getChildValue()
            if self.xmlObj.hasTag("persist1_name") :
                self.persist1Name = self.xmlObj["persist1_name"][0].getChildValue()
            if self.xmlObj.hasTag("persist2_name") :
                self.persist2Name = self.xmlObj["persist2_name"][0].getChildValue()
            if self.xmlObj.hasTag("monitors") :
                self.monitors = []
                for monitors in self.xmlObj["monitors"]:
                    self.monitors.append(monitors.getChildValue())
            if self.xmlObj.hasTag("min_monitors") :
                self.minMonitors = self.xmlObj["min_monitors"][0].getChildValue()
            if self.xmlObj.hasTag("recover_interval") :
                self.recoverInterval = self.xmlObj["recover_interval"][0].getChildValue()
            if self.xmlObj.hasTag("stepper_interval") :
                self.stepperInterval = self.xmlObj["stepper_interval"][0].getChildValue()
            if self.xmlObj.hasTag("sched_method") :
                self.schedMethod = self.xmlObj["sched_method"][0].getChildValue()
            if self.xmlObj.hasTag("conn_stat_all") :
                self.connStatAll = self.xmlObj["conn_stat_all"][0].getChildValue()
            if self.xmlObj.hasTag("queue_length") :
                self.queueLength = self.xmlObj["queue_length"][0].getChildValue()
            if self.xmlObj.hasTag("queue_timeout") :
                self.queueTimeout = self.xmlObj["queue_timeout"][0].getChildValue()

        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)
    def __str__(self) :
        return str(self.originStr)
    #@staticmethod
    @classmethod
    def generatingPoolList(cls, httpBody) :
        return PoolList(httpBody)
    @classmethod
    def generatingPoolInfo(cls, httpBody) :
        return NodePoolV2(httpBody)
    @classmethod
    def poolinfoToXml(cls, pool) :
        params = "<node_pool_info>\n"
        if pool.name != None :
            pool.name = base64.b64encode(pool.name)
            params += "<node_pool_name>" + pool.name + "</node_pool_name>\n"
        if pool.lbMethod != None :
            params += "<node_lb_method>" + pool.lbMethod + "</node_lb_method>\n"
        if pool.hashType != None :
            params += "<hash_type>" + pool.hashType + "</hash_type>\n"
        if pool.persist1Name != None :
            pool.persist1Name = base64.b64encode(pool.persist1Name)
            params += "<persist1_name>" + pool.persist1Name + "</persist1_name>\n"
        if pool.persist2Name != None :
            pool.persist2Name = base64.b64encode(pool.persist2Name)
            params += "<persist2_name>" + pool.persist2Name + "</persist2_name>\n"
        if pool.monitors != None :
            monitors_array = pool.monitors.split(';')
            for monitor in monitors_array :
                params += "<monitors>" + base64.b64encode(monitor) + "</monitors>\n"
        if pool.minMonitors != -1 :
            params += "<min_monitors>" + str(pool.minMonitors) + "</min_monitors>\n"
        if pool.recoverInterval != -1 :
            params += "<recover_interval>" + str(pool.recoverInterval) + "</recover_interval>\n"
        if pool.stepperInterval != -1 :
            params += "<stepper_interval>" + str(pool.stepperInterval) + "</stepper_interval>\n"
        if pool.schedMethod != None :
            params += "<sched_method>" + pool.schedMethod + "</sched_method>\n"
        if pool.connStatAll != None :
            params += "<conn_stat_all>" + pool.connStatAll + "</conn_stat_all>\n"
        if pool.queueLength != -1 :
            params += "<queue_length>" + str(pool.queueLength) + "</queue_length>\n"
        if pool.queueTimeout != -1 :
            params += "<queue_timeout>" + str(pool.queueTimeout) + "</queue_timeout>\n"
        if pool.netnsId != -1 :
            params += "<netns_id>" + str(pool.netnsId) + "</netns_id>\n"
        params += "</node_pool_info>\n"
        return params

class PoolList (ParentList) :
    '''
    从xml中获取节点池列表
    '''
    def __init__(self, httpBody = None) :
        ParentList.__init__(self, httpBody)
        #self.length = 0
        #self.index = 0
        #self.poolList = []
        if httpBody == None or httpBody == "":
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0 :
            return
        if not isinstance(httpBody, unicode) :
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)
            if self.xmlObj.hasTag("NodePoolListType") :
                if not self.xmlObj.hasTag("node_pool"):
                    return
                poolListXmlObj = self.xmlObj["node_pool"]
            elif self.xmlObj.hasTag("NodePoolViewInfoType") :
                poolListXmlObj = self.xmlObj["NodePoolViewInfoType"]
                
            #print poolListXmlObj.m_obj
            #print len(poolListXmlObj)
            for i in range(len(poolListXmlObj)) :
                #print poolListXmlObj[i].toxml()
                pool = NodePoolV2(poolListXmlObj[i].toxml())
                self.elementList.append(pool)
                self.length += 1
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)
