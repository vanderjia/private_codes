# -*- coding: utf-8 -*-
# Copyright (c) 2008-2016, AD SANGFOR, [Version 6.3.0]
# Filename: LanInfo.py
from Configuration import Configuration
from APIException import APIException
from ErrorInfo import ErrInfo
from urllib2 import base64
import XMLObject as xmlo
import urllib
from ParentList import ParentList
from AddrElement import AddrElement


class LanInfo (ErrInfo):
    def __init__(self, httpBody=None):
        ErrInfo.__init__(self, httpBody)
        self.lan_name = None
        self.enable = None
        self.ifname = None
        self.ip_addr = []             # 获取的网口ip，格式:ip/mask
        self.ip_addr_map = []         # 网口ip, AddrElement类型
        self.enable_detect = None     # 健康监测开关 'true'/'false'
        self.arp_detect = None        # arp监测开关
        self.detect_ip = None         # 检测ip
        self.enable_nic_check = None  # 插拔检测开关
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
                httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)
            xmlChildObj = None
            if self.xmlObj.hasTag("lan_name"):
                self.wan_name = urllib.unquote(Configuration.base64decode(self.xmlObj["lan_name"][0].getChildValue()))
            if self.xmlObj.hasTag("ifname"):
                xmlChildObj = self.xmlObj["ifname"][0]
                if xmlChildObj.hasTag('ifname'):
                    self.ifname = urllib.unquote(Configuration.base64decode(xmlChildObj.getChildObj('ifname')[0].getChildValue()))
                if xmlChildObj.hasTag('enable'):
                    self.enable = xmlChildObj.getChildObj('enable')[0].getChildValue()
            if self.xmlObj.hasTag("ip_addr") :
                self.ip_addr = []
                xmlChildObj = self.xmlObj["ip_addr"]
                for ip in xmlChildObj:
                    self.ip_addr.append(ip.getChildValue())
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)

    def __str__(self):
        return self.originStr

    @classmethod
    def netifToXml(cls, lanInfo):
        params = ''
        if lanInfo.ifname is not None:
            params += '<ifname>' + base64.b64encode(lanInfo.ifname) + '</ifname>'
        if lanInfo.enable is not None:
            params += '<enable>' + lanInfo.enable + '</enable>'
        if len(lanInfo.ip_addr_map) != 0:
            for addr in lanInfo.ip_addr_map:
                params += '<ip_addr>'
                params += '<info>' + addr.ip + '</info>'
                params += '<info_id>' + str(addr.info_id) + '</info_id>'
                params += '</ip_addr>'
        if params != '':
            params = '<netif>' + params + '</netif>'
        return params

    @classmethod
    def lanInfoToXml(cls, lanInfo):
        params = ''
        if lanInfo is not None:
            params += '<netif_info>'
            if lanInfo.lan_name is not None:
                params += '<name>' + base64.b64encode(lanInfo.lan_name) + '</name>'
            params += LanInfo.netifToXml(lanInfo)
            if lanInfo.enable_detect is not None:
                params += '<enable_detect>' + lanInfo.enable_detect + '</enable_detect>'
            if lanInfo.arp_detect is not None:
                params += '<arp_detect>' + lanInfo.arp_detect + '</arp_detect>'
            if lanInfo.arp_detect == 'true':
                if lanInfo.detect_ip is not None:
                    params += '<detect_ip>'
                    params += '<info>' + lanInfo.detect_ip + '</info>'
                    params += '</detect_ip>'
            if lanInfo.enable_nic_check is not None:
                params += '<enable_nic_check>' + lanInfo.enable_nic_check + '</enable_nic_check>'
            params += '</netif_info>'
        return params


    @classmethod
    def generatinglanList(cls, httpBody) :
        return LanList(httpBody)

    @classmethod
    def generatinglanInfo(cls, httpBody) :
        return LanList(httpBody)
        
class LanList(ParentList):
    '''
    '''
    def __init__(self, httpBody = None):
        ParentList.__init__(self, httpBody)
        if httpBody is None or httpBody == "":
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)
            if self.xmlObj.hasTag("LanInfoListType"):
                if not self.xmlObj.hasTag('lan_info'):
                    return
                lanListXmlObj = self.xmlObj["lan_info"]
            elif self.xmlObj.hasTag("LanIpListType") :
                lanListXmlObj = self.xmlObj["LanIpListType"]
            else:
                return
            for i in range(len(lanListXmlObj)):
                node = LanInfo(lanListXmlObj[i].toxml())
                self.elementList.append(node)
                self.length += 1
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)
