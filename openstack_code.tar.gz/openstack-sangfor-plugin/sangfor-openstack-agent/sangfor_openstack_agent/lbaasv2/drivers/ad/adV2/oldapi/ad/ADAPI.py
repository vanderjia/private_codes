# -*- coding: utf-8 -*-
# Copyright (c) 2008-2016, AD SANGFOR, [Version 6.3.0]
# Filename: ADAPI.py

# 定义了 ADAPI PYTHON SDK 对外的接口
#from http import HttpClient
from api.http.HttpClient import HttpClient, RequestMethod, HttpClientException
from api.NodeInfo import NodeInfo, ConfStatus#, NodeList, HealthStatus,
from api.NodePool import NodePool#, PoolList
from api.Configuration import Configuration
from api.APIException import APIException
import urllib

class ADAPI :
    '''
    包含 ADAPI PYTHON SDK 对外的接口
    '''
    def __init__(self, configuration = None) :
        '''
        初始化类
        @param configuration 初始化信息。若为None，则必须调用setConfig方法设置初始化信息。
        @type Configuration
        @return
        @rtype
        '''
        self.config = configuration
    '''
    获取ADAPI的版本信息
    '''
    @classmethod
    def getVersion(cls) :
        import __init__
        return __init__.__version__
    def setConfig(self, configuration = None) :
        '''
        用于初始化ADAPI SDK所需信息。包括AD IP、AD端口(若为None，默认设置为443)、用户名、密码
        @param configuration 初始化信息类。
        @type Configuration
        @return
        @rtype
        '''
        self.config = configuration

    def getNodesStatus(self, nodePoolName) :
        '''
        获取指定节点池中所有节点的健康状态、连接数、配置状态列表
        @param nodePoolName 节点池名称
        @type str
        @return NodeList
        @rtype NodeList
        '''
        httpBody = None
        requestMethod = RequestMethod.GET
        # 传入参数
        params = {"username":self.config.username,
                  "password":self.config.password,
                  "node_pool_name":nodePoolName}
        #print "ADAPI params: " + str(params)
        try :
            # 发送HTTPS请求
            httpBody = HttpClient.httpClient(self.config.getNodeStatusURI,
                                             params,
                                             self.config.ip, self.config.port,
                                             requestMethod)
        # 使用请求结果构造节点状态列表
        #print "httpBody: " + httpBody
            if httpBody == None :
                raise APIException(4, "unknown error")
            nodeList = NodeInfo.generatingNodeList(httpBody)
            return nodeList
        except HttpClientException, e:
            code = None
            reason = str(e.code) + "; " + str(e.reason)
            code = APIException.codeTransfer(e)
            #print str(APIException(code, reason))
            raise APIException(code, reason)

    def getNodePoolList(self) :
        '''
        获取节点池列表
        @return PoolList
        @rtype PoolList
        '''
        requestMethod = RequestMethod.GET
        # 传入参数
        params = {"username":self.config.username,
                  "password":self.config.password}
        #print "ADAPI params: " + str(params)
        try :
            # 发送HTTPS请求
            httpBody = HttpClient.httpClient(self.config.getNodePoolListURI,
                                             params,
                                             self.config.ip, self.config.port,
                                             requestMethod)

            if httpBody == None :
                raise APIException(4, "unknown error")
            #print httpBody
            poolList = NodePool.generatingPoolList(httpBody)
            return poolList
        except HttpClientException, e:
            code = None
            reason = str(e.code) + "; " + str(e.reason)
            code = APIException.codeTransfer(e)
            raise APIException(code, reason)

    def getNodeList(self, nodePoolName) :
        '''
        获取指定节点池中所有节点的健康状态、连接数、配置状态列表
        @param nodePoolName 节点池名称
        @type str
        @return NodeList
        @rtype NodeList
        '''
        requestMethod = RequestMethod.GET
        params = {"username":self.config.username,
                  "password":self.config.password,
                  "node_pool_name":nodePoolName}
        #print "ADAPI params: " + str(params)
        try :
            httpBody = HttpClient.httpClient(self.config.getNodeListURI,
                                             params,
                                             self.config.ip, self.config.port,
                                             requestMethod)
            #print httpBody
            if httpBody == None :
                raise APIException(4, "unknown error")
            nodeList = NodeInfo.generatingNodeList(httpBody)
            return nodeList
        except HttpClientException, e:
            code = None
            reason = str(e.code) + "; " + str(e.reason)
            code = APIException.codeTransfer(e)
            raise APIException(code, reason)
    def getNodeInfo(self, nodePoolName, nodeIP, nodePort) :
        '''
        获取指定节点信息
        @param nodePoolName 节点池名称
        @type str
        @param nodeIP 节点IP
        @type str
        @param nodePort 节点端口
        @type int
        @return NodeInfo
        @rtype NodeInfo
        '''
        requestMethod = RequestMethod.GET
        params = {"username":self.config.username,
                  "password":self.config.password,
                  "node_pool_name":nodePoolName,
                  "node_ip":nodeIP}
        if nodePort != None :
            params["node_port"] = nodePort
        #print "ADAPI params: " + str(params)
        try :
            httpBody = HttpClient.httpClient(self.config.getNodeInfoURI,
                                             params,
                                             self.config.ip, self.config.port,
                                             requestMethod)
            if httpBody == None :
                raise APIException(4, "unknown error")
            node = NodeInfo(httpBody)
            return node
        except HttpClientException, e:
            code = None
            reason = str(e.code) + "; " + str(e.reason)
            code = APIException.codeTransfer(e)
            raise APIException(code, reason)

    def deleteNode(self, nodePoolName, nodeIP, nodePort) :
        '''
        删除指定节点
        @param nodePoolName 节点池名称
        @type str
        @param nodeIP 节点IP
        @type str
        @param nodePort 节点端口
        @type int
        @return None
        @rtype None
        '''
        requestMethod = RequestMethod.POST
        #authStr = "?" + urllib.quote("username=" + self.config.username + "&password=" +
        #    self.config.password)
        authStr = "?" + "username=" + urllib.quote_plus(self.config.username) + "&password=" + \
             urllib.quote_plus(self.config.password)
        # 请求参数
        params = {"node_pool_name":nodePoolName,
                  "node_ip":nodeIP}
        if nodePort != None :
            params["node_port"] = nodePort
        #print "ADAPI params: " + str(params)
        try :
            # 发送请求
            httpBody = HttpClient.httpClient(self.config.deleteNodeURI + authStr,
                                             params,
                                             self.config.ip, self.config.port,
                                             requestMethod)

            if httpBody == None :
                raise APIException(4, "unknown error")
            node = NodeInfo(httpBody)
            return node
        except HttpClientException, e:
            code = None
            reason = str(e.code) + "; " + str(e.reason)
            code = APIException.codeTransfer(e)
            raise APIException(code, reason)
    def updateNode(self, nodePoolName, nodeIP, nodePort, node) :
        '''
        更新指定节点的配置信息
        @param nodePoolName 节点池名称
        @type str
        @param nodeIP 节点IP，用于指定节点
        @type str
        @param nodePort 节点端口，用于指定节点
        @type int
        @param  node   要更新的节点数据。若成员变量不为默认值，则表示要更新
        @type NodeInfo
        @return None
        @rtype None
        '''
        httpBody = None
        requestMethod = RequestMethod.POST
        #authStr = "?" + urllib.quote("username=" + self.config.username + "&password=" +
        #    self.config.password)
        authStr = "?" + "username=" + urllib.quote_plus(self.config.username) + "&password=" + \
             urllib.quote_plus(self.config.password)
        # 请求参数
        params = {"node_pool_name":nodePoolName,
                  "node_ip":nodeIP}
        # node中的数据若不为无效值，则作为更新数据放入params
        if nodePort != None :
            params["node_port"] = nodePort
        if node.nodePort != -1 :
            params["new_node_port"] = node.nodePort
        if node.ratio != -1 :
            params["ratio"] = node.ratio
        if node.maxConnects != -1 :
            params["max_connects"] = node.maxConnects
        if node.newConnects != -1 :
            params["new_connects"] = node.newConnects
        if node.maxRequest != -1 :
            params["max_request"] = node.maxRequest
        if node.confStatus != None :
            params["status"] = node.confStatus
        if node.rsVal1 != None :
            if not isinstance(node.rsVal1, unicode) :
                node.rsVal1  = unicode(node.rsVal1, "utf8")
            params["rs_val1"]  = urllib.quote_plus(node.rsVal1.encode("utf8"))
        #print "ADAPI params: " + str(params)
        try :
            # 发送请求
            httpBody = HttpClient.httpClient(self.config.updateNodeURI + authStr,
                                             params,
                                             self.config.ip, self.config.port,
                                             requestMethod)
            if httpBody == None :
                raise APIException(4, "unknown error")
            node = NodeInfo(httpBody)
            return node
        except HttpClientException, e:
            code = None
            reason = str(e.code) + "; " + str(e.reason)
            code = APIException.codeTransfer(e)
            raise APIException(code, reason)
    def createNode(self, nodePoolName, node) :
        '''
        创建新节点
        @param nodePoolName 节点池名称
        @param  node    要创建的节点信息
        @type NodeInfo
        @return None
        @rtype None
        '''
        requestMethod = RequestMethod.POST
        #authStr = "?" + urllib.quote("username=" + self.config.username + "&password=" +
        #    self.config.password)
        authStr = "?" + "username=" + urllib.quote_plus(self.config.username) + "&password=" + \
             urllib.quote_plus(self.config.password)
        params = {"node_pool_name":nodePoolName,
                  "node_ip":node.nodeIP}

        if node.nodePort != -1 :
            params["node_port"] = node.nodePort
        if node.ratio != -1 :
            params["ratio"] = node.ratio
        if node.maxConnects != -1 :
            params["max_connects"] = node.maxConnects
        if node.newConnects != -1 :
            params["new_connects"] = node.newConnects
        if node.maxRequest != -1 :
            params["max_request"] = node.maxRequest
        if node.confStatus != None :
            params["status"] = node.confStatus
        if node.rsVal1 != None :
            if not isinstance(node.rsVal1, unicode) :
                node.rsVal1  = unicode(node.rsVal1, "utf8")
            params["rs_val1"]  = urllib.quote_plus(node.rsVal1.encode("utf8"))
        #print "ADAPI params: " + str(params)
        try :
            # 发送请求
            httpBody = HttpClient.httpClient(self.config.createNodeURI + authStr,
                                             params,
                                             self.config.ip, self.config.port,
                                             requestMethod)
            if httpBody == None :
                raise APIException(4, "unknown error")
            node = NodeInfo(httpBody)
            return node
        except HttpClientException, e:
            code = None
            reason = str(e.code) + "; " + str(e.reason)
            code = APIException.codeTransfer(e)
            raise APIException(code, reason)



if __name__ == "__main__":
    config = Configuration("admin", "root1234", "200.200.82.191", "443")
    adapi = ADAPI(config)
    #adapi.api_is_avaliable('admin','root1234')
    print adapi.getNodeList("test")

