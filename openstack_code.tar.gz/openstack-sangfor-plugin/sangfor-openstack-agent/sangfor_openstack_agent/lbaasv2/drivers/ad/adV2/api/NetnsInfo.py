# -*- coding: utf-8 -*-
# Copyright (c) 2008-2020, AD SANGFOR
# Filename: NetnsInfo.py
# 定义netns信息
from Configuration import Configuration
from APIException import APIException
from ErrorInfo import ErrInfo
from http.HttpClient import HttpClient
from ParentList import ParentList
from urllib2 import base64
import JSONObj as jsono
import urllib
import json


class NetnsInfo(ErrInfo):
    def __init__(self, httpBody=None):
        ErrInfo.__init__(self, httpBody)
        self.name = None
        self.tenant = None     # 所属租户
        self.appgId = 1        # 所属应用组
        self.netnsId = 0       # netns id
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('NetnsInfoType'):
                jsonNetnsInfo = self.jsonObj['NetnsInfoType']
                if 'name' in jsonNetnsInfo:
                    self.name = urllib.unquote(
                        base64.b64decode(jsonNetnsInfo['name']))
                if 'tenant' in jsonNetnsInfo:
                    self.tenant = urllib.unquote(
                        base64.b64decode(jsonNetnsInfo['tenant']))
                if 'appg_id' in jsonNetnsInfo:
                    self.appgId = int(jsonNetnsInfo['appg_id'])
                if 'netns_id' in jsonNetnsInfo:
                    self.netnsId = int(jsonNetnsInfo['netns_id'])
        except jsono.JSONObjException, e:
            raise APIException(3, e.reason)

    @classmethod
    def netnsInfoToDict(cls, netnsInfo):
        netnsDict = {}
        netnsDict['appg_id'] = netnsInfo.appgId
        if netnsInfo.name is None:
            netnsDict['name'] = ''
        else:
            netnsDict['name'] = netnsInfo.name
        if netnsInfo.tenant is None:
            netnsDict['tenant'] = ''
        else:
            netnsDict['tenant'] = netnsInfo.tenant
        return netnsDict

    @classmethod
    def generatingNetnsInfo(cls, httpBody):
        return NetnsInfo(httpBody)


class VlanInfoList(ParentList):
    def __init__(self, httpBody=None):
        ParentList.__init__(self, httpBody)
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if not self.jsonObj.hasTag('data'):
                return
            for item in self.jsonObj['data']:
                vlan = VlanInfo(json.dumps(item, ensure_ascii=False))
                self.elements.append(vlan)
        except jsono.JSONObjException, e:
            raise APIException(3, e.reason)
