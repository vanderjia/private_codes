# -*- coding: utf-8 -*-
# Copyright (c) 2008-2020, AD SANGFOR
# Filename: StaticRouteInfo.py
# 定义会话保持配置信息
from APIException import APIException
from ErrorInfo import ErrInfo
from ParentList import ParentList
from urllib2 import base64
import JSONObj as jsono
import urllib
import json
import codecs


class StaticRouteInfo(ErrInfo):
    def __init__(self, httpBody=None):
        ErrInfo.__init__(self, httpBody)
        self.net = None     #网络号
        self.mask = -1      #掩码
        self.gw_addr = None #网关ip
        self.dev_id = 0     #生效设备，默认都生效
        self.netns_id = -1  #对应netns id

        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
                httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('net'):
                self.net = self.jsonObj['net']
            if self.jsonObj.hasTag('mask'):
                self.mask = self.jsonObj['mask']
            if self.jsonObj.hasTag('netns_id'):
                self.netns_id = self.jsonObj['netns_id']
            if self.jsonObj.hasTag('dev_gw'):
                subObj = self.jsonObj['dev_gw']
                if 'gw_addr' in subObj:
                    self.gw_addr = subObj['gw_addr']
                if 'dev_id' in subObj:
                    self.dev_id = subObj['dev_id']
        except jsono.JSONObjException as e:
            raise APIException(3, e.reason)

    @classmethod
    def routeInfoToDict(cls, route):
        routeDict = {}
        if route.net is not None:
            routeDict['net'] = route.net
        if route.mask != -1:
            routeDict['mask'] = route.mask
        if route.netns_id != -1:
            routeDict['netns_id'] = route.netns_id
        gwDevDict = {}
        if route.dev_id != -1:
            gwDevDict['dev_id'] = route.dev_id
        if route.gw_addr is not None:
            gwDevDict['gw_addr'] = route.gw_addr
        routeDict['gw_dev'] = gwDevDict
        return routeDict

    @classmethod
    def generatingRouteList(cls, httpBody):
        return RouteList(httpBody)

    @classmethod
    def generatingStaticRouteInfo(cls, httpBody):
        return StaticRouteInfo(httpBody)

