import datetime
import hashlib
import logging as std_logging
import urllib2
import uuid

import sys
from eventlet import greenthread
from time import time
import commands

from neutron.common import constants as q_const
from neutron.common.exceptions import InvalidConfigurationOption
from neutron.common.exceptions import NeutronException
from neutron.plugins.common import constants as plugin_const
from neutron_lbaas.services.loadbalancer import constants as lb_const

from oslo_config import cfg
from oslo_log import helpers as log_helpers
from oslo_log import log as logging
from oslo_utils import importutils
from sangfor_openstack_agent.lbaasv2.drivers.ad.vadCache import MADcache as MAD 
from sangfor_openstack_agent.lbaasv2.drivers.ad.vadCache import VADcache as VAD 
from sangfor_openstack_agent.lbaasv2.drivers.ad.adCache import ADcache as AD

from sangfor_openstack_agent.lbaasv2.drivers.ad.lbaas_driver import LBaaSBaseDriver 
from sangfor_openstack_agent.lbaasv2.drivers.ad import constants_v2 as sangforconst

'''
全局变量定义
'''
_DEFAULT_POOL = 'openstack-default-pool'
_MONITOR_RETRIES = 255
_MONITOR_MAX_DELAY = 255
_MONTTOR_MAX_TIMEOUT = 255
_MONITOR_TYPE_MAP = {
    'TCP':'MONITOR_CONNECT_TCP',
    'PING':'MONITOR_ICMPV4',
    'HTTP':'MONITOR_CONNECT_HTTP',
    'HTTPS':'MONITOR_CONNECT_HTTPS'
}

LOG = logging.getLogger(__name__)
__VERSION__ = '0.1.1'

'''
配置文件定义
'''
OPTS = [
    cfg.StrOpt(
        'server_host',
        default='200.200.144.196',
        help='connect to AD server_address'
    ),
    cfg.IntOpt(
        'server_port',
        default=443,
        help='connect to AD server_port',
    ),
    cfg.IntOpt(
        'vxlan_local_port',
        default=0,
        help='vxlan local port',
    ),

    cfg.IntOpt(
        'vxlan_remote_port',
        default=4789,
        help='vxlan remote port',
    ),
    cfg.StrOpt(
        'server_admin',
        default='admin',
        help='username to login'
    ),
    cfg.StrOpt(
        'server_password',
        default='root1234',
        help='password to login'
    ),

    cfg.ListOpt(
        'advertised_tunnel_types', default=['vxlan'],
        help='tunnel types which are advertised to other VTEPs'
    ),
    cfg.ListOpt(
        'vad_manager_info_mapping', default=['eth1:200.200.144.113:22'],
        help='vad manager info'
    ),
    cfg.ListOpt(
        'external_physical_mappings', default=['default:eth1:True'],
        help='Mapping between Neutron physical_network to interfaces'
    ),

    cfg.ListOpt(
        'local_interface_ip', default=['eth1:200.200.1.2:24'],
        help='Mapping between Neutron physical_network to interfaces'
    ),
]

'''
AD驱动类，直接调用AD api方法下发配置
'''
class ADDriver(LBaaSBaseDriver):

    def __init__(self, conf, registerOpts=True):

        super(ADDriver, self).__init__(conf)
        self.conf = conf

        if registerOpts:
            self.conf.register_opts(OPTS)
        self.plugin_rpc = None
        
        #TODO:需要整理，对外配置显示，回作为agent属性存储到db中
        self.agent_configurations = {}
        self.agent_configurations["tunnel_types"] = self.conf.advertised_tunnel_types
        self.agent_configurations['common_networks']={}

        
        self.username = self.conf.server_admin
        self.password = self.conf.server_password
        #改为通过AD API连接物理AD
        #self.mad = MAD(self.username, self.password, self.conf.server_host, self.conf.server_port)
        self.ad = AD(self.username, self.password, self.conf.server_host, self.conf.server_port)
        #没人操作这个loadbalancer，删掉吧
        #self.loadbalancer = {}
        self.interface_mapping={}
        self.local_interface_ip = {}
        self.tagging_mapping={}
        #self.vad_manager_info={}

        #TODO:对AD设备的话，server_host应该改为AD的集群管理IP
        if self.conf.environment_prefix:
            self.agent_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, self.conf.environment_prefix + '.' + self.conf.server_host))
        else:
            self.agent_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, self.conf.server_host))

        #对外物理接口，用来建立vlan或vxlan，这部分可以复用
        for maps in self.conf.external_physical_mappings:
            intmap = maps.split(':')
            net_key = str(intmap[0]).strip()
            self.interface_mapping[net_key] = str(intmap[1]).strip()
            self.tagging_mapping[net_key] = str(intmap[2]).strip()
            LOG.debug('physical_network %s = interface %s, tagged %s'
                      % (net_key, intmap[1], intmap[2]))

        #TODO:标识vad的管理ip，应该可以删掉了
        '''
        for maps in self.conf.vad_manager_info_mapping:
            intmap = maps.split(':')
            net_key = str(intmap[0]).strip()
            self.vad_manager_info[net_key] = {
                    'manager_ip': intmap[1],
                    'manager_mask':intmap[2], 
                    'password': 'root1234'
                    }
            pass
        '''

        #应该是vxlan等tunnel引用的通信ip列表，可以不动
        for maps in self.conf.local_interface_ip:
            intmap = maps.split(':')
            net_key = str(intmap[0].strip())
            self.local_interface_ip[net_key]=[intmap[1].strip(), int(intmap[2].strip())]
            pass

        #TODO:不再需要获取vad状态，agent重启考虑针对ERROR或PENDING，增量下发配置即可
        '''
        vadList = self.mad.getVADList()
        try:
            for vad in vadList:
                if vad.started():
                    vad.resetConfig()
        except Exception as e:
            LOG.error("resetConfig failed")
            return
        '''
        """
        self.reset = True
        """
        self.reset = False

    def _getnetwork_from_service(self, service, network_id):
        if 'networks' in service:
            return service['networks'][network_id]

    def _get_subnets_to_from_service(self, service, subnet_id):
        if 'subnets' in service:
            return service['subnets'][subnet_id]
    def set_tunnel_rpc(self, tunnel_rpc):
       self._tunnel_rpc = tunnel_rpc

    def set_l2pop_rpc(self, l2_pop_rpc):
       self._l2pop_rpc = l2_pop_rpc

    def _get_subnets_to_assure(self, service):
        networks = dict()
        loadbalancer = service['loadbalancer']
        lb_status = loadbalancer['provisioning_status']

        if lb_status != plugin_const.PENDING_DELETE:
            if 'network_id' in loadbalancer:
                network = self._getnetwork_from_service(service, loadbalancer['network_id'])
                subnet = self._get_subnets_to_from_service(service, loadbalancer['vip_subnet_id'])
                networks[network['id']] = {'network': network,
                        'subnet': subnet,
                        'is_for_member': False}
                pass
            pass
        return networks.values()
            
    def set_plugin_rpc(self, plugin_rpc):
       self.plugin_rpc = plugin_rpc

    def _get_lb_appg_id(self, lb_id):
        '''
        TODO: 获取虚拟服务对应的appg id
        @param lb_id lb的id
        @return 返回appg_id(暂时返回默认组id 1)
        '''
        return 1

    def _assure_netns(self, lb):
        '''
        @创建netns
        @param service: 创建虚拟服务的完整信息
        @return 返回netns_id
        '''
        netns_name = self._get_loadbalancer_name(lb['id'])
        appg_id = self._get_lb_appg_id(lb['id'])
        netns_id = self.ad.createNetns(netns_name, appg_id)
        return netns_id

    def _assure_macvlan(self, netns_id, ifname, lb)
        '''
        @创建macvlan
        @param netns_id macvlan对应netns的id
        @param ifname   macvlan引用的if
        @param lb   lb的信息,用来获取mac地址
        @return macvlan 对应device
        '''
        macvlan_name = self._get_loadbalancer_name(lb['id'])
        mac_addr = lb['vip_port']['mac_address']
        return self.ad.createMacvlan(macvlan_name, ifname, mac_addr, netns_id)

    def _assure_network(self, network,service):
        if not network:
            LOG.error(' assure_network: '
                      'Attempted to assure a network with no id..skipping.')
            return

        if network['provider:network_type'] == 'vlan':
            return self._assure_network_vlan(network)
        elif network['provider:network_type'] == 'vxlan':
            return self._assure_network_vxlan(network, service)
        elif network['provider:network_type'] == 'flat':
            return ['flat', '']
        else:
            error_message = 'Unsupported network type %s.' \
                            % network['provider:network_type'] + \
                            ' Cannot setup network.'
            LOG.error(error_message)
            raise Exception()
        return ['flat','']
        pass

    def _get_tunnel_name(self, network):
        tunnel_type = network['provider:network_type']
        tunnel_id = network['provider:segmentation_id']
        return 'tunnel-' + str(tunnel_type) + '-' + str(tunnel_id)

    def _get_vxlan_vteps(self, service):
        vxlan=[]
        if 'loadbalancer' in service and 'vxlan_vteps' in service['loadbalancer']:
            vxlan = service['loadbalancer']['vxlan_vteps']
        return vxlan

    def _assure_network_vxlan(self, network, service):
        '''
        TODO:现在AD不支持，直接返回失败
        '''

        '''
        tunnel_name = self._get_tunnel_name(network)

        self.mad.createVxlan(tunnel_name, network['provider:segmentation_id'],
                self._get_vxlan_vteps(service), self.conf.vxlan_remote_port)
        local_ip = self._get_vxlan_local_ip(network)
        fdb_entry = { network['id']: { 'ports':{local_ip:[q_const.FLOODING_ENTRY]},
            'network_type':network['provider:network_type'],
            'segmentation_id':network['provider:segmentation_id']}}
        self._l2pop_rpc.add_fdb_entries(self._context, fdb_entry)
        return ['vxlan', tunnel_name]
        '''

        return

    def _get_interface(self, network):

        interface = self.interface_mapping['default']
        net_key = network['provider:physical_network']

        if net_key in self.interface_mapping:
            interface = self.interface_mapping[net_key]
        else:
            interface = self.interface_mapping['default']

        return interface

    def _get_vxlan_local_ip(self, network):
        return self.local_interface_ip[self._get_interface(network)][0]

    def _assure_network_vlan(self, network):
        '''
        @创建vlan网口
        @param network 对应网络结构
        @return ['vlan', vlan_device] device为设备上vlan设备的实际名称
        '''
        
        interface = self.interface_mapping['default']
        tagged = self.tagging_mapping['default']

        net_key = network['provider:physical_network']
        if net_key in self.interface_mapping:
            interface = self.interface_mapping[net_key]
            tagged = self.tagging_mapping[net_key]
        else:
            interface = self.interface_mapping['default']
            tagged = self.tagging_mapping['default']

        if tagged:
            vlanid = network['provider:segmentation_id']
        else:
            vlanid = 0

        vlan_name = self._get_vlan_name(network['id'])

        try:
            self.ad.createVlan(vlan_name, vlanid, interface)
        except APIException as ex:
            LOG.error(u"Create Vlan error %s " % str(ex))
            pass
        
        return ['vlan', vlan_name]

    def set_context(self, context):
        self._context = context
        pass
        
    def post_init(self):
        pass

    def _get_vlan_name(self, net_id):
        '''
        @获取vlan口配置名称
        @param net_id network的uuid
        @return vlan名称
        '''
        return "op-vlan-" + net_id

    def _get_loadbalancer_name(self, lb_id):
        '''
        @获取所有虚拟服务相关配置名称
        @param lb_id lb的uuid
        @return 配置名称
        '''
        return "openstack-" + lb_id

    def _get_listener_name(self, listener_id):
        '''
        @获取所有listener相关配置名称(服务 VS)
        @param listener_id listener的uuid
        @return 配置名称
        '''
        return "openstack-" + listener_id

    def _get_pool_name(self, pool_id):
        '''
        @获取所有pool相关配置名称(节点池 回话保持)
        @param pool_id pool的uuid
        @return 配置名称
        '''
        return "openstack-" + pool_id

    def _get_monitor_name(self, monitor_id):
        '''
        @获取所有monitor相关配置名称(节点池 回话保持)
        @param monitor_id monitor的uuid
        @return 配置名称
        '''
        return "openstack-" + monitor_id

    def create_loadbalancer(self, loadbalancer, service):
        try:
            self._common_service_handler(service)
        except Exception as e:
            service['loadbalancer']['provisioning_status'] = plugin_const.ERROR
            self._update_service_status(service)
            LOG.error(u'create loadbalancer error %s' % str(e))

    def update_loadbalancer(self, old_lb ,lb, service):
        try:
            self._common_service_handler(service)
        except Exception as e:
            service['loadbalancer']['provisioning_status'] = plugin_const.ERROR
            self._update_service_status(service)
            LOG.error("getVAD error")
            return
        pass

    def delete_loadbalancer(self, lb, service):
        name = self._get_loadbalancer_name(service)
        try:
            self._common_service_handler(service)
        except Exception as e:
            service['loadbalancer']['provisioning_status'] = plugin_const.ERROR
            self._update_service_status(service)
            LOG.error("delete vad %s failed", str(e))
        pass

    @log_helpers.log_method_call
    def _createDefaultPool(self, name):
        create = True
        pooList = self.ad.getPoolList()
        for pool in pooList:
            if pool.name == name:
                create = False
                break
        if create:
            self.ad.createPool(name)

    def create_listener(self, listener, service):

        try:
            self._common_service_handler(service)
        except Exception as e:
            LOG.error("createServ error(%s)" % e)
            service['loadbalancer']['provisioning_status'] = plugin_const.ERROR
            self._update_service_status(service)
            return
        pass

    def update_listener(self, old_listener, listener, service):
        lbname = self._get_loadbalancer_name(service)
        vsname = 'openstack-'+listener['id']
        try:
            self._common_service_handler(service)
        except Exception as e:
            LOG.error("update listener error")
            service['loadbalancer']['provisioning_status'] = plugin_const.ERROR
            self._update_service_status(service)
            return

        self._update_service_status(service)
        pass

    def delete_listener(self, listener, service):
        lbname = self._get_loadbalancer_name(service)
        vsname = 'openstack-'+listener['id']
        try:
            self._common_service_handler(service)
        except Exception as e:
            LOG.error("delet listener failed")
            service['loadbalancer']['provisioning_status'] = plugin_const.ERROR
            self._update_service_status(service)
            return

    def create_pool(self, pool, service):
        try:
            self._common_service_handler(service)
        except Exception as e:
            LOG.error("create_pool failed")
            service['loadbalancer']['provisioning_status'] = plugin_const.ERROR
            self._update_service_status(service)
            return


    def _getSchedMethod(self, pool):
        method = 'NODE_LB_HASH'
        schedMap = {
                'ROUND_ROBIN': 'NODE_LB_RR',
                'LEAST_CONNECTIONS':'NODE_LB_LEAST_CONN'
                }
        if pool['lb_algorithm'] in schedMap:
            method = schedMap[pool['lb_algorithm']]
        return method

    def update_pool(self, oldpool, pool, service):
        try:
            self._common_service_handler(service)
        except Exception as e :
            service['loadbalancer']['provisioning_status'] = plugin_const.ERROR
            self._update_service_status(service)
            LOG.error("update pool %s" % e)
        pass

    def delete_pool(self, pool, service):
        lbname = self._get_loadbalancer_name(service)
        try:
            self._common_service_handler(service)
        except Exception as e:
            service['loadbalancer']['provisioning_status'] = plugin_const.ERROR
            self._update_service_status(service)
            LOG.error("error  %s" % e)
        pass

    def create_member(self, member, service):
        try:
            self._common_service_handler(service)
        except Exception as e:
            service['loadbalancer']['provisioning_status'] = plugin_const.ERROR
            self._update_service_status(service)
            LOG.error("createMember err %s" % e)
        pass
    def update_member(self, old_member, member, service):
        try:
            self._common_service_handler(service)
        except Exception as e:
            service['loadbalancer']['provisioning_status'] = plugin_const.ERROR
            self._update_service_status(service)
            LOG.error("error %s" % e) 
        pass

    def delete_member(self, member, service):
        try:
            self._common_service_handler(service)
        except Exception as e:
            service['loadbalancer']['provisioning_status'] = plugin_const.ERROR
            self._update_service_status(service)
            LOG.error("deleteMember eror %s" % e)
        pass    

    @log_helpers.log_method_call
    def create_health_monitor(self, health_monitor, service):
        try:
            self._common_service_handler(service)
        except Exception as e:
            LOG.error("error %s " % e)
            service['loadbalancer']['provisioning_status'] = plugin_const.ERROR
            self._update_service_status(service)
        pass

    @log_helpers.log_method_call
    def update_health_monitor(self, old, health_monitor, service):
        try:
            self._common_service_handler(service)
        except Exception as e:
            LOG.error("error %s " % e)
            service['loadbalancer']['provisioning_status'] = plugin_const.ERROR
            self._update_service_status(service)
        pass

    @log_helpers.log_method_call
    def delete_health_monitor(self, health_monitor, service):
        try:
            self._common_service_handler(service)
        except Exception as e:
            LOG.error("deleteMonitor error %s ", e)
            service['loadbalancer']['provisioning_status'] = plugin_const.ERROR
            self._update_service_status(service)
        pass

    def tunnel_update(self, **kargs):
        pass

    def add_fdb_entries(self, fdb):
        pass

    def remove_fdb_entries(self, fdb):
        pass

    def update_fdb_entries(self, fdb):
        pass

    def _update_service_status(self, service):
        """Update status of objects in OpenStack """
        if not self.plugin_rpc:
            LOG.error("Cannot update status in Neutron without "
                      "RPC handler.")
            return

        if 'members' in service:
            # Call update_members_status
            self._update_member_status(service['members'])
        if 'healthmonitors' in service:
            # Call update_monitor_status
            self._update_health_monitor_status(
                service['healthmonitors']
            )
        if 'pools' in service:
            # Call update_pool_status
            self._update_pool_status(
                service['pools']
            )
        if 'listeners' in service:
            # Call update_listener_status
            self._update_listener_status(
                service['listeners']
            )
        self._update_loadbalancer_status(
            service['loadbalancer']
        )

    def _update_member_status(self, members):
        """Update member status in OpenStack """
        for member in members:
            if 'provisioning_status' in member:
                provisioning_status = member['provisioning_status']
                if (provisioning_status == plugin_const.PENDING_CREATE or
                        provisioning_status == plugin_const.PENDING_UPDATE):
                        self.plugin_rpc.update_member_status(
                            member['id'],
                            plugin_const.ACTIVE,
                            lb_const.ONLINE
                        )
                elif provisioning_status == plugin_const.PENDING_DELETE:
                    self.plugin_rpc.member_destroyed(
                        member['id'])

    def _update_health_monitor_status(self, health_monitors):
        """Update pool monitor status in OpenStack """
        for health_monitor in health_monitors:
            if 'provisioning_status' in health_monitor:
                provisioning_status = health_monitor['provisioning_status']
                if (provisioning_status == plugin_const.PENDING_CREATE or
                        provisioning_status == plugin_const.PENDING_UPDATE):
                        self.plugin_rpc.update_health_monitor_status(
                            health_monitor['id'],
                            plugin_const.ACTIVE,
                            lb_const.ONLINE
                        )
                elif provisioning_status == plugin_const.PENDING_DELETE:
                    self.plugin_rpc.health_monitor_destroyed(
                        health_monitor['id'])

    @log_helpers.log_method_call
    def _update_pool_status(self, pools):
        """Update pool status in OpenStack """
        for pool in pools:
            if 'provisioning_status' in pool:
                provisioning_status = pool['provisioning_status']
                if (provisioning_status == plugin_const.PENDING_CREATE or
                        provisioning_status == plugin_const.PENDING_UPDATE):
                        self.plugin_rpc.update_pool_status(
                            pool['id'],
                            plugin_const.ACTIVE,
                            lb_const.ONLINE
                        )
                elif provisioning_status == plugin_const.PENDING_DELETE:
                    self.plugin_rpc.pool_destroyed(
                        pool['id'])

    @log_helpers.log_method_call
    def _update_listener_status(self, listeners):
        """Update listener status in OpenStack """
        for listener in listeners:
            if 'provisioning_status' in listener:
                provisioning_status = listener['provisioning_status']
                if (provisioning_status == plugin_const.PENDING_CREATE or
                        provisioning_status == plugin_const.PENDING_UPDATE):
                        self.plugin_rpc.update_listener_status(
                            listener['id'],
                            plugin_const.ACTIVE,
                            lb_const.ONLINE
                        )
                elif provisioning_status == plugin_const.PENDING_DELETE:
                    self.plugin_rpc.listener_destroyed(
                        listener['id'])

    @log_helpers.log_method_call
    def _update_loadbalancer_status(self, loadbalancer):
        """Update loadbalancer status in OpenStack """
        provisioning_status = loadbalancer['provisioning_status']

        if (provisioning_status == plugin_const.PENDING_CREATE or
                provisioning_status == plugin_const.PENDING_UPDATE):
            self.plugin_rpc.update_loadbalancer_status(
                loadbalancer['id'],
                plugin_const.ACTIVE,
                lb_const.ONLINE)
        elif provisioning_status == plugin_const.PENDING_DELETE:
            self.plugin_rpc.loadbalancer_destroyed(
                loadbalancer['id'])
        elif provisioning_status == plugin_const.ERROR:
            self.plugin_rpc.update_loadbalancer_status(
                loadbalancer['id'])
        else:
            LOG.error('Loadbalancer provisioning status is invalid')

    def sync(self, service):
        if self.plugin_rpc:
            service = self.plugin_rpc.get_service_by_loadbalancer_id(service['loadbalancer']['id'])
        if service['loadbalancer']:
            self._common_service_handler(service)
        else:
            LOG.debug("Attempted sync of deleted pool")

    @log_helpers.log_method_call
    def _common_service_handler(self, service):
        '''
        配置下发通知接口，保留原有形式，修改内部实现
        '''
        self._assure_loadbalancer(service)
        #TODO:将下面配置中的vad去掉即可，直接用ad的api应该完全兼容
        self._assure_listeners(service)
        self._assure_pools(service)
        self._assure_members(service)
        self._assure_monitors(service)

        #状态更新可以完全复用
        self._update_service_status(service)

    @log_helpers.log_method_call
    def _assure_loadbalancer(self, service):
        '''
        lb下发接口
        '''
        if 'loadbalancer' not in service:
            return
        name = self._get_loadbalancer_name(service)
        lb = service['loadbalancer']
        #TODO: 如果单台AD的话，delete需要处理一下了
        if lb['provisioning_status'] == plugin_const.PENDING_DELETE:
            LOG.debug("delete lb(%s) ok" % name)
            return
        elif lb['provisioning_status'] == plugin_const.PENDING_CREATE:
            try:
                #TODO:如果层次化绑定在agent实现的话，应该是在这里做
                subnetsinfo = self._get_subnets_to_assure(service)
                bridge = self._assure_network(subnetsinfo[0]['network'], service)
                netns_id = self._assure_netns(service)
                interface = self._get_interface(subnetsinfo[0]['network'])
                if bridge[0] == 'flat':
                    bridge[1] = interface
                macvlan_device = self._assure_macvlan(netns_id, bridge[1], lb)

                ipg_name = self._get_loadbalancer_name(lb['id'])
                #下面的操作重新处理，不再创建vad，直接创建ip组和wan口
                self.ad.createIPGroup(ipg_name, [service['loadbalancer']['vip_address']],\
                        {'mask':int(subnetsinfo[0]['subnet']['cidr'].split('/')[1]), \
                        'gatewayIP':subnetsinfo[0]['subnet']['gateway_ip'], 'wan':ipg_name,
                        'ifname':bridge[1]})
                
            except Exception as e:
                raise(e)
        else:
            pass

    @log_helpers.log_method_call
    def _createListener(self, loadbalancer, listener) #, vad, service):
        self._createDefaultPool(_DEFAULT_POOL)
        ipg_name = self._get_loadbalancer_name(loadbalancer['id'])
        name = self._get_listener_name(listener['id'])
        srvtype = 'SRV_HTTP' if listener['protocol'] == 'HTTP' else 'SRV_TCP'
        enable = 'true' if listener['admin_state_up'] and loadbalancer['admin_state_up'] else 'false'
        mode = 'VS_MODE_L7' if listener['protocol'] == 'HTTP' else 'VS_MODE_L4'
        #这部分在lb create的时候应该已经创建过了
        '''
        subnetsinfo = self._get_subnets_to_assure(service)
        vad.createIPGroup(name, [service['loadbalancer']['vip_address']],\
                {'mask':int(subnetsinfo[0]['subnet']['cidr'].split('/')[1]), \
                'gatewayIP':subnetsinfo[0]['subnet']['gateway_ip'], 'wan':self._get_loadbalancer_name(service)})
        '''
        self.ad.createServ(name, srvtype, [int(listener['protocol_port'])])
        self.ad.createVS(name, {'poolName': _DEFAULT_POOL, "ipgName":ipg_name, 'serviceName':name, 'enable':enable, 'mode':mode})


    @log_helpers.log_method_call
    def _updateListener(self, loadbalancer, listener) #, vad, service):
        #vsname = 'openstack-'+listener['id']
        vsname = self._get_listener_name(listener['id'])
        enable =  'true ' if listener['admin_state_up'] and loadbalancer['admin_state_up'] else 'false'
        self.ad.updateVS(vsname, {'enable': enable})

    @log_helpers.log_method_call
    def _deleteListener(self, loadbalancer, listener) #, vad, service):
        vsname = self._get_listener_name(listener['id'])
        self.ad.deleteVS(vsname)
        self.ad.deleteServ(vsname)
        '''
        args = dict(wan=self._get_loadbalancer_name(service), ip=[loadbalancer['vip_address']])
        vad.deleteIPGroup(vsname, args)
        lbname = self._get_loadbalancer_name(service)
        '''

    @log_helpers.log_method_call
    def _assure_listeners(self, service):
        if 'listeners' not in service:
            return
        
        listeners = service['listeners']
        loadbalancer = service['loadbalancer']
        for listener in listeners:
            if listener['provisioning_status'] == plugin_const.PENDING_CREATE:
                self._createListener(loadbalancer, listener) #, vad, service)
            elif listener['provisioning_status'] == plugin_const.PENDING_UPDATE:
                self._updateListener(loadbalancer, listener) #, vad, service)
            elif listener['provisioning_status'] == plugin_const.PENDING_DELETE:
                self._deleteListener(loadbalancer, listener) #, vad, service)
            else:
                LOG.debug("Unkown listener state")

    @log_helpers.log_method_call
    def _createPool(self, loadbalancer, pool, vad, service):
        lbname = self._get_loadbalancer_name(loadbalancer['id'])
        poolname = self._get_pool_name(pool['id'])
        method = self._getSchedMethod(pool)
        relat = False if pool['protocol'] != 'HTTP' and \
                pool['sessionpersistence'] and \
                'type' in pool['sessionpersistence '] and \
                pool['sessionpersistence']['type'] != 'SOURCE_IP' else True
        if pool['sessionpersistence'] and relat:
            if pool[sessionpersistence]['type'] == 'SOURCE_IP':
                self.ad.createPersist(poolname, {'type': 'PERSIST_SOURCE_IP'})
            elif pool['sessionpersistence']['type'] == 'HTTP_COOKIE':
                self.ad.createPersist(pool_name, \
                        {'type':'PERSIST_COOKIE', \
                        'cookie_type':'PERSIST_COOKIE_INSERT',\
                        'cookie_name':'openstack_cookie_insert'})
            else:
                self.ad.createPersist(pool_name, \
                        {'type':'PERSIST_COOKIE', \
                        'cookie_type':'PERSIST_COOKIE_STUDY',\
                        'cookie_name':pool['sessionpersistence']['cookie_name']})
            self.ad.createPool(poolname, {'lbMethod':method, 'persist1Name':pool_name})
        else:
            self.ad.createPool(poolname, {'lbMethod':method})
        for listener in pool['listeners']:
            self.ad.updateVS(self._get_listener_name(listener['id']), {'poolName' : poolname})

    @log_helpers.log_method_call
    def _updatePool(self, loadbalancer, pool) #, vad, service):
        lbname = self._get_loadbalancer_name(service)
        pool_name = self._get_pool_name(pool['id'])
        for listener in pool['listeners']:
            enable = 'true' if pool['admin_state_up'] and loadbalancer['admin_state_up'] else 'false'
            self.ad.updateVS(self._get_listener_name(listener['id']), {'enable':enable})
        method = self._getSchedMethod(pool)
        relat = False if pool['protocol'] != 'HTTP' and \
                pool['sessionpersistence'] and \
                'type' in pool['sessionpersistence '] and \
                pool['sessionpersistence']['type'] != 'SOURCE_IP' else True
        if pool['sessionpersistence'] and relat:
            try:
                self.ad.deletePersist(pool_name)
            except Exception as e:
                LOG.debug(e)
            if pool['sessionpersistence']['type'] == 'SOURCE_IP':
                self.ad.createPersist(pool_name, {'type': 'PERSIST_SOURCE_IP'})
                self.ad.updatePool(pool_name, {'persist1Name': pool_name, 'lbMethod':method})
            elif pool['sessionpersistence']['type'] == 'HTTP_COOKIE':
                self.ad.createPersist(pool_name, \
                        {'type':'PERSIST_COOKIE', \
                        'cookie_type':'PERSIST_COOKIE_INSERT',\
                        'cookie_name':'openstack_cookie_insert'})
                self.ad.updatePool(pool_name, {'persist1Name':pool_name, 'lbMethod':method}) 
            else:
                self.ad.createPersist(pool_name, \
                        {'type':'PERSIST_COOKIE', \
                        'cookie_type':'PERSIST_COOKIE_STUDY',\
                        'cookie_name':pool['sessionpersistence']['cookie_name']})
                self.ad.updatePool(pool_name, \
                        {'persist1Name':pool_name, 'lbMethod':method}) 
        else:
            self.ad.updatePool(pool_name, {'lbMethod':method})

    @log_helpers.log_method_call
    def _deletePool(self, loadbalancer, pool) #, vad, service):
        lbname = self._get_loadbalancer_name(service)
        pool_name = self._get_pool_name(pool['id'])
        for member in pool['members']:
            self.ad.deleteMember(pool_name, member['address'], port=member['protocol_port'])
        if pool['sessionpersistence'] :
            self.ad.updatePool(pool_name,  {'persist1Name':'None'})
            self.ad.deletePersist(pool_name)
        if pool['healthmonitor_id']:
            self.ad.deleteMonitor(self._get_monitor_name(pool['healthmonitor_id']))
        for listener in pool['listeners']:
            self.ad.updateVS(self._get_listener_name(listener['id'])\
                    , {'enable':'false', 'poolName':_DEFAULT_POOL})
        self.ad.deletePool(pool_name)

    @log_helpers.log_method_call
    def _assure_pools(self, service):
        if 'pools' not in service:
            return
        
        pools = service['pools']
        loadbalancer = service['loadbalancer']
        for pool in pools:
            if pool['provisioning_status'] == plugin_const.PENDING_CREATE:
                self._createPool(loadbalancer, pool) #, vad, service)
            elif pool['provisioning_status'] == plugin_const.PENDING_UPDATE:
                self._updatePool(loadbalancer, pool) #, vad, service)
            elif pool['provisioning_status'] == plugin_const.PENDING_DELETE:
                self._deletePool(loadbalancer, pool) #, vad, service)
            else:
                LOG.debug("Unkown pool state")

    @log_helpers.log_method_call
    def _createMember(self, loadbalancer, member) #, vad, service):
        pool_name = self._get_pool_name(member['pool_id'])
        self.ad.createMember(pool_name, member['id'], member['address'], member['protocol_port'], {'ratio':member['weight']})
        pass

    @log_helpers.log_method_call
    def _updateMember(self, loadbalancer, member) #, vad, service):
        pool_name = self._get_pool_name(member['pool_id'])
        self.ad.updateMember(pool_name, member['id'], member['address'], member['protocol_port'])
        pass

    @log_helpers.log_method_call
    def _deleteMember(self, loadbalancer, member) #, vad, service):
        pool_name = self._get_pool_name(member['pool_id'])
        self.ad.deleteMember(pool_name, member['id'], member['address'], member['protocol_port'])
        pass

    @log_helpers.log_method_call
    def _createMonitor(self, monitor, service) #, vad, service):
        name = self._get_monitor_name(monitor['id'])
        mtype= "MONITOR_ICMPV4" if monitor['type'] not in _MONITOR_TYPE_MAP else _MONITOR_TYPE_MAP[monitor['type']]
        tryout = monitor['max_retries'] if int(monitor['max_retries'] ) < _MONITOR_RETRIES else _MONITOR_RETRIES
        timeout = monitor['timeout'] if int(monitor['timeout']) < _MONTTOR_MAX_TIMEOUT else _MONTTOR_MAX_TIMEOUT
        interval = monitor['delay'] if int(monitor['delay']) < _MONITOR_MAX_DELAY else _MONITOR_MAX_DELAY
        args={
                'interval':interval,
                'timeout':timeout,
                'tryout':tryout
            }
        if mtype == "MONITOR_CONNECT_TCP":
            self.ad.createMonitor(name, mtype, args)
        elif mtype == 'MONITOR_ICMPV4':
            self.ad.createMonitor(name,mtype, args)
        elif mtype == 'MONITOR_CONNECT_HTTP':
            args['resp_code']=monitor['expected_codes']
            args['url_msg']=monitor['url_path']
            self.ad.createMonitor(name, mtype, args)
        elif mtype == 'MONITOR_CONNECT_HTTPS': 
            LOG.error("Can`t support HTTPS montior")
            return
        for monitor in service['healthmonitors']:
            self.ad.addPoolMonitor(self._get_pool_name(monitor['pool_id']), name)
        pass
    @log_helpers.log_method_call
    def _updateMonitor(self, monitor) #, vad, service):
        name = self._get_monitor_name(monitor['id'])
        interval = monitor['delay'] if int(monitor['delay']) < _MONITOR_MAX_DELAY else _MONITOR_MAX_DELAY
        tryout = monitor['max_retries'] if int(monitor['max_retries'] ) < _MONITOR_RETRIES else _MONITOR_RETRIES
        timeout = monitor['timeout'] if int(monitor['timeout']) < _MONTTOR_MAX_TIMEOUT else _MONTTOR_MAX_TIMEOUT
        mtype= "PING" if monitor['type'] not in _MONITOR_TYPE_MAP else _MONITOR_TYPE_MAP[monitor['type']]
        args={
                'type':mtype,
                'interval':interval,
                'timeout':timeout,
                'tryout':tryout
            }
        if mtype == "MONITOR_CONNECT_TCP":
            self.ad.updateMonitor(name, args)
        elif mtype == 'MONITOR_ICMPV4':
            self.ad.updateMonitor(name, args)
        elif mtype == 'MONITOR_CONNECT_HTTP':
            args['resp_code']=monitor['expected_codes']
            args['url_msg']=monitor['url_path']
            self.ad.updateMonitor(name, args)
        elif mtype == 'MONITOR_CONNECT_HTTPS': 
            args['resp_code']=monitor['expected_codes']
            args['url_msg']=monitor['url_path']
            self.ad.updateMonitor(name, args)  
        pass

    def _deleteMonitor(self, monitor, service):
        name = self._get_monitor_name(monitor['id'])
        for monitor in service['healthmonitors']:
            vad.delPoolMonitor(self._get_pool_name(monitor['pool_id']), name)
        self.ad.deleteMonitor(name)
        pass

    @log_helpers.log_method_call
    def _assure_members(self, service):
        if not (('pools' in service) and ('members' in service)):
            return
        members = service['members']
        loadbalancer = service['loadbalancer']

        for member in members:
            if member['provisioning_status'] == plugin_const.PENDING_CREATE:
                self._createMember(loadbalancer, member) #, vad, service)
            elif member['provisioning_status'] == plugin_const.PENDING_UPDATE:
                self._updateMember(loadbalancer, member) #, vad, service)
            elif member['provisioning_status'] == plugin_const.PENDING_DELETE:
                self._deleteMember(loadbalancer, member) #, vad, service)
            else:
                LOG.debug("Unkown member state")

    @log_helpers.log_method_call
    def _assure_monitors(self, service):
        if not (('pools' in service) and ('healthmonitors' in service)):
            return
        monitors = service['healthmonitors']
        loadbalancer = service['loadbalancer']

        for monitor in monitors:
            if monitor['provisioning_status'] == plugin_const.PENDING_CREATE:
                self._createMonitor(monitor, service)
            elif monitor['provisioning_status'] == plugin_const.PENDING_UPDATE:
                self._updateMonitor(montior)
            elif montior['provisioning_status'] == plugin_const.PENDING_DELETE:
                self._deleteMonitor(monitor, service)
            else:
                LOG.error("unknow montior stat")
    def remove_orphans(loadbalancer):
        pass
    def _resetProvisioningStatus(self, service):
        if service['loadbalancer']['provisioning_status'] == plugin_const.ERROR:
            service['loadbalancer']['provisioning_status'] == plugin_const.PENDING_CREATE

        if 'members' in service:
            for member in service['members']:
                if member['provisioning_status'] == plugin_const.ACTIVE or \
                        member['provisioning_status'] == plugin_const.PENDING_UPDATE or \
                        member['provisioning_status'] == plugin_const.ERROR:
                    member['provisioning_status'] = plugin_const.PENDING_CREATE
        if 'healthmonitors' in service:
            for monitor in service['healthmonitors']:
                if monitor['provisioning_status'] == plugin_const.ACTIVE or \
                        monitor['provisioning_status'] == plugin_const.PENDING_UPDATE or \
                        monitor['provisioning_status'] == plugin_const.ERROR:
                    monitor['provisioning_status'] = plugin_const.PENDING_CREATE
        if 'pools' in service:
            for pool in service['pools']:
                if pool['provisioning_status'] == plugin_const.ACTIVE or \
                        pool['provisioning_status'] == plugin_const.PENDING_UPDATE or \
                        pool['provisioning_status'] == plugin_const.ERROR:
                    pool['provisioning_status'] = plugin_const.PENDING_CREATE
        if 'listeners' in service:
            for listener in service['listeners']:
                if listener['provisioning_status'] == plugin_const.ACTIVE or \
                        monitor['provisioning_status'] == plugin_const.PENDING_UPDATE or \
                        monitor['provisioning_status'] == plugin_const.ERROR:
                    listener['provisioning_status'] = plugin_const.PENDING_CREATE

    def exists(self, service):
        if self.reset == True:
            self.reset = False
            self._resetProvisioningStatus(service)
            return False
        lb = self._get_loadbalancer_name(service)
        try:
           self.mad.getVAD(lb)
           return True
        except:
            return False
