from sangfor_openstack_agent.lbaasv2.drivers.ad.vad import MADHOST as MAD 
from sangfor_openstack_agent.lbaasv2.drivers.ad.vad import VAD as VAD 
from sangfor_openstack_agent.lbaasv2.drivers.ad.utils import compareData as compare
from oslo_log import log as logging
LOG = logging.getLogger(__name__)

__ALL__ = ['MADcache', 'VADcache']

def _needUpdate(name, kargs, cache):
    if name not in cache:
        return True
    else:
        if not compare(kargs, cache[name]):
            return True
    return False

class MADcache(object):
    def __init__(self, username, password, host, port):
        self.mad= MAD(username, password, host, port)
        self.vadCache = {}
        self.vlanCache = {}
        self.vxlanCache = {}
        self.startCache = {}
        self.stopCache = {}

    def createVlan(self, name, vlanid, interface=[]):
        if name in self.vlanCache:
            return

        self.mad.createVlan(name, vlanid, interface)
        self.vlanCache[name] = {
            'id': vlanid,
            'interface':interface
        }
    def updateVlan(self, name, id, interface):
        args = dict(id=id, interface=interface)
        if _needUpdate(name, args, self.vlanCache):
            self.mad.updateVlan(name, vlanid, interface)
            self.vlanCache[name]['id']=vlanid
            self.vlanCache[name]['interface']=interface

    def deleteVlan(self, name):
        self.mad.deleteVlan(name)
        if name in self.vlanCache:
            del self.vlanCache[name]

    def createVxlan(self, name, vxlanid, remoteaddr=[], remoteport=4789):
        if name in self.vxlanCache:
            return
        self.mad.createVxlan(name, vxlanid, remoteaddr, remoteport)
        self.vxlanCache[name] = dict(vxlanid=vxlanid, remoteaddr=remoteaddr, remoteport=remoteport)
        pass

    def updateVxlan(self, name, vxlanid, remoteaddr, remoteport=4789):
        args = dict(vxlanid=vxlanid, remoteaddr=remoteaddr,remoteport=remoteport)
        if _needUpdate(name, args, self.vxlanCache[name]):
            self.mad.updateVxlan(name, vxlanid, remoteaddr, remoteport)
            self.vxlanCache[name] = args

    def deleteVxlan(self, name):
        self.mad.deleteVxlan(name)
        if name in self.vxlanCache:
            del self.vxlanCache[name]

    def createVAD(self, name, kargs):
        if name in self.vadCache:
            return
        kargs['mad']=self.mad.mad
        vad = self.mad.createVAD(name, kargs)
        kargs['vad'] = vad
        kargs['mad']=self.mad
        vad = VADcache(name, kargs)
        self.vadCache[name]=vad
        return vad
    def deleteVAD(self, name):
        vad = self.getVAD(name)
        vad.delete()
        if name in self.vadCache:
            del self.vadCache[name]
    def stopVAD(self, name):
        self.mad.stopVAD(name)

    def getVAD(self, name):
        if name in self.vadCache:
            return self.vadCache[name]
        vad = self.mad.getVAD(name)
        kargs = dict(mad=self.mad, mirror=vad.mirror, 
                ip=vad.ip, mask=vad.mask,password=vad.password, 
                bri_type=vad.bri_type, bri_name = vad.bri_name, interface=[],
                vad=vad)
        return VADcache(name, kargs)

    def getVADList(self):
        vadList = self.mad.getVADList()
        vadCacheList = []
        for vad in vadList:
            kargs = dict(mad=self.mad, mirror=vad.mirror, 
                    ip=vad.ip, mask=vad.mask,password=vad.password, 
                    bri_type=vad.bri_type, bri_name = vad.bri_name, interface=[],
                    vad=vad)
            vadCacheList.append(VADcache(vad.name, kargs))
        return vadCacheList
    def getmirrorList(self):
        return self.mad.getmirrorList()

class VADcache(object):
    def __init__(self, name, kargs):
        self.ipGroupCache={}
        self.ipCache = {}
        self.servCache = {}
        self.vsCache = {}
        self.poolCache = {}
        self.memberCache = {}
        self.poolMonitorCache ={}
        self.persistCache = {}
        self.wanCache = {}
        self.monitorCache ={}
        self.name = name
        kargs['mad'] = kargs['mad'].mad
        self.vad = VAD(name, kargs)
    def createServ(self, name, Stype="SRV_HTTP", port=[]):
        if name in self.servCache:
            return
        self.vad.createServ(name, Stype, port)
        self.servCache[name] = dict(type=Stype, port=port)
        pass
    def updateServ(self, name, Stype="SRV_HTTP", port=[]):
        args = dict(type=Stype, port=port)
        if _needUpdate(name, args, self.servCache):
            self.vad.updateServ(name, Stype, port)
            self.servCache[name] = args

        pass

    def deleteServ(self, name):
        self.vad.deleteServ(name)
        if name in self.servCache:
            del self.servCache[name]
        pass

    def createIPGroup(self, name, ip=[], args={}):
        if name in self.ipGroupCache:
            return 
        self.vad.createIPGroup(name, ip, args)
        self.ipGroupCache[name] = dict(ip=ip)
        pass
    def updateIPGroup(self, name, ip=[]):
        args = dict(ip=ip)
        if _needUpdate(name, args, self.ipGroupCache):
            self.vad.updateIPGroup(name, ip)
            self.ipGroupCache[name] = args
        pass
    def deleteIPGroup(self, name, args):
        self.vad.deleteIPGroup(name, args)
        if name in self.ipGroupCache:
            del self.ipGroupCache[name]
        pass
    def IPGroupAddIP(self, ipgrpname="", ip=[]):
        newip = []
        if ipgrpname in self.ipCache:
            for single in ip:
                if single not in self.ipCache[ipgrpname]['ip']:
                    newip.append(single)
        else:
            self.vad.IPGroupAddIP(ipgrpname, ip)
            self.ipCache[ipgrpnamer] = {'ip':ip}
            

        if len(newip):
            self.vad.IPGroupAddIP(ipgrpname, newip)
        for single in newip:
            self.ipCache[ipgrpname]['ip'].append(single)

        pass
    def IPGroupDelIP(self, ipgrpname="", ip=[]):
        if ipgrpname in self.ipCache:
            self.vad.IPGroupDelIP(ipgrpname, ip)
            for single in ip:
                if single in self.ipCache[ipgrpname]['ip']:
                    self.ipCache[ipgrpname]['ip'].remove(single)
        else:
            self.vad.IPGroupDelIP(ipgrpname, ip)
        pass

    def createPersist(self, name, kargs={}):
        if name in self.persistCache:
            return
        self.vad.createPersist(name, kargs)
        self.persistCache[name] = kargs
        pass
    def deletePersist(self, name):
        self.vad.deletePersist(name)
        if name in self.persistCache:
            del self.persistCache[name]
        pass


    def updatePersist(self, name, kargs={}):
        if _needUpdate(name, kargs, self.persistCache):
            self.deletePersist(name)
            self.createPersist(name, kargs)
            self.persistCache[name] = kargs
    def createMonitor(self, name, type='MONITOR_CONNECT_TCP', kargs={}):
        if name in self.monitorCache:
            return
        self.vad.createMonitor(name, type, kargs)
        self.monitorCache[name] = { 'type':type, 'kargs':kargs }
        pass
    def updateMonitor(self, name, type='MONITOR_CONNECT_TCP', kargs={}):
        args = dict(type=type, kargs=kargs)
        if _needUpdate(name, args, self.monitorCache):
            self.vad.updateMonitor(name, type, kargs)
            self.monitorCache[name] = args
        pass
    def deleteMonitor(self, name):
        self.vad.deleteMonitor(name)
        if name in self.monitorCache:
            del self.monitorCache[name]
        pass
    def createPool(self, name, kargs={}):
        if name in self.poolCache:
            return
        self.vad.createPool(name, kargs)
        self.poolCache[name] = kargs
        pass
    def updatePool(self, name, kargs={}):
        if _needUpdate(name, kargs, self.poolCache):
            self.vad.updatePool(name, kargs)
            self.poolCache[name]=kargs
        pass
    def deletePool(self, name):
        self.vad.deletePool(name)
        if name in self.poolCache:
            del self.poolCache[name]
        pass
    def createMember(self, name, mid, ip="", port=80, kargs={}):

        if mid in self.memberCache:
            return
        self.vad.createMember(name, ip, port, kargs)
        self.memberCache[mid] = {'name':name, 'ip':ip, 'port':port, 'kargs':kargs}

    def deleteMember(self, name, mid, ip, port, kargs={}):
        self.vad.deleteMember(name, ip ,port, kargs)
        if name in self.memberCache:
            del self.memberCache[mid]

    def updateMember(self, name, mid, ip="", port=80, kargs={}):
        args = dict(name=name, ip=ip, port=port, kargs=kargs)
        if _needUpdate(mid, args, self.memberCache):
            self.deleteMember(name, mid, ip, port, kargs)
            self.createMember(name, mid, ip, port, kargs)
            self.memberCache[mid]=args

    def addPoolMonitor(self, poolname, monitorname):
        key = poolname+':'+monitorname
        if key in self.poolMonitorCache:
            return
        self.vad.addPoolMonitor(poolname, monitorname)
        self.poolMonitorCache[key] = True

    def delPoolMonitor(self, poolname, monitorname):
        self.vad.delPoolMonitor(poolname, monitorname)
        key = poolname+':'+monitorname
        if key in self.poolMonitorCache:
            del self.poolMonitorCache[key]

    def createVS(self, name,  kargs={}):
        if name in self.vsCache:
            return
        self.vad.createVS(name, kargs)
        self.vsCache[name] = kargs
        pass
    def updateVS(self, name, kargs={}):
        if _needUpdate(name, kargs, self.vsCache):
            self.vad.updateVS(name, kargs)
            self.vsCache[name] = kargs
        pass
    def deleteVS(self, name):
        self.vad.deleteVS(name)
        if name in self.vsCache:
            del self.vsCache[name]
        pass

    def createWan(self, name, ifname, ips=[], args={}):
        if name in self.wanCache:
            return
        self.vad.createWan(name, ifname, ips, args)

    def resetConfig(self):
        self.vad.resetConfig()

    def start(self):
        self.vad.start()

    def started(self):
        return self.vad.started()

    def stop(self):
        self.vad.stop()

    def delete(self):
        self.vad.delete()

    def getPoolList(self):
        return self.vad.getPoolList()
