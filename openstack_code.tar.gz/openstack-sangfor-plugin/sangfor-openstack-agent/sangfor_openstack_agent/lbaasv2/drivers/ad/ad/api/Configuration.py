# -*- coding: utf-8 -*-
# Copyright (c) 2008-2016, AD SANGFOR, [Version 6.3.0]
# Filename: Configuration.py
from urllib2 import base64
from http.HttpClient import HttpClient

__version__ = '6.3.0'
__author__ = 'ad.sangfor.com'

# 用于管理连接AD的配置，包括AD的IP、AD的端口、登入AD所需的用户名和密码
# 会先对用户名/密码进行base64编码
class Configuration :
    '''
    用于管理连接AD的配置，包括AD的IP、AD的端口、登入AD所需的用户名、密码和超时时间

    @var self.m_ip AD 的 IP
    @type self.m_ip string
    @var self.m_port AD 的端口
    @type self.m_port int
    @var self.m_username 登入AD的用户名
    @type self.m_username string
    @var self.m_password 登入用户的密码
    @type self.m_password string
    '''
    def __init__(self, username, password, ip, port = 443, timeout = 20) :
        self.init(username, password, ip, port, timeout)
        
        # 获取节点状态列表
        self.getNodeStatusURI = "/api/get/status/node_pool/status.cgi"
        # 获取节点池列表
        self.getNodePoolListURI = "/api/get/conf/node_pool/list.cgi"
        # 获取节点列表
        self.getNodeListURI = "/api/get/conf/node_pool/nodes.cgi"
        # 获取节点信息
        self.getNodeInfoURI = "/api/get/conf/node_pool/node.cgi"
        # 更新节点
        self.updateNodeURI = "/api/post/conf/node_pool/node/update.cgi"
        # 删除节点
        self.deleteNodeURI = "/api/post/conf/node_pool/node/delete.cgi"
        # 创建节点
        self.createNodeURI = "/api/post/conf/node_pool/node/create.cgi"   
        
        #restful api url 列表
        # 创建服务
        self.createServURI = "/api/rest/adapi_rest.cgi/createServ"
        # 获取服务列表
        self.getServListURI = "/api/rest/adapi_rest.cgi/serv/list"
        # 获取具体服务信息
        self.getServInfoURI = "/api/rest/adapi_rest.cgi/serv"
        # 添加服务端口
        self.addServPortURI = "/api/rest/adapi_rest.cgi/addServPort"
        # 删除服务端口
        self.delServPortURI = "/api/rest/adapi_rest.cgi/delServPort"
        # 删除服务
        self.delServURI = "/api/rest/adapi_rest.cgi/delServ"
        # 创建IP组
        self.createIpGroupURI = "/api/rest/adapi_rest.cgi/createIpGroup"
        # 获取IP组列表
        self.getIpGroupListURI = "/api/rest/adapi_rest.cgi/ipgroup/list"
        # 获取具体IP组列表
        self.getIpGroupInfoURI = "/api/rest/adapi_rest.cgi/ipgroup"
        # 添加IP
        self.addIpURI = "/api/rest/adapi_rest.cgi/addIp"
        # 删除IP
        self.delIpURI = "/api/rest/adapi_rest.cgi/delIp"
        # 删除IP组
        self.delIpGroupURI = "/api/rest/adapi_rest.cgi/delIpGroup"
        # 创建会话保持
        self.createPersistURI = "/api/rest/adapi_rest.cgi/createPersist"
        # 获取会话保持列表
        self.getPersistListURI = "/api/rest/adapi_rest.cgi/persist/list"
        # 获取会话保持信息
        self.getPersistInfoURI = "/api/rest/adapi_rest.cgi/persist"
        # 更新会话保持
        self.updatePersistURI = "/api/rest/adapi_rest.cgi/updatePersist"
        # 删除会话保持
        self.delPersistURI = "/api/rest/adapi_rest.cgi/delPersist"
        # 创建节点监视器
        self.createNodeMonitorURI = "/api/rest/adapi_rest.cgi/createNodeMonitor"
        # 获取节点监视器列表
        self.getMonitorListURI = "/api/rest/adapi_rest.cgi/nodemonitor/list"
        # 获取节点监视器信息
        self.getMonitorInfoURI = "/api/rest/adapi_rest.cgi/nodemonitor"
        # 更新节点监视器
        self.updateNodeMonitorURI = "/api/rest/adapi_rest.cgi/updateNodeMonitor"
        # 删除节点监视器
        self.delMonitorURI = "/api/rest/adapi_rest.cgi/delNodeMonitor"
        # 创建节点池
        self.createNodePoolURI = "/api/rest/adapi_rest.cgi/createNodePool"
        # 获取节点池列表
        self.getNodePoolListV2URI = "/api/rest/adapi_rest.cgi/nodepool/list"
        # 获取节点池信息
        self.getNodePoolInfoURI = "/api/rest/adapi_rest.cgi/nodepool"
        # 更新节点池
        self.updateNodePoolURI = "/api/rest/adapi_rest.cgi/updateNodePool"
        # 删除节点池
        self.delNodePoolURI = "/api/rest/adapi_rest.cgi/delNodePool"
        # 创建节点
        self.createNodeV2URI = "/api/rest/adapi_rest.cgi/createNode"
        # 获取节点列表
        self.getNodeListV2URI = "/api/rest/adapi_rest.cgi/node/list"
        # 获取节点信息
        self.getNodeInfoV2URI = "/api/rest/adapi_rest.cgi/node"
        # 获取节点状态
        self.getNodeStatusV2URI = "/api/rest/adapi_rest.cgi/node/status"
        # 更新节点
        self.updateNodeV2URI = "/api/rest/adapi_rest.cgi/updateNode"
        # 删除节点
        self.delNodeURIV2URI = "/api/rest/adapi_rest.cgi/delNode"
        # 创建虚拟服务
        self.createVsURI = "/api/rest/adapi_rest.cgi/createVs"
         # 获取虚拟服务列表
        self.getVsListURI = "/api/rest/adapi_rest.cgi/vs/list"
        # 获取虚拟服务信息
        self.getVsInfoURI = "/api/rest/adapi_rest.cgi/vs"
        # 获取虚拟服务状态
        self.getVsStatusURI = "/api/rest/adapi_rest.cgi/vs/status"
        # 更新虚拟服务
        self.updateVsURI = "/api/rest/adapi_rest.cgi/updateVs"
        # 删除虚拟服务
        self.delVsURI = "/api/rest/adapi_rest.cgi/delVs"
        # openstack reset
        self.reSetURI = "/api/rest/adapi_rest.cgi/reset"
        # 创建wan
        self.createWanURI = "/api/rest/adapi_rest.cgi/createWan"
        # 更新wan
        self.updateWanURI = "/api/rest/adapi_rest.cgi/updateWan"
        # 删除wan
        self.deleteWanURI = "/api/rest/adapi_rest.cgi/deleteWan"
        # 创建lan
        self.createLanURI = "/api/rest/adapi_rest.cgi/createLan"
        # 更新lan
        self.updateLanURI = "/api/rest/adapi_rest.cgi/updateLan"
        # 删除lan
        self.deleteLanURI = "/api/rest/adapi_rest.cgi/deleteLan"
        #获取wan口列表: getWanList
        self.getWanListURI = "/api/rest/adapi_rest.cgi/wan/list"
        #获取具体wan口
        self.getWanInfoURI = "/api/rest/adapi_rest.cgi/wan"
        #获取lan口列表: getLanList
        self.getLanListURI = "/api/rest/adapi_rest.cgi/lan/list"
        #获取具体lan口
        self.getLanInfoURI = "/api/rest/adapi_rest.cgi/lan"
        #获取设备状态信息
        self.getSysStautsURI = "/api/rest/adapi_rest.cgi/sysstatus"
        #创建高级ACL
        self.createAclURI = "/api/rest/adapi_rest.cgi/createAcl"
        #删除高级ACL
        self.delAclURI = "/api/rest/adapi_rest.cgi/delAcl"
        #更新高级ACL
        self.updateAclURI = "/api/rest/adapi_rest.cgi/updateAcl"
        #获取高级ACL列表
        self.getAdvanceAclListURI = "/api/rest/adapi_rest.cgi/advacl/list"
        #获取具体高级ACL
        self.getAdvanceAclInfoURI = "/api/rest/adapi_rest.cgi/advacl"
        #增量添加节点池的监视器
        self.addPoolMonitorURI = "/api/rest/adapi_rest.cgi/addPoolMonitor"
        #增量删除节点池的监视器
        self.delPoolMonitorURI = "/api/rest/adapi_rest.cgi/delPoolMonitor"
        #创建mysql策略
        self.createMySQLProfile = "/api/rest/adapi_rest.cgi/createMySQLProfile"
        #更新mysql策略
        self.updateMySQLProfile = "/api/rest/adapi_rest.cgi/updateMySQLProfile"
        #获取mysql策略
        self.getMySQLProfileInfoURI = "/api/rest/adapi_rest.cgi/mysqlprofile"
        # 创建snat地址集
        self.createSnatSetURI = "/api/rest/adapi_rest.cgi/createSnatSet"
        # 更新snat地址集
        self.updateSnatSetURI = "/api/rest/adapi_rest.cgi/updateSnatSet"
        # 删除snat地址集
        self.deleteSnatSetURI = "/api/rest/adapi_rest.cgi/deleteSnatSet"
        # 获取snat地址集列表
        self.getSnatSetListURI = "/api/rest/adapi_rest.cgi/snatset/list"
        # 获取snat地址集
        self.getSnatSetURI = "/api/rest/adapi_rest.cgi/snatset"
        #测试Openstack验证用户名密码
        self.testURI = "/api/rest/adapi_rest.cgi/test"
        
    def init(self, username, password, ip, port, timeout = 20) :
        '''
        初始化ADAPI SDK所需的信息。对于用户名密码会进行base64编码。
        @param ip 登入AD的IP
        @type ip string
        @param port 登入AD的端口 默认为443
        @type port int
        @param username 登入AD的用户名
        @type username string
        @param password 登入AD的密码
        @type password string
        @params timeout 设置超时时间
        @type timeout int
        @return    无
        @rtype    无
        '''
        self.ip = ip
        self.port = port
        #self.timeout = timeout

        self.username = base64.b64encode(username)#base64.encodestring(username)
        self.password = base64.b64encode(password)#base64.encodestring(password)
        #print "username: " + self.username + "; password: " + self.password
        self.timeout = timeout
        if self.timeout != None :
            HttpClient.setTimeout(self.timeout)
            #socket.setdefaulttimeout(self.timeout) # 10 秒钟后超时
            #urllib2.socket.setdefaulttimeout(self.timeout) # 另一种方式
    '''
    获取ADAPI的版本信息
    '''
    @classmethod
    def getVersion(cls) :
        import __init__
        return __init__.__version__
    @classmethod
    def base64encode(cls, src) :
        if src == None:
            return None
        return base64.b64encode(src)
    @classmethod
    def base64decode(cls, src) :
        if src == None:
            return None
        return base64.b64decode(src)
