# -*- coding: utf-8 -*-
# Copyright (c) 2008-2016, AD SANGFOR, [Version 6.3.0]
# Filename: WanInfo.py

from Configuration import Configuration
from APIException import APIException
from ErrorInfo import ErrInfo
from urllib2 import base64
import XMLObject as xmlo
import urllib
from ParentList import ParentList
from AddrElement import AddrElement


class WanInfo (ErrInfo) :
    def __init__(self, httpBody = None) :
        ErrInfo.__init__(self, httpBody)
        self.wan_name = None
        self.enable = None
        self.ifname = None
        self.ip_addr = []             # 存放网口ip(ip/mask)，兼容旧版本
        self.ip_addr_map = []         # 网口ip，AddrElement类型，新建/更新时用到
        self.gw_addr_map = []         # ipv4网关，AddrElement类型(非集群时，只用一个网关)
                                      # 当集群时，ipv4/ipv6网关同时存在gw_addr_map中
        self.gw_addr_v6_map = None    # ipv6网关，AddrElement类型
        self.max_up_bandwidth = -1    # 上行带宽，单位：Kbps
        self.max_down_bandwidth = -1  # 下行带宽，单位：Kbps
        self.up_busy_rate = -1        # 上行繁忙比，单位：%
        self.down_busy_rate = -1      # 下行繁忙比，单位：%
        self.inet_addr_map = []       # 网口ip对应的互联网ip, AddrElement类型
        self.enable_detect = None     # 健康监测开关    'true'/'false'
        self.arp_detect = None        # 网关arp监测开关
        self.monitor = []             # 监视器(ping/ping6/http)
        self.detect_host = []         # 监视主机列表
        self.enable_nic_check = None  # 网线插拔检测开关
        if httpBody == "" or httpBody == None :
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0 :
            return
        if not isinstance(httpBody, unicode) :
                httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)
            xmlChildObj = None
            if self.xmlObj.hasTag("wan_name") :
                self.wan_name = urllib.unquote(Configuration.base64decode(self.xmlObj["wan_name"][0].getChildValue()))
            if self.xmlObj.hasTag("ifname") :
                xmlChildObj = self.xmlObj["ifname"][0]
                if xmlChildObj.hasTag('ifname'):
                    self.ifname = urllib.unquote(Configuration.base64decode(xmlChildObj.getChildObj('ifname')[0].getChildValue()))
                if xmlChildObj.hasTag('enable'):
                    self.enable = xmlChildObj.getChildObj('enable')[0].getChildValue()
            if self.xmlObj.hasTag("ip_addr") :
                self.ip_addr = []
                xmlChildObj = self.xmlObj["ip_addr"]
                for ip in xmlChildObj:
                    self.ip_addr.append(ip.getChildValue())
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)

    def __str__(self) :
        return self.originStr

    @classmethod
    def netifToXml(cls, wanInfo):
        params = ''
        if wanInfo.ifname is not None:
            params += '<ifname>' + wanInfo.ifname + '</ifname>'
        if wanInfo.enable is not None:
            params += '<enable>' + wanInfo.enable + '</enable>'
        if len(wanInfo.ip_addr_map) != 0:
            for addr in wanInfo.ip_addr_map:
                params += '<ip_addr>'
                params += '<info>' + addr.ip + '</info>'
                params += '<info_id>' + str(addr.info_id) + '</info_id>'
                params += '</ip_addr>'
        if len(wanInfo.gw_addr_map) != 0:
            for addr in wanInfo.gw_addr_map:
                params += '<gw_addr>'
                params += '<info>' + addr.ip + '</info>'
                params += '<info_id>' + str(addr.info_id) + '</info_id>'
                params += '</gw_addr>'
        if wanInfo.gw_addr_v6_map is not None:
            params += '<gw_addr_v6>'
            params += '<info>' + wanInfo.gw_addr_v6_map.ip + '</info>'
            params += '<info_id>' + str(wanInfo.gw_addr_v6_map.info_id) + '</info_id>'
            params += '</gw_addr_v6>'
        if wanInfo.max_up_bandwidth != -1:
            params += '<max_up_bandwidth>' 
            params += str(wanInfo.max_up_bandwidth)
            params += '</max_up_bandwidth>'
        if wanInfo.max_down_bandwidth != -1:
            params += '<max_down_bandwidth>' 
            params += str(wanInfo.max_down_bandwidth)
            params += '</max_down_bandwidth>'
        if wanInfo.up_busy_rate != -1:
            params += '<up_busy_rate>' 
            params += str(wanInfo.up_busy_rate)
            params += '</up_busy_rate>'
        if wanInfo.down_busy_rate != -1:
            params += '<down_busy_rate>' 
            params += str(wanInfo.down_busy_rate)
            params += '</down_busy_rate>'
        if params != '':
            params = '<netif>' + params + '</netif>'
        return params

    @classmethod
    def wanInfoToXml(cls, wanInfo):
        params = ''
        if wanInfo is not None:
            params += '<netif_info>'
            if wanInfo.wan_name is not None:
                params += '<name>' + base64.b64encode(wanInfo.wan_name) + '</name>'
            params += WanInfo.netifToXml(wanInfo)
            if len(wanInfo.inet_addr_map) != 0:
                for addr in wanInfo.inet_addr_map:
                    params += '<inet_addr>'
                    params += '<info>' + addr.ip + '</info>'
                    params += '<info_id>' + str(addr.info_id) + '</info_id>'
                    params += '</inet_addr>'
            if wanInfo.enable_detect is not None:
                params += '<enable_detect>' + wanInfo.enable_detect + '</enable_detect>'
            if wanInfo.enable_detect == 'true':
                if wanInfo.arp_detect is not None:
                    params += '<arp_detect>' + wanInfo.arp_detect + '</arp_detect>'
                if len(wanInfo.monitor) != 0:
                    for item in wanInfo.monitor:
                        params += '<monitor>' + item + '</monitor>'
                if len(wanInfo.detect_host) != 0:
                    for host in wanInfo.detect_host:
                        params += '<detect_host>' + host + '</detect_host>'
            if wanInfo.enable_nic_check is not None:
                params += '<enable_nic_check>' + wanInfo.enable_nic_check + '</enable_nic_check>'
            params += '</netif_info>'
        return params


    @classmethod
    def generatingwanList(cls, httpBody) :
        return WanList(httpBody)

    @classmethod
    def generatingwanInfo(cls, httpBody) :
        return WanInfo(httpBody)
        
class WanList (ParentList) :
    '''
    '''
    def __init__(self, httpBody = None) :
        ParentList.__init__(self, httpBody)
        if httpBody == None or httpBody == "" :
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0 :
            return
        if not isinstance(httpBody, unicode) :
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)
            if self.xmlObj.hasTag("WanInfoListType"):
                if not self.xmlObj.hasTag("wan_info"):
                    return
                wanListXmlObj = self.xmlObj["wan_info"]
            elif self.xmlObj.hasTag("WanIpListType") :
                wanListXmlObj = self.xmlObj["WanIpListType"]
            else:
                return
            for i in range(len(wanListXmlObj)) :
                node = WanInfo(wanListXmlObj[i].toxml())
                self.elementList.append(node)
                self.length += 1
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)