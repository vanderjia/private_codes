# -*- coding: utf-8 -*-
# Copyright (c) 2008-2016, AD SANGFOR, [Version 6.3.0]
# Filename: NodeInfo.py

import XMLObject as xmlo
from APIException import APIException
from ErrorInfo import ErrInfo

class NodePool (ErrInfo) :
    '''
    从xml中获取节点池信息
    '''
    def __init__(self, httpBody = None) :
        ErrInfo.__init__(self, httpBody)
        self.name = None
        if httpBody == None or httpBody == "":
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0 :
            return
        if not isinstance(httpBody, unicode) :
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)

            if self.xmlObj.hasTag("node_pool") :
                self.name = self.xmlObj["name"][0].getChildValue()

        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)
    def __str__(self) :
        return str(self.originStr)
    #@staticmethod
    @classmethod
    def generatingPoolList(self, httpBody) :
        return PoolList(httpBody)

class PoolList (ErrInfo) :
    '''
    从xml中获取节点池列表
    '''
    def __init__(self, httpBody = None) :
        ErrInfo.__init__(self, httpBody)
        self.length = 0
        #self.index = 0
        self.poolList = []
        if httpBody == None or httpBody == "":
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0 :
            return
        if not isinstance(httpBody, unicode) :
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.xmlObj = xmlo.XMLObject(httpBody)

            if not self.xmlObj.hasTag("node_pool_list") :
                raise APIException("not node pool list data")
            if not self.xmlObj.hasTag("node_pool") :
                return
            poolListXmlObj = self.xmlObj["node_pool"]
            #print nodeListXmlObj.m_obj

            #print len(nodeListXmlObj)
            for i in range(len(poolListXmlObj)) :
                #print nodeListXmlObj[i].toxml()
                pool = NodePool(poolListXmlObj[i].toxml())
                self.poolList.append(pool)
                self.length += 1
        except xmlo.XMLObjectException, e:
            raise APIException(3, e.reason)
    def __len__(self) :
        if self.poolList == None :
            return 0
        return len(self.poolList)
    def __iter__(self) :
        '''
        迭代器
        '''
        #self.index = 0
        return iter(self.poolList)
    #def next(self) :
        #if self.index == self.length :
        #    raise StopIteration
        #self.index += 1
        #return self.poolList[self.index - 1]
    def __getitem__(self, key) :
        '''
        重载下标操作符
        '''
        #if key >= self.length :
        #    return None
        return self.poolList[key]
    def __delitem__(self, key) :
        del self.poolList[key]
    def __setitem__(self, key, value) :
        self.poolList[key] = value




