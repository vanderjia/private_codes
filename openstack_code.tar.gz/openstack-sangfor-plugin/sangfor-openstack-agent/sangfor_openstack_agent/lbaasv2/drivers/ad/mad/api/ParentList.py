# -*- coding: utf-8 -*-
# Copyright (c) 2008-2020, AD SANGFOR
# Filename: ParentList.py

from ErrorInfo import ErrInfo


class ParentList (ErrInfo):
    def __init__(self, httpBody=None):
        ErrInfo.__init__(self, httpBody)
        self.elements = []

    def __len__(self):
        if self.elements is None:
            return 0
        return len(self.elements)

    def __iter__(self):
        '''
        迭代器
        '''
        return iter(self.elements)

    def __getitem__(self, index):
        '''
        重载下标操作符
        '''
        return self.elements[index]

    def __delitem__(self, key):
        del self.elements[key]

    def __setitem__(self, key, value):
        self.elements[key] = value
