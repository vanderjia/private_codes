# -*- coding: utf-8 -*-
# Copyright (c) 2008-2020, AD SANGFOR
# Filename: SrouteInfo.py
# 定义静态路由信息
from Configuration import Configuration
from APIException import APIException
from ErrorInfo import ErrInfo
from http.HttpClient import HttpClient
from ParentList import ParentList
from urllib2 import base64
import JSONObj as jsono
import urllib
import json
import codecs


class SrouteInfo(ErrInfo):
    '''
    静态路由信息
    {
        'id': ,
        'net': ,
        'gw': ,
    }
    '''
    def __init__(self, httpBody=None):
        ErrInfo.__init__(self, httpBody)
        self.id = 0             # 静态路由配置id
        self.net = None         # 目的网段
        self.mask = 0           # 目的网络掩码
        self.gw = None          # 下一条地址
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('id'):
                self.id = int(self.jsonObj['id'])
            if self.jsonObj.hasTag('net'):
                self.net = self.jsonObj['net']
            if self.jsonObj.hasTag('mask'):
                self.mask = int(self.jsonObj['mask'])
            if self.jsonObj.hasTag('gw'):
                self.gw = self.jsonObj['gw']
        except jsono.JSONObjException, e:
            raise APIException(3, e.reason)

    @classmethod
    def srouteInfoToDict(cls, srouteInfo):
        srouteDict = {}
        srouteDict['id'] = srouteInfo.id
        if srouteInfo.net is not None:
            srouteDict['net'] = srouteInfo.net
        else:
            srouteDict['net'] = ''
        srouteDict['mask'] = srouteInfo.mask
        if srouteInfo.gw is not None:
            srouteDict['gw'] = srouteInfo.gw
        else:
            srouteDict['gw'] = ''
        return srouteDict

    @classmethod
    def generatingSrouteList(cls, httpBody):
        return SrouteList(httpBody)


class SrouteList(ParentList):
    '''
    静态路由信息列表
    {
        'data': [
            {'id': , ...}
        ]
    }
    '''
    def __init__(self, httpBody):
        ParentList.__init__(self, httpBody)
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if not self.jsonObj.hasTag('data'):
                return
            for item in self.jsonObj['data']:
                sroute = SrouteInfo(json.dumps(item, ensure_ascii=False))
                self.elements.append(sroute)
        except jsono.JSONObjException, e:
            raise APIException(3, e.reason)
