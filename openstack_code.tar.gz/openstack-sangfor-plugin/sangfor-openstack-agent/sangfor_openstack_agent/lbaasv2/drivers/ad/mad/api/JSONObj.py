# -*- coding: utf-8 -*-
# Copyright (c) 2008-2020, AD SANGFOR
# Filename: JSONObject.py
import json


class JSONObjException(StandardError):
    '''
    解析json字符串
    '''

    def __init__(self, code, reason):
        '''
        1 can't parse json
        2 can't find tag
        3 can't find attributes
        4 can't find child nodes
        5 can't get node value
        @param  reason 出错信息
        @type   str
        @param  code 错误码
        @type   int
        '''
        StandardError.__init__(self, reason)
        self.code = code
        self.reason = reason

    def __str__(self):
        '''
        '''
        return 'JSONObjException: %d; %s' % (self.code, self.reason)


class JSONObj:

    def __init__(self, jsonStr):
        '''
        要求传入的参数是unicode对象 utf8编码
        @param json 字符串
        @param unicode
        '''
        try:
            if not isinstance(jsonStr, unicode):
                jsonStr = unicode(jsonStr, "utf8")
            self.jsonObj = json.loads(jsonStr.encode("utf8"))
        except:
            raise JSONObjException(1, "can't parse json")

    def __getitem__(self, key):
        '''
        重载下标操作符
        @param key 要获取的子节点的tag
        @type str
        @return 子节点列表
        @rtype XMLChildListObject
        '''
        if key not in self.jsonObj:
            raise JSONObjException(2, "can't parse json")
        return self.jsonObj[key]

    def hasTag(self, tag):
        '''
        检测是否有相关字段
        @param tag json字段
        '''
        if tag in self.jsonObj:
            return True
        else:
            return False

    def toJson(self):
        '''
        返回本对象的json字符串
        '''
        return json.dumps(self.jsonObj)
