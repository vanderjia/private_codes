# -*- coding: utf-8 -*-
# Copyright (c) 2008-2020, AD SANGFOR
# Filename: PersistInfo.py
# 定义会话保持配置信息
from APIException import APIException
from ErrorInfo import ErrInfo
from ParentList import ParentList
from urllib2 import base64
import JSONObj as jsono
import urllib
import json
import codecs


class PersistInfo(ErrInfo):
    def __init__(self, httpBody=None):
        ErrInfo.__init__(self, httpBody)
        self.name = None
        self.type = None
        self.priorToConnect = None
        self.maskv4 = None
        self.maskv6 = None
        self.sourceipTimeout = -1
        self.cookieType = None
        self.cookieName = None
        self.cookieDomain = None
        self.cookiePath = None
        self.cookieTimeout = -1
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
                httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('persist_name'):
                self.name = base64.b64decode(self.jsonObj['persist_name'])
            if self.jsonObj.hasTag('p_type'):
                self.type = self.jsonObj['p_type']
            if self.jsonObj.hasTag('PersistInfoType'):
                pers = self.jsonObj['PersistInfoType']
                if 'persist_name' in pers:
                    self.name = base64.b64decode(pers['persist_name'])
                if 'p_type' in pers:
                    self.type = pers['p_type']
                if 'prior_to_connect' in pers:
                    self.priorToConnect = pers['prior_to_connect']
                if 'cookie' in pers:
                    cookie = pers['cookie']
                    if 'cookie_name' in cookie:
                        self.cookieName = \
                            base64.b64decode(cookie['cookie_name'])
                    if 'cookie_type' in cookie:
                        self.cookieType = cookie['cookie_type']
                    if 'cookie_domain' in cookie:
                        self.cookieDomain = cookie['cookie_domain']
                    if 'cookie_path' in cookie:
                        self.cookiePath = \
                            urllib.unquote(cookie['cookie_path'])
                    if 'cookie_timeout' in cookie:
                        self.cookieTimeout = int(cookie['cookie_timeout'])
                if 'sourceIp' in pers:
                    sourceIp = pers['sourceIp']
                    if 'mask_v4' in sourceIp:
                        self.maskv4 = sourceIp['mask_v4']
                    if 'mask_v6' in sourceIp:
                        self.maskv6 = sourceIp['mask_v6']
                    if 'sourceip_timeout' in sourceIp:
                        self.sourceipTimeout = \
                            int(sourceIp['sourceip_timeout'])
        except jsono.JSONObjException as e:
            raise APIException(3, e.reason)

    @classmethod
    def persistInfoToDict(cls, pers):
        persDict = {}
        if pers.name is not None:
            persDict['name'] = pers.name
        if pers.type is not None:
            persDict['type'] = pers.type
        if pers.priorToConnect is not None:
            persDict['prior_to_connect'] = pers.priorToConnect
        if pers.type == 'PERSIST_SOURCE_IP':
            sourceipDict = {}
            if pers.maskv4 is not None:
                sourceipDict['mask_v4'] = pers.maskv4
            if pers.maskv6 is not None:
                sourceipDict['mask_v6'] = pers.maskv6
            if pers.sourceipTimeout != -1:
                sourceipDict['timeout'] = pers.sourceipTimeout
            persDict['source_ip'] = sourceipDict
        elif pers.type == 'PERSIST_COOKIE':
            cookie = {}
            if pers.cookieName is not None:
                cookie['cookie_name'] = pers.cookieName
            if pers.cookieType is not None:
                cookie['cookie_type'] = pers.cookieType
            if pers.cookieDomain is not None:
                cookie['cookie_domain'] = pers.cookieDomain
            if pers.cookiePath is not None:
                cookie['cookie_path'] = pers.cookiePath
            if pers.cookieTimeout != -1:
                cookie['cookie_timeout'] = pers.cookieTimeout
            persDict['cookie'] = cookie
        return persDict

    @classmethod
    def generatingPersistList(cls, httpBody):
        return PersistList(httpBody)

    @classmethod
    def generatingPersistInfo(cls, httpBody):
        return PersistInfo(httpBody)


class PersistList(ParentList):
    '''
    从xml中获取节点列表
    '''
    def __init__(self, httpBody=None):
        ParentList.__init__(self, httpBody)
        if httpBody is None or httpBody == "":
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('PersistInfoListType'):
                if self.jsonObj['PersistInfoListType'] is None:
                    return
                persList = self.jsonObj['PersistInfoListType']
                if 'persist_info' in persList:
                    if isinstance(persList['persist_info'], list):
                        for pers in persList['persist_info']:
                            item = PersistInfo(json.dumps(pers,
                                ensure_ascii=False))
                            self.elements.append(item)
                    else:
                        pers = persList['persist_info']
                        item = PersistInfo(json.dumps(pers, ensure_ascii=False))
                        self.elements.append(item)
        except jsono.JSONObjException as e:
            raise APIException(3, e.reason)
