# -*- coding: utf-8 -*-
# Copyright (c) 2008-2020, AD SANGFOR
# Filename: ResInfo.py
# 定义MAD资源信息
from Configuration import Configuration
from APIException import APIException
from ErrorInfo import ErrInfo
from http.HttpClient import HttpClient
from ParentList import ParentList
from urllib2 import base64
import JSONObj as jsono
import urllib
import json
import codecs


class ResInfo(ErrInfo):
    def __init__(self, httpBody=None):
        ErrInfo.__init__(self, httpBody)
        self.coreNum = []
        self.cpuCore = 0              # 逻辑CPU个数
        self.cpuNum = 0               # 物理CPU个数
        self.mem = 0                  # 物理内存总量，单位：M
        self.validMem = 0             # 可用内存，单位：M
        self.validCoreNum = 0         # 可用逻辑CPU个数
        self.snVadNum = 0             # 授权vAD个数
        self.newMemVadEnable = True   # 新建vAD是否有足够内存
        self.newCoreVadEnable = True  # 新建vAD是否有足够逻辑CPU
        self.newSnVadEnable = True    # 是否可以新建vAD
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('core_num'):
                self.coreNum = self.jsonObj['core_num'].split(',')
            if self.jsonObj.hasTag('cpu_core'):
                self.cpuCore = self.jsonObj['cpu_core']
            if self.jsonObj.hasTag('cpu_num'):
                self.cpuNum = self.jsonObj['cpu_num']
            if self.jsonObj.hasTag('mem_num'):
                self.mem = self.jsonObj['mem_num']
            if self.jsonObj.hasTag('valid_mem_num'):
                self.validMem = self.jsonObj['valid_mem_num']
            if self.jsonObj.hasTag('valid_core_num'):
                self.validCoreNum = self.jsonObj['valid_core_num']
            if self.jsonObj.hasTag('sn_vad_num'):
                self.snVadNum = self.jsonObj['sn_vad_num']
            if self.jsonObj.hasTag('new_mem_vad_enable'):
                self.newMemVadEnable = self.jsonObj['new_mem_vad_enable']
            if self.jsonObj.hasTag('new_core_vad_enable'):
                self.newCoreVadEnable = self.jsonObj['new_core_vad_enable']
            if self.jsonObj.hasTag('new_sn_vad_enable'):
                self.newSnVadEnable = self.jsonObj['new_sn_vad_enable']
        except jsono.JSONObjException, e:
            raise APIException(3, e.reason)

    @classmethod
    def generatingResInfo(cls, httpBody):
        return ResInfo(httpBody)
