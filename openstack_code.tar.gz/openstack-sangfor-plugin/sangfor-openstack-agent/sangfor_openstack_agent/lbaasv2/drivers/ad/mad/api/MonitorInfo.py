# -*- coding: utf-8 -*-
# Copyright (c) 2008-2020, AD SANGFOR
# Filename: MonitorInfo.py
# 定义监视器配置信息
from APIException import APIException
from ErrorInfo import ErrInfo
from ParentList import ParentList
from urllib2 import base64
import JSONObj as jsono
import urllib
import json
import codecs


class MonitorInfo (ErrInfo):
    def __init__(self, httpBody=None):
        ErrInfo.__init__(self, httpBody)
        self.name = None
        self.type = None
        self.interval = -1
        self.timeout = -1
        self.tryout = -1
        self.addr = None
        self.port = -1
        self.debug = None
        self.maxRecvBuf = -1
        self.sendMsg = None
        self.recvInclude = None
        self.closeSendMsg = None
        self.respCode = []
        self.urlMsg = None
        self.hex = None
        self.isFirewall = None
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
                httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('name'):
                self.name = urllib.unquote(
                    base64.b64decode(self.jsonObj['name']))
            if self.jsonObj.hasTag('type'):
                self.type = self.jsonObj['type']
            if self.jsonObj.hasTag('NodeMonitorInfoType'):
                monitorInfo = self.jsonObj['NodeMonitorInfoType']
                if 'monitor_name' in monitorInfo:
                    self.name = urllib.unquote(
                        base64.b64decode(monitorInfo['monitor_name']))
                if 'base_info' in monitorInfo:
                    baseInfo = monitorInfo['base_info']
                    if 'type' in baseInfo:
                        self.type = baseInfo['type']
                    if 'interval' in baseInfo:
                        self.interval = int(baseInfo['interval'])
                    if 'timeout' in baseInfo:
                        self.timeout = int(baseInfo['timeout'])
                    if 'tryout' in baseInfo:
                        self.tryout = int(baseInfo['tryout'])
                    if 'addr' in baseInfo:
                        self.addr = baseInfo['addr']
                    if 'debug' in baseInfo:
                        self.debug = baseInfo['debug']
                    if 'port' in baseInfo:
                        self.port = int(baseInfo['port'])
                if 'icmp_ext' in monitorInfo:
                    icmpExt = monitorInfo['icmp_ext']
                    if 'is_firewall' in icmpExt:
                        self.isFirewall = icmpExt['is_firewall']
                if 'connect_ext' in monitorInfo:
                    ext = monitorInfo['connect_ext']
                    if 'recv_buf_max' in ext:
                        self.maxRecvBuf = int(ext['recv_buf_max'])
                    if 'send_msg' in ext:
                        self.sendMsg = urllib.unquote(ext['send_msg'])
                    if 'recv_include' in ext:
                        self.recvInclude = urllib.unquote(ext['recv_include'])
                    if 'close_send_msg' in ext:
                        self.closeSendMsg = urllib.unquote(
                            ext['close_send_msg'])
                    if 'resp_code' in ext:
                        self.respCode = ext['resp_code'].split(';')
                    if 'url_msg' in ext:
                        self.urlMsg = ext['url_msg']
                    if 'hex' in ext:
                        self.hex = ext['hex']
        except jsono.JSONObjException as e:
            raise APIException(3, e.reason)

    @classmethod
    def extToDict(cls, monitor):
        extDict = {}
        if monitor.maxRecvBuf != -1:
            extDict['recv_buf_max'] = monitor.maxRecvBuf
        if monitor.sendMsg is not None:
            extDict['send_msg'] = monitor.sendMsg
        if monitor.recvInclude is not None:
            extDict['recv_include'] = monitor.recvInclude
        if monitor.closeSendMsg is not None:
            extDict['close_send_msg'] = monitor.closeSendMsg
        if len(monitor.respCode) != 0:
            extDict['resp_code'] = ';'.join(monitor.respCode)
        if monitor.urlMsg is not None:
            extDict['url_msg'] = monitor.urlMsg
        if monitor.hex is not None:
            extDict['hex'] = monitor.hex
        return extDict

    @classmethod
    def monitorInfoToDict(cls, monitor):
        monitorDict = {}
        if monitor.name is not None:
            monitorDict['name'] = monitor.name
        if monitor.type is not None:
            monitorDict['type'] = monitor.type
        if monitor.interval != -1:
            monitorDict['interval'] = monitor.interval
        if monitor.timeout != -1:
            monitorDict['timeout'] = monitor.timeout
        if monitor.tryout != -1:
            monitorDict['tryout'] = monitor.tryout
        if monitor.addr is not None:
            monitorDict['addr'] = monitor.addr
        if monitor.port != -1:
            monitorDict['port'] = monitor.port
        if monitor.debug is not None:
            monitorDict['debug'] = monitor.debug
        if monitor.isFirewall is not None:
            monitorDict['is_firewall'] = monitor.isFirewall
        extDict = MonitorInfo.extToDict(monitor)
        if extDict:
            monitorDict['connect_ext'] = extDict
        return monitorDict

    @classmethod
    def generatingMonitorList(cls, httpBody):
        return MonitorList(httpBody)

    @classmethod
    def generatingMonitorInfo(cls, httpBody):
        return MonitorInfo(httpBody)


class MonitorList (ParentList):
    def __init__(self, httpBody=None):
        ParentList.__init__(self, httpBody)
        if httpBody is None or httpBody == "":
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('NodeMonitorInfoListType'):
                if self.jsonObj['NodeMonitorInfoListType'] is None:
                    return
                monitorList = self.jsonObj['NodeMonitorInfoListType']
                if 'monitor_info' in monitorList:
                    monitorInfo = monitorList['monitor_info']
                    if isinstance(monitorInfo, list):
                        for monitor in monitorInfo:
                            item = MonitorInfo(json.dumps(monitor,
                                ensure_ascii=False))
                            self.elements.append(item)
                    else:
                        item = MonitorInfo(json.dumps(monitorInfo,
                            ensure_ascii=False))
                        self.elements.append(item)
        except jsono.JSONObjException as e:
            raise APIException(3, e.reason)
