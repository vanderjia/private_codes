# -*- coding: utf-8 -*-
# Copyright (c) 2008-2020, AD SANGFOR
# Filename: NetifInfo.py
# 定义网络接口信息
from Configuration import Configuration
from APIException import APIException
from ErrorInfo import ErrInfo
from http.HttpClient import HttpClient
from ParentList import ParentList
from urllib2 import base64
import JSONObj as jsono
import urllib
import json
import codecs


class IfnameInfo(ErrInfo):
    def __init__(self, httpBody=None):
        ErrInfo.__init__(self, httpBody)
        self.device = None    # 物理网口
        self.name = None      # 页面网口名称
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('device'):
                self.device = self.jsonObj['device']
            if self.jsonObj.hasTag('name'):
                self.name = self.jsonObj['name']
        except jsono.JSONObjException, e:
            raise APIException(3, e.reason)


class NetifInfo(ParentList):
    '''
    网络接口信息
    '''
    def __init__(self, httpBody=None):
        ParentList.__init__(self, httpBody)
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if not self.jsonObj.hasTag('data'):
                return
            for item in self.jsonObj['data']:
                netif = IfnameInfo(json.dumps(item, ensure_ascii=False))
                self.elements.append(netif)
        except jsono.JSONObjException, e:
            raise APIException(3, e.reason)

    @classmethod
    def generatingNetifInfo(cls, httpBody):
        return NetifInfo(httpBody)
