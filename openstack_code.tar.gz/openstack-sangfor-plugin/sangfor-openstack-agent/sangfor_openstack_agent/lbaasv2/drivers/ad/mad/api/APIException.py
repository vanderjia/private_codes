# -*- coding: utf-8 -*-
# Copyright (c) 2008-2016, AD SANGFOR, [Version 6.3.0]
# Filename: APIException.py

from http.HttpClient import HttpClientException
from JSONObj import JSONObjException


# ADAPI PYTHON SDK 异常
class APIException(StandardError):
    '''
    ADAPI PYTHON SDK 异常
    封装了ADAPI PYTHON SDK可能抛出的所有异常
    1. code 1; reason time out
    2. code 2; reason http error
    3. code 3; reason can't parse json data
    4. code 4; reason unknown error
    '''
    def __init__(self, code=None, reason=None):
        '''
        初始化函数
        1. code 1; reason time out
        2. code 2; reason http error
        3. code 3; reason can't parse json data
        4. code 4; reason unknown error
        @param  reason 出错信息
        @type   str
        @param  code 错误码
        @type   int
        '''
        StandardError.__init__(self, reason)
        if isinstance(reason, unicode):
            reason = reason.encode("utf8")
        self.code = code
        self.reason = reason

    def __str__(self):
        '''
        转化为字符串的函数
        '''
        return 'APIException : %s; %s' % (str(self.code), self.reason)

    @classmethod
    def codeTransfer(cls, e):
        if isinstance(e, HttpClientException):
            if e.code == 1:
                return 1
            elif e.code == 3:
                return 3
            elif e.code == 4:
                return 4
            else:  # 500
                return 2
        elif isinstance(e, JSONObjException):
            return 3
        elif isinstance(e, APIException):
            return e.code
        else:
            return 4
