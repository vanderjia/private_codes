# -*- coding: utf-8 -*-
# Copyright (c) 2008-2016, AD SANGFOR, [Version 6.3.0]
# Filename: HttpClient.py

import os
import sys
sys.path.append(os.path.abspath(os.path.dirname(__file__) + '/' + '..'))
from LogInfo import LogInfo
from urllib2 import URLError, base64
from httplib import InvalidURL
import json
import urllib
import urllib2
import socket


# 用于封装HTTP请求的参数
# 返回xxx=xxx&xx=xx的字符串，并进行url编码
class HttpClientException (StandardError):
    '''
    '''
    def __init__(self, code, reason):
        '''
        1. timeout; code: 1; reason: time out
        2. http error; code: http status code; reason: http error reason
        3. unknown error; code:3; reaon: unknown error
        @param  reason 出错信息
        @type   str
        @param  code 错误码
        @type   int
        '''
        StandardError.__init__(self, reason)
        self.code = code
        self.reason = reason

    def __str__(self):
        '''
        '''
        return ('HttpClientException: %s; %s' %
            (str(self.code), str(self.reason)))


def encodeParams(params):
    '''
    处理请求参数。会进行url编码。
    @param params http请求的参数
    @type params dict
    @return 类似"xxx=xxx&xx=xx"格式的字符串。此字符串已经进行url编码
    @rtype string
    '''
    if len(params) == 0:
        return ""
    args = []
    for k, v in params.iteritems():
        qv = None
        if isinstance(v, unicode):
            qv = v.encode("utf8")
        else:
            qv = str(v)
        args.append('%s=%s' % (urllib.quote_plus(k), urllib.quote_plus(qv)))
    return "&".join(args)


class RequestMethod:
    GET = "GET"
    POST = "POST"

    def __init__(self):
        None

    @classmethod
    def check(cls, checkValue):
        if (checkValue != RequestMethod.GET and
            checkValue != RequestMethod.POST):
            return False
        return True

    @classmethod
    def get(cls):
        return RequestMethod.GET

    @classmethod
    def post(cls):
        return RequestMethod.POST


class HttpClient:
    '''
    '''
    def __init__(self):
        None

    @classmethod
    def urlEncode(cls, sour):
        if not isinstance(sour, str):
            return None
        return urllib.quote(sour)

    @classmethod
    def urlDecode(cls, sour):
        if not isinstance(sour, str):
            return None
        return urllib.unquote(sour)

    @classmethod
    def setTimeout(cls, timeout):
        socket.setdefaulttimeout(timeout)

    @classmethod
    def setSangforAuth(cls, request, config):
        '''
        在HTTP Header中插入身份认证信息
        Sangfor-Auth: xxxx
        '''
        authInfo = {
            'username': config.username,
            'passwd': config.password
        }
        authStr = urllib.quote_plus(
            base64.b64encode(
                json.dumps(authInfo, ensure_ascii=False)))
        request.add_header('Sangfor-Auth', authStr)

    @classmethod
    def httpClient(
        cls,
        uri,
        params,
        config,
        requestMethod=RequestMethod.GET):
        '''
        restFul发送https请求
        @param requestMethod 请求的类型 GET或POST
        @type requestMethod RequestMethod
        @param uri 请求的URI
        @type uri string
        @param params http请求的参数
        @type params dict
        @return 请求得到的数据
        @rtype string
        '''
        # 处理请求地址
        port = str(config.port)
        if port != "0" and port != "None":
            uri = config.ip + ":" + port + uri
        else:
            uri = config.ip + uri
        uri = "https://" + uri
        strParams = params
        if params is not None and len(params) != 0:
            if requestMethod.lower() == "POST".lower():
                strParams = encodeParams(params)
        httpBody = None
        if requestMethod.lower() == "GET".lower():
            if strParams != "" and strParams is not None:
                uri += "?" + strParams
        else:
            httpBody = strParams
        # 发送请求
        LogInfo.makeLogger("uri: " + str(uri))
        LogInfo.makeLogger("body: " + str(httpBody))
        request = urllib2.Request(uri, data=httpBody)
        body = ""
        try:
            # 插入身份认证信息
            HttpClient.setSangforAuth(request, config)
            resp = urllib2.urlopen(request)
            body = str(resp.read())
        except urllib2.HTTPError as e:
            raise HttpClientException(e.code, str(e.read()))
        except URLError as e:
            raise HttpClientException(1, str(e.reason))
        except InvalidURL as e:
            if len(e.args) >= 1:
                errStr = e.args[0]
            raise HttpClientException(1, str(errStr))
        except:
            raise HttpClientException(3, "unknow reason")
        # 转换为unicode编码
        if not isinstance(body, unicode):
            body = unicode(body, "utf8")
        return body
