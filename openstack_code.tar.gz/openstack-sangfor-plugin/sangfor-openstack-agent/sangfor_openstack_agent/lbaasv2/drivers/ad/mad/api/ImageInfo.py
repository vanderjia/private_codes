# -*- coding: utf-8 -*-
# Copyright (c) 2008-2020, AD SANGFOR
# Filename: ImageInfo.py
# 定义Image信息
from Configuration import Configuration
from APIException import APIException
from ErrorInfo import ErrInfo
from http.HttpClient import HttpClient
from ParentList import ParentList
from urllib2 import base64
import JSONObj as jsono
import urllib
import json
import codecs


class ImageStatus:
    IMAGE_UPLOAD  = 0  # image正在解压
    IMAGE_UPDATE  = 1  # image正在升级
    IMAGE_DISABLE = 2  # image不可用
    IMAGE_ENABLE  = 3  # image可用
    IMAGE_REMOVE  = 4  # image正在删除

    def __init__(self):
        None

    @classmethod
    def check(cls, status):
        if (status != ImageStatus.IMAGE_UPLOAD and
            status != ImageStatus.IMAGE_UPDATE and
            status != ImageStatus.IMAGE_DISABLE and
            status != ImageStatus.IMAGE_ENABLE and
            status != ImageStatus.IMAGE_REMOVE):
            return False
        return True


class ImageInfo(ErrInfo):
    def __init__(self, httpBody=None):
        ErrInfo.__init__(self, httpBody)
        self.id = 0            # 配置id
        self.uuid = None       # uuid
        self.version = None    # 版本
        self.status = None     # image状态
        self.imageDesc = None  # 描述
        self.updateList = []   # 允许升级的版本
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('id'):
                self.id = int(self.jsonObj['id'])
            if self.jsonObj.hasTag('uuid'):
                self.uuid = self.jsonObj['uuid']
            if self.jsonObj.hasTag('version'):
                self.version = self.jsonObj['version']
            if self.jsonObj.hasTag('status'):
                self.status = int(self.jsonObj['status'])
            if self.jsonObj.hasTag('description'):
                self.imageDesc = self.jsonObj['description']
            if self.jsonObj.hasTag('updatelist'):
                self.updateList = self.jsonObj['updatelist'].split(',')
        except jsono.JSONObjException, e:
            raise APIException(3, e.reason)

    @classmethod
    def generatingImageInfoList(cls, httpBody):
        return ImageInfoList(httpBody)


class ImageInfoList(ParentList):
    def __init__(self, httpBody=None):
        ParentList.__init__(self, httpBody)
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if not self.jsonObj.hasTag('data'):
                return
            for item in self.jsonObj['data']:
                image = ImageInfo(json.dumps(item, ensure_ascii=False))
                self.elements.append(image)
        except jsono.JSONObjException, e:
            raise APIException(3, e.reason)
