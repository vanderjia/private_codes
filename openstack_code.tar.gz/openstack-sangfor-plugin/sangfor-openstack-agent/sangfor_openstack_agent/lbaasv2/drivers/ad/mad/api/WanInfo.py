﻿# -*- coding: utf-8 -*-
# Copyright (c) 2008-2020, AD SANGFOR
# Filename: WanInfo.py
# 定义wan口网络配置信息
from APIException import APIException
from ErrorInfo import ErrInfo
from ParentList import ParentList
from AddrElement import AddrElement
from urllib2 import base64
import JSONObj as jsono
import urllib
import json
import codecs


class WanInfo(ErrInfo):
    def __init__(self, httpBody=None):
        ErrInfo.__init__(self, httpBody)
        self.name = None
        self.enable = None
        self.ifname = None
        self.ip = []                  # ip地址列表, AddrElement类型([{'info': ip/mask, 'info_id': id}])
        self.gwAddr = []              # ipv4网关, AddrElement类型(非集群时，只用一个网关)
                                      # 当集群时，ipv4/ipv6网关同时存在gw_addr_map中
        self.gwAddrv6 = None          # ipv6网关, AddrElement类型
        self.maxUpBandwidth = -1      # 上行带宽，单位：Kbps
        self.maxDownBandwidth = -1    # 下行带宽，单位：Kbps
        self.upBusyRate = -1          # 上行繁忙比，单位：%
        self.downBusyRate = -1        # 下行繁忙比，单位：%
        self.inetAddr = []            # 网口ip对应的互联网ip, AddrElement类型
        self.enableDetect = None      # 健康监测开关    'true'/'false'
        self.arpDetect = None         # 网关arp监测开关
        self.monitor = []             # 监视器(ping/ping6/http)
        self.detectHost = []          # 监视主机列表
        self.enableNicCheck = None    # 网线插拔检测开关
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
                httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('wan_name'):
                self.name = urllib.unquote(
                    base64.b64decode(self.jsonObj['wan_name']))
            if self.jsonObj.hasTag('ifname'):
                netif = self.jsonObj['ifname']
                if 'ifname' in netif:
                    self.ifname = urllib.unquote(
                        base64.b64decode(netif['ifname']))
                if 'enable' in netif:
                    self.enable = netif['enable']
            if self.jsonObj.hasTag('WanIpListType'):
                ipList = self.jsonObj['WanIpListType']
                if 'ip_addr' in ipList:
                    ipInfo = ipList['ip_addr']
                    if isinstance(ipInfo, list):
                        for ip in ipInfo:
                            self.ip.append(AddrElement(ip, 1, AddrElement.ADDR_ONE))
                    else:
                        self.ip.append(AddrElement(ipInfo, 1, AddrElement.ADDR_ONE))
        except jsono.JSONObjException as e:
            raise APIException(3, e.reason)

    @classmethod
    def netifToDict(cls, wanInfo):
        netifDict = {}
        if wanInfo.ifname is not None:
            netifDict['ifname'] = wanInfo.ifname
        if wanInfo.enable is not None:
            netifDict['enable'] = wanInfo.enable
        if len(wanInfo.ip) != 0:
            netifDict['ip_addr'] = []
            for addr in wanInfo.ip:
                item = {}
                item['info'] = addr.ip
                item['info_id'] = addr.info_id
                netifDict['ip_addr'].append(item)
        if len(wanInfo.gwAddr) != 0:
            netifDict['gw_addr'] = []
            for addr in wanInfo.gwAddr:
                item = {}
                item['info'] = addr.ip
                item['info_id'] = addr.info_id
                netifDict['gw_addr'].append(item)
        if wanInfo.gwAddrv6 is not None:
            item = {}
            item['info'] = wanInfo.gwAddrv6.ip
            item['info_id'] = wanInfo.gwAddrv6.info_id
            netifDict['gw_addr_v6'] = item
        if wanInfo.maxUpBandwidth != -1:
            netifDict['max_up_bandwidth'] = wanInfo.maxUpBandwidth
        if wanInfo.maxDownBandwidth != -1:
            netifDict['max_down_bandwidth'] = wanInfo.maxDownBandwidth
        if wanInfo.upBusyRate != -1:
            netifDict['up_busy_rate'] = wanInfo.upBusyRate
        if wanInfo.downBusyRate != -1:
            netifDict['down_busy_rate'] = wanInfo.downBusyRate
        return netifDict

    @classmethod
    def wanInfoToDict(cls, wanInfo):
        wanDict = {}
        if wanInfo is not None:
            if wanInfo.name is not None:
                wanDict['name'] = wanInfo.name
            if len(wanInfo.inetAddr) != 0:
                wanDict['inet_addr'] = []
                for addr in wanInfo.inetAddr:
                    item = {}
                    item['info'] = addr.ip
                    item['info_id'] = addr.info_id
                    wanDict['inet_addr'].append(item)
            if wanInfo.enableDetect is not None:
                wanDict['enable_detect'] = wanInfo.enableDetect
            if wanInfo.enableDetect is 'true':
                if wanInfo.arpDetect is not None:
                    wanDict['arp_detect'] = wanInfo.arpDetect
                if len(wanInfo.monitor) != 0:
                    wanDict['monitor'] = []
                    for item in wanInfo.monitor:
                        wanDict['monitor'].append(item)
                if len(wanInfo.detectHost) != 0:
                    wanDict['detect_host'] = []
                    for host in wanInfo.detectHost:
                        wanDict['detect_host'].append(host)
            if wanInfo.enableNicCheck is not None:
                wanDict['enable_nic_check'] = wanInfo.enableNicCheck
            netif = WanInfo.netifToDict(wanInfo)
            if netif:
                wanDict['netif'] = netif
        return wanDict

    @classmethod
    def generatingWanList(cls, httpBody):
        return WanList(httpBody)

    @classmethod
    def generatingWanInfo(cls, httpBody):
        return WanInfo(httpBody)


class WanList(ParentList):
    def __init__(self, httpBody=None):
        ParentList.__init__(self, httpBody)
        if httpBody is None or httpBody is "":
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('WanInfoListType'):
                if self.jsonObj['WanInfoListType'] is None:
                    return
                wanList = self.jsonObj['WanInfoListType']
                if 'wan_info' in wanList:
                    wanInfo = wanList['wan_info']
                    if isinstance(wanInfo, list):
                        for wan in wanInfo:
                            item = WanInfo(json.dumps(wan,
                                ensure_ascii=False))
                            self.elements.append(item)
                    else:
                        item = WanInfo(json.dumps(wanInfo,
                            ensure_ascii=False))
                        self.elements.append(item)
        except jsono.JSONObjException as e:
            raise APIException(3, e.reason)
