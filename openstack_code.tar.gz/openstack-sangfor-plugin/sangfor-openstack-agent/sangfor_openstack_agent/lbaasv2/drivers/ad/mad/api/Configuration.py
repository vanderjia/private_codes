# -*- coding: utf-8 -*-
# Copyright (c) 2008-2020, AD SANGFOR
# Filename: Configuration.py
# 用于管理连接AD的配置，包括AD的IP、AD的端口、登入AD所需的用户名和密码
# 会先对用户名/密码进行base64编码
import hashlib
from urllib2 import base64
from http.HttpClient import HttpClient

__version__ = '2.0.0'
__author__ = 'ad.sangfor.com'


class Configuration:
    '''
    用于管理连接AD的配置，包括AD的IP、AD的端口、登入AD所需的用户名、密码和超时时间

    @var self.m_ip AD 的 IP
    @type self.m_ip string
    @var self.m_port AD 的端口
    @type self.m_port int
    @var self.m_username 登入AD的用户名
    @type self.m_username string
    @var self.m_password 登入用户的密码
    @type self.m_password string
    '''

    def __init__(self, username, password, ip, port=443, timeout=20):
        self.init(username, password, ip, port, timeout)
        # openstack测试
        self.madapiURI = "/mapi/madapi.cgi/test"
        # 获取MAD配置信息
        self.getMadResInfoURI = "/mapi/madapi.cgi/madres"
        # 获取镜像信息
        self.getImageListURI = "/mapi/madapi.cgi/image/list"
        # 创建vlan
        self.createVlanURI = "/mapi/madapi.cgi/createVlan"
        # 更新vlan
        self.updateVlanURI = "/mapi/madapi.cgi/updateVlan"
        # 删除vlan
        self.deleteVlanURI = "/mapi/madapi.cgi/deleteVlan"
        # 获取vlan
        self.getVlanURI = "/mapi/madapi.cgi/vlan"
        # 获取vlan列表
        self.getVlanListURI = "/mapi/madapi.cgi/vlan/list"
        # 获取vlan可以引用哪些网口
        self.listNetVlanURI = "/mapi/madapi.cgi/vlan/net"
        # 创建bond
        self.createBondURI = "/mapi/madapi.cgi/createBond"
        # 更新bond
        self.updateBondURI = "/mapi/madapi.cgi/updateBond"
        # 删除bond
        self.deleteBondURI = "/mapi/madapi.cgi/deleteBond"
        # 获取bond
        self.getBondURI = "/mapi/madapi.cgi/bond"
        # 获取bond列表
        self.getBondListURI = "/mapi/madapi.cgi/bond/list"
        # 获取bond可以引用哪些网口
        self.listNetBondURI = "/mapi/madapi.cgi/bond/net"
        # 创建switch
        self.createSwitchURI = "/mapi/madapi.cgi/createSwitch"
        # 更新switch
        self.updateSwitchURI = "/mapi/madapi.cgi/updateSwitch"
        # 删除switch
        self.deleteSwitchURI = "/mapi/madapi.cgi/deleteSwitch"
        # 获取switch
        self.getSwitchURI = "/mapi/madapi.cgi/switch"
        # 获取switch列表
        self.getSwitchListURI = "/mapi/madapi.cgi/switch/list"
        # 获取switch可以引用哪些网口
        self.listNetSwitchURI = "/mapi/madapi.cgi/switch/net"
        # 创建vxlan
        self.createVxlanURI = "/mapi/madapi.cgi/createVxlan"
        # 更新vxlan
        self.updateVxlanURI = "/mapi/madapi.cgi/updateVxlan"
        # 删除vxlan
        self.deleteVxlanURI = "/mapi/madapi.cgi/deleteVxlan"
        # 获取vxlan
        self.getVxlanURI = "/mapi/madapi.cgi/vxlan"
        # 获取vxlan列表
        self.getVxlanListURI = "/mapi/madapi.cgi/vxlan/list"
        # 获取vxlan可以引用哪些网口
        self.listNetVxlanURI = "/mapi/madapi.cgi/vxlan/net"
        # 创建静态路由
        self.createSrouteURI = "/mapi/madapi.cgi/createSroute"
        # 更新静态路由
        self.updateSrouteURI = "/mapi/madapi.cgi/updateSroute"
        # 删除静态路由
        self.deleteSrouteURI = "/mapi/madapi.cgi/deleteSroute"
        # 获取静态路由列表
        self.getSrouteListURI = "/mapi/madapi.cgi/sroute/list"
        # 创建接口IP
        self.createNetifIPURI = "/mapi/madapi.cgi/createNetIP"
        # 更新接口IP
        self.updateNetifIPURI = "/mapi/madapi.cgi/updateNetIP"
        # 删除接口IP
        self.deleteNetifIPURI = "/mapi/madapi.cgi/deleteNetIP"
        # 获取接口IP列表
        self.getNetifIPListURI = "/mapi/madapi.cgi/ip/list"
        # 获取接口IP可以引用哪些网口
        self.listNetNetifIPURI = "/mapi/madapi.cgi/ip/net"
        # 创建vad
        self.createVadURI = "/mapi/madapi.cgi/createVad"
        # 更新vad
        self.updateVadURI = "/mapi/madapi.cgi/updateVad"
        # 删除vad
        self.deleteVadURI = "/mapi/madapi.cgi/deleteVad"
        # 启动vad
        self.startVadURI = "/mapi/madapi.cgi/startVad"
        # 关闭vad
        self.stopVadURI = "/mapi/madapi.cgi/stopVad"
        # 强制关闭vad
        self.closeVadURI = "/mapi/madapi.cgi/closeVad"
        # 重启vad
        self.restartVadURI = "/mapi/madapi.cgi/restartVad"
        # 获取vad信息
        self.getVadURI = "/mapi/madapi.cgi/vad"
        # 获取vad列表
        self.getVadListURI = "/mapi/madapi.cgi/vad/list"
        # 获取vad可以引用哪些网口
        self.listNetVadURI = "/mapi/madapi.cgi/vad/net"
        # vad代理
        self.vadProxyURI = "/mapi/madapi.cgi/vadproxy"

    def init(self, username, password, ip, port, timeout=20):
        '''
        初始化ADAPI SDK所需的信息。对于用户名密码会进行base64编码。
        @param ip 登入AD的IP
        @type ip string
        @param port 登入AD的端口 默认为443
        @type port int
        @param username 登入AD的用户名
        @type username string
        @param password 登入AD的密码
        @type password string
        @params timeout 设置超时时间
        @type timeout int
        @return    无
        @rtype    无
        '''
        self.ip = ip
        self.port = port
        self.username = username
        self.password = Configuration.MD5(password)
        self.timeout = timeout
        if self.timeout is not None:
            HttpClient.setTimeout(self.timeout)

    @classmethod
    def getVersion(cls):
        '''
        获取MADAPI的版本信息
        '''
        import __init__
        return __init__.__version__

    @classmethod
    def MD5(cls, src):
        m = hashlib.md5()
        m.update(src)
        return m.hexdigest()

    @classmethod
    def base64encode(cls, src):
        if src is None:
            return None
        return base64.b64encode(src)

    @classmethod
    def base64decode(cls, src):
        if src is None:
            return None
        return base64.b64decode(src)
