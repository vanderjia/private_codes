# -*- coding: utf-8 -*-
# Copyright (c) 2008-2020, AD SANGFOR
# Filename: NodeInfo.py
# 定义节点配置信息
from APIException import APIException
from ErrorInfo import ErrInfo
from ParentList import ParentList
from urllib2 import base64
import JSONObj as jsono
import urllib
import json
import codecs


class ConfStatus:
    NODE_ENABLE = "NODE_ENABLE"
    NODE_DISABLE = "NODE_DISABLE"
    NODE_OFFLINE = "NODE_OFFLINE"

    def __init__(self):
        None

    @classmethod
    def check(cls, checkValue):
        if (checkValue != ConfStatus.NODE_ENABLE and
            checkValue != ConfStatus.NODE_DISABLE and
            checkValue != ConfStatus.NODE_OFFLINE):
            return False
        return True


class HealthStatus:
    NODE_NORMAL = "NODE_NORMAL"
    NODE_BUSY = "NODE_BUSY"
    NODE_FAIL = "NODE_FAIL"
    NODE_UNAVAILABLE = "NODE_UNAVAILABLE"
    NODE_DISABLE = "NODE_DISABLE"

    def __init__(self):
        None

    @classmethod
    def check(cls, checkValue):
        if (checkValue != HealthStatus.NODE_NORMAL and
            checkValue != HealthStatus.NODE_BUSY and
            checkValue != HealthStatus.NODE_FAIL and
            checkValue != HealthStatus.NODE_UNAVAILABLE and
            checkValue != HealthStatus.NODE_DISABLE):
            return False
        return True


class NodeInfo(ErrInfo):
    def __init__(self, httpBody=None):
        ErrInfo.__init__(self, httpBody)
        self.poolName = None
        self.nodeIP = None
        self.nodePort = -1
        self.ratio = -1
        self.maxConnects = -1
        self.newConnects = -1
        self.maxRequest = -1
        self.rsVal1 = None
        self.confStatus = None
        self.healStatus = None
        self.connection = -1
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
                httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('status'):
                self.confStatus = self.jsonObj['status']
            if self.jsonObj.hasTag('ratio'):
                self.ratio = int(self.jsonObj['ratio'])
            if self.jsonObj.hasTag('max_connects'):
                self.maxConnects = int(self.jsonObj['max_connects'])
            if self.jsonObj.hasTag('new_connects'):
                self.newConnects = int(self.jsonObj['new_connects'])
            if self.jsonObj.hasTag('max_request'):
                self.maxRequest = int(self.jsonObj['max_request'])
            if self.jsonObj.hasTag('addr'):
                self.nodeIP = self.jsonObj['addr']
            if self.jsonObj.hasTag('port'):
                self.nodePort = int(self.jsonObj['port'])
            if self.jsonObj.hasTag('conf_status'):
                self.confStatus = self.jsonObj['conf_status']
            if self.jsonObj.hasTag('current_status'):
                self.healStatus = self.jsonObj['current_status']
            if self.jsonObj.hasTag('connection'):
                self.connection = int(self.jsonObj['connection'])
            if self.jsonObj.hasTag('rs_val1'):
                self.rsVal1 = urllib.unquote(
                    base64.b64decode(self.jsonObj['rs_val1']))
            if self.jsonObj.hasTag('NodeInfoType'):
                nodeInfo = self.jsonObj['NodeInfoType']
                if 'status' in nodeInfo:
                    self.confStatus = nodeInfo['status']
                if 'ratio' in nodeInfo:
                    self.ratio = int(nodeInfo['ratio'])
                if 'max_connects' in nodeInfo:
                    self.maxConnects = int(nodeInfo['max_connects'])
                if 'new_connects' in nodeInfo:
                    self.newConnects = int(nodeInfo['new_connects'])
                if 'max_request' in nodeInfo:
                    self.maxRequest = int(nodeInfo['max_request'])
                if 'addr' in nodeInfo:
                    self.nodeIP = nodeInfo['addr']
                if 'port' in nodeInfo:
                    self.nodePort = int(nodeInfo['port'])
                if 'rs_val1' in nodeInfo:
                    self.rsVal1 = urllib.unquote(
                        base64.b64decode(nodeInfo['rs_val1']))
        except jsono.JSONObjException as e:
            raise APIException(3, e.reason)

    @classmethod
    def nodeInfoToDict(cls, node):
        nodeDict = {}
        if node.confStatus is not None:
            nodeDict['status'] = node.confStatus
        if node.ratio != -1:
            nodeDict['ratio'] = node.ratio
        if node.maxConnects != -1:
            nodeDict['max_connects'] = node.maxConnects
        if node.newConnects != -1:
            nodeDict['new_connects'] = node.newConnects
        if node.maxRequest != -1:
            nodeDict['max_request'] = node.maxRequest
        if node.nodeIP is not None:
            nodeDict['ip'] = node.nodeIP
        if node.nodePort != -1:
            nodeDict['port'] = node.nodePort
        if node.rsVal1 is not None:
            nodeDict['rs_val1'] = node.rsVal1
        return nodeDict

    @classmethod
    def generatingNodeList(cls, httpBody):
        return NodeList(httpBody)

    @classmethod
    def generatingNodeInfo(cls, httpBody):
        return NodeInfo(httpBody)

    @classmethod
    def generatingNodeStatus(cls, httpBody):
        return NodeList(httpBody)


class NodeList(ParentList):
    def __init__(self, httpBody=None):
        ParentList.__init__(self, httpBody)
        self.poolName = None
        if httpBody is None or httpBody == "":
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('NodeListType'):
                if self.jsonObj['NodeListType'] is None:
                    return
                nodeList = self.jsonObj['NodeListType']
                if '@name' in nodeList:
                    self.poolName = urllib.unquote(
                        base64.b64decode(nodeList['@name']))
                if 'node' in nodeList:
                    nodeInfo = nodeList['node']
                    if isinstance(nodeInfo, list):
                        for node in nodeInfo:
                            item = NodeInfo(json.dumps(node,
                                ensure_ascii=False))
                            self.elements.append(item)
                    else:
                        item = NodeInfo(json.dumps(nodeInfo,
                            ensure_ascii=False))
                        self.elements.append(item)
            if self.jsonObj.hasTag('NodeStatusListType'):
                if self.jsonObj['NodeStatusListType'] is None:
                    return
                statusList = self.jsonObj['NodeStatusListType']
                if '@name' in statusList:
                    self.poolName = urllib.unquote(
                        base64.b64decode(nodeList['@name']))
                if 'node' in statusList:
                    statusInfo = statusList['node']
                    if isinstance(statusInfo, list):
                        for status in statusInfo:
                            item = NodeInfo(json.dumps(status,
                                ensure_ascii=False))
                            self.elements.append(item)
                    else:
                        item = NodeInfo(json.dumps(statusInfo,
                            ensure_ascii=False))
                        self.elements.append(item)
        except jsono.JSONObjException as e:
            raise APIException(3, e.reason)
