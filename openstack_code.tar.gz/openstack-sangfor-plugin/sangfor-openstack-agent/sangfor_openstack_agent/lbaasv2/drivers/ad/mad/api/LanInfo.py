# -*- coding: utf-8 -*-
# Copyright (c) 2008-2020, AD SANGFOR
# Filename: LanInfo.py
# 定义lan口网络配置信息
from APIException import APIException
from ErrorInfo import ErrInfo
from ParentList import ParentList
from AddrElement import AddrElement
from urllib2 import base64
import JSONObj as jsono
import urllib
import json
import codecs


class LanInfo(ErrInfo):
    def __init__(self, httpBody=None):
        ErrInfo.__init__(self, httpBody)
        self.name = None
        self.enable = None
        self.ifname = None
        self.ip = []                    # 网口ip, AddrElement类型
        self.enableDetect = None        # 健康监测开关 'true'/'false'
        self.arpDetect = None           # arp监测开关
        self.detectIp = None            # 检测ip
        self.enableNicCheck = None      # 插拔检测开关
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
                httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('lan_name'):
                self.name = urllib.unquote(
                    base64.b64decode(self.jsonObj['lan_name']))
            if self.jsonObj.hasTag('ifname'):
                netif = self.jsonObj['ifname']
                if 'ifname' in netif:
                    self.ifname = urllib.unquote(
                        base64.b64decode(netif['ifname']))
                if 'enable' in netif:
                    self.enable = netif['enable']
            if self.jsonObj.hasTag('LanIpListType'):
                ipList = self.jsonObj['LanIpListType']
                if 'ip_addr' in ipList:
                    ipInfo = ipList['ip_addr']
                    if isinstance(ipInfo, list):
                        for ip in ipInfo:
                            self.ip.append(AddrElement(ip, 1, AddrElement.ADDR_ONE))
                    else:
                        self.ip.append(AddrElement(ipInfo, 1, AddrElement.ADDR_ONE))
        except jsono.JSONObjException as e:
            raise APIException(3, e.reason)

    @classmethod
    def netifToDict(cls, lanInfo):
        netifDict = {}
        if lanInfo.ifname is not None:
            netifDict['ifname'] = lanInfo.ifname
        if lanInfo.enable is not None:
            netifDict['enable'] = lanInfo.enable
        if len(lanInfo.ip) != 0:
            netifDict['ip_addr'] = []
            for addr in lanInfo.ip:
                item = {}
                item['info'] = addr.ip
                item['info_id'] = addr.info_id
                netifDict['ip_addr'].append(item)
        return netifDict

    @classmethod
    def lanInfoToDict(cls, lanInfo):
        lanDict = {}
        if lanInfo is not None:
            if lanInfo.name is not None:
                lanDict['name'] = lanInfo.name
            if lanInfo.enableDetect is not None:
                lanDict['enable_detect'] = lanInfo.enableDetect
            if lanInfo.arpDetect is not None:
                lanDict['arp_detect'] = lanInfo.arpDetect
            if lanInfo.arpDetect is 'true':
                if lanInfo.detectIp is not None:
                    lanDict['detect_ip'] = lanInfo.detectIp
            if lanInfo.enableNicCheck is not None:
                lanDict['enable_nic_check'] = lanInfo.enableNicCheck
            netif = LanInfo.netifToDict(lanInfo)
            if netif:
                lanDict['netif'] = netif
        return lanDict

    @classmethod
    def generatingLanList(cls, httpBody):
        return LanList(httpBody)

    @classmethod
    def generatingLanInfo(cls, httpBody):
        return LanInfo(httpBody)


class LanList(ParentList):
    def __init__(self, httpBody=None):
        ParentList.__init__(self, httpBody)
        if httpBody is None or httpBody == "":
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('LanInfoListType'):
                if self.jsonObj['LanInfoListType'] is None:
                    return
                lanList = self.jsonObj['LanInfoListType']
                if 'lan_info' in lanList:
                    lanInfo = lanList['lan_info']
                    if isinstance(lanInfo, list):
                        for lan in lanInfo:
                            item = LanInfo(json.dumps(lan,
                                ensure_ascii=False))
                            self.elements.append(item)
                    else:
                        item = LanInfo(json.dumps(lanInfo,
                            ensure_ascii=False))
                        self.elements.append(item)
        except jsono.JSONObjException as e:
            raise APIException(3, e.reason)
