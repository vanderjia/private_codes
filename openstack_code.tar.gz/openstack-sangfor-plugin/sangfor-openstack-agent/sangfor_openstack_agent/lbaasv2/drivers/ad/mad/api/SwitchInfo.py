# -*- coding: utf-8 -*-
# Copyright (c) 2008-2020, AD SANGFOR
# Filename: BondInfo.py
# 定义switch信息
from Configuration import Configuration
from APIException import APIException
from ErrorInfo import ErrInfo
from http.HttpClient import HttpClient
from ParentList import ParentList
from urllib2 import base64
import JSONObj as jsono
import urllib
import json
import codecs


class SwitchInfo(ErrInfo):
    def __init__(self, httpBody=None):
        ErrInfo.__init__(self, httpBody)
        self.name = None
        self.device = None # 生成的物理网口
        self.ifname = []   # 引用的物理网口
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('name'):
                self.name = self.jsonObj['name']
            if self.jsonObj.hasTag('device'):
                self.device = self.jsonObj['device']
            if self.jsonObj.hasTag('ifname'):
                self.ifname = self.jsonObj['ifname'].split(',')
        except jsono.JSONObjException, e:
            raise APIException(3, e.reason)

    @classmethod
    def switchInfoToDict(cls, switchInfo):
        switchDict = {}
        if switchInfo.name is None:
            switchDict['name'] = ''
        else:
            switchDict['name'] = switchInfo.name
        if switchInfo.ifname:
            switchDict['ifname'] = ','.join(switchInfo.ifname)
        else:
            switchDict['ifname'] = ''
        return switchDict

    @classmethod
    def generatingSwitchInfo(cls, httpBody):
        return SwitchInfo(httpBody)

    @classmethod
    def generatingSwitchInfoList(cls, httpBody):
        return SwitchInfoList(httpBody)


class SwitchInfoList(ParentList):
    def __init__(self, httpBody=None):
        ParentList.__init__(self, httpBody)
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if not self.jsonObj.hasTag('data'):
                return
            for item in self.jsonObj['data']:
                switchItem = SwitchInfo(json.dumps(item, ensure_ascii=False))
                self.elements.append(switchItem)
        except jsono.JSONObjException, e:
            raise APIException(3, e.reason)
