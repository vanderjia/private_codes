# -*- coding: utf-8 -*-
# Copyright (c) 2008-2020, AD SANGFOR
# Filename: IPGroup.py
# 定义IP组配置信息
from APIException import APIException
from ErrorInfo import ErrInfo
from ParentList import ParentList
from urllib2 import base64
import JSONObj as jsono
import json
import urllib
import codecs


class IPInfo(ErrInfo):
    def __init__(self, httpBody=None):
        ErrInfo.__init__(self, httpBody)
        self.netifName = None
        self.ipAddr = []
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
                httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('netif_name'):
                self.netifName = urllib.unquote(
                    base64.b64decode(self.jsonObj['netif_name']))
            if self.jsonObj.hasTag('ip_addr'):
                if isinstance(self.jsonObj['ip_addr'], list):
                    for ip in self.jsonObj['ip_addr']:
                        self.ipAddr.append(ip)
                else:
                    self.ipAddr.append(self.jsonObj['ip_addr'])
        except jsono.JSONObjException as e:
            raise APIException(3, e.reason)


class IPGroup(ErrInfo):
    def __init__(self, httpBody=None):
        ErrInfo.__init__(self, httpBody)
        self.name = None
        self.ipgInfo = []
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
                httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('name'):
                self.name = urllib.unquote(
                    base64.b64decode(self.jsonObj['name']))
            if self.jsonObj.hasTag('IpInfoListType'):
                ipgList = self.jsonObj['IpInfoListType']
                if isinstance(ipgList['ip_list'], list):
                    for ipg in ipgList['ip_list']:
                        item = IPInfo(json.dumps(ipg, ensure_ascii=False))
                        self.ipgInfo.append(item)
                else:
                    ipg = ipgList['ip_list']
                    item = IPInfo(json.dumps(ipg, ensure_ascii=False))
                    self.ipgInfo.append(item)
        except jsono.JSONObjException as e:
            raise APIException(3, e.reason)

    @classmethod
    def ipGroupToDict(cls, ipGroup):
        ipGDict = {}
        if ipGroup.name is not None:
            ipGDict['name'] = ipGroup.name
        ipGDict['ip_info'] = []
        for ipG in ipGroup.ipgInfo:
            item = {}
            if ipG.netifName is not None:
                item['netif_name'] = ipG.netifName
            item['ip_addr'] = []
            for ip in ipG.ipAddr:
                item['ip_addr'].append(ip)
            ipGDict['ip_info'].append(item)
        return ipGDict

    @classmethod
    def generatingIPGroupList(cls, httpBody):
        return IPGroupList(httpBody)

    @classmethod
    def generatingIPGroup(cls, httpBody):
        return IPGroup(httpBody)


class IPGroupList (ParentList):
    '''
    从xml中获取节点列表
    '''
    def __init__(self, httpBody=None):
        ParentList.__init__(self, httpBody)
        if httpBody is None or httpBody == "":
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('IpGroupInfoListType'):
                if self.jsonObj['IpGroupInfoListType'] is None:
                    return
                grpList = self.jsonObj['IpGroupInfoListType']
                if 'ip_group_list' in grpList:
                    # json要判断是否是列表
                    if isinstance(grpList['ip_group_list'], list):
                        for grp in grpList['ip_group_list']:
                            item = IPGroup(json.dumps(grp, ensure_ascii=False))
                            self.elements.append(item)
                    else:
                        grp = grpList['ip_group_list']
                        item = IPGroup(json.dumps(grp, ensure_ascii=False))
                        self.elements.append(item)
        except jsono.JSONObjException as e:
            raise APIException(3, e.reason)
