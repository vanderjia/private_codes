# -*- coding: utf-8 -*-
# Copyright (c) 2008-2020, AD SANGFOR
# Filename: PoolInfo.py
# 定义节点池配置信息
from APIException import APIException
from ErrorInfo import ErrInfo
from ParentList import ParentList
from urllib2 import base64
import JSONObj as jsono
import urllib
import json
import codecs


class PoolInfo(ErrInfo):
    '''
    从xml中获取节点池信息
    '''
    def __init__(self, httpBody=None):
        ErrInfo.__init__(self, httpBody)
        self.name = None
        self.lbMethod = None
        self.hashType = None
        self.persist1Name = None
        self.persist2Name = None
        self.monitors = []
        self.minMonitors = -1
        self.recoverInterval = -1
        self.stepperInterval = -1
        self.schedMethod = None
        self.connStatAll = None
        self.queueLength = -1
        self.queueTimeout = -1
        self.nodeNumber = -1
        if httpBody is None or httpBody == "":
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('node_pool_name'):
                self.name = urllib.unquote(
                        base64.b64decode(self.jsonObj['node_pool_name']))
            if self.jsonObj.hasTag('node_number'):
                self.nodeNumber = int(self.jsonObj['node_number'])
            if self.jsonObj.hasTag('NodePoolViewInfoType'):
                poolInfo = self.jsonObj['NodePoolViewInfoType']
                if 'node_pool_name' in poolInfo:
                    self.name = urllib.unquote(
                        base64.b64decode(poolInfo['node_pool_name']))
                if 'node_lb_method' in poolInfo:
                    self.lbMethod = poolInfo['node_lb_method']
                if 'hash_type' in poolInfo:
                    self.hashType = poolInfo['hash_type']
                if 'persist1_name' in poolInfo:
                    self.persist1Name = urllib.unquote(
                        base64.b64decode(poolInfo['persist1_name']))
                if 'persist2_name' in poolInfo:
                    self.persist2Name = urllib.unquote(
                        base64.b64decode(poolInfo['persist2_name']))
                if 'monitors' in poolInfo:
                    if isinstance(poolInfo['monitors'], list):
                        for monitor in poolInfo['monitors']:
                            self.monitors.append(
                                urllib.unquote(base64.b64decode(monitor)))
                    else:
                        self.monitors.append(poolInfo['monitors'])
                if 'min_monitors' in poolInfo:
                    self.minMonitors = int(poolInfo['min_monitors'])
                if 'recover_interval' in poolInfo:
                    self.recoverInterval = int(poolInfo['recover_interval'])
                if 'stepper_interval' in poolInfo:
                    self.stepperInterval = int(poolInfo['stepper_interval'])
                if 'sched_method' in poolInfo:
                    self.schedMethod = poolInfo['sched_method']
                if 'conn_stat_all' in poolInfo:
                    self.connStatAll = poolInfo['conn_stat_all']
                if 'queue_length' in poolInfo:
                    self.queueLength = int(poolInfo['queue_length'])
                if 'queue_timeout' in poolInfo:
                    self.queueTimeout = int(poolInfo['queue_timeout'])
        except jsono.JSONObjException as e:
            raise APIException(3, e.reason)

    @classmethod
    def poolInfoToDict(cls, pool):
        poolDict = {}
        if pool.name is not None:
            poolDict['name'] = pool.name
        if pool.lbMethod is not None:
            poolDict['lb_method'] = pool.lbMethod
        if pool.hashType is not None:
            poolDict['hash_type'] = pool.hashType
        if pool.persist1Name is not None:
            poolDict['persist1_name'] = pool.persist1Name
        if pool.persist2Name is not None:
            poolDict['persist2_name'] = pool.persist2Name
        if len(pool.monitors) != 0:
            poolDict['monitors'] = pool.monitors
        if pool.minMonitors != -1:
            poolDict['min_monitors'] = pool.minMonitors
        if pool.recoverInterval != -1:
            poolDict['recover_inter'] = pool.recoverInterval
        if pool.stepperInterval != -1:
            poolDict['stepper_inter'] = pool.stepperInterval
        if pool.schedMethod is not None:
            poolDict['sched_method'] = pool.schedMethod
        if pool.queueLength != -1:
            poolDict['queue_length'] = pool.queueLength
        if pool.queueTimeout != -1:
            poolDict['queue_timeout'] = pool.queueTimeout
        if pool.connStatAll is not None:
            poolDict['conn_stat_all'] = pool.connStatAll
        return poolDict

    @classmethod
    def generatingPoolList(cls, httpBody):
        return PoolList(httpBody)

    @classmethod
    def generatingPoolInfo(cls, httpBody):
        return PoolInfo(httpBody)


class PoolList (ParentList):
    def __init__(self, httpBody=None):
        ParentList.__init__(self, httpBody)
        if httpBody is None or httpBody == "":
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('NodePoolListType'):
                if self.jsonObj['NodePoolListType'] is None:
                    return
                poolList = self.jsonObj['NodePoolListType']
                if 'node_pool' in poolList:
                    poolInfo = poolList['node_pool']
                    if isinstance(poolInfo, list):
                        for pool in poolInfo:
                            item = PoolInfo(json.dumps(pool,
                                ensure_ascii=False))
                            self.elements.append(item)
                    else:
                        item = PoolInfo(json.dumps(poolInfo,
                            ensure_ascii=False))
                        self.elements.append(item)
        except jsono.JSONObjException as e:
            raise APIException(3, e.reason)
