﻿# -*- coding: utf-8 -*-
# Copyright (c) 2008-2020, AD SANGFOR
# Filename: SnatSet.py
# snat地址集
from APIException import APIException
from ErrorInfo import ErrInfo
from ParentList import ParentList
from AddrElement import AddrElement
from urllib2 import base64
import JSONObj as jsono
import urllib
import json
import codecs


class SnatSet(ErrInfo):
    def __init__(self, httpBody=None):
        ErrInfo.__init__(self, httpBody)
        self.name = None
        self.ipRange = []      # ip地址范围，AddrElement类型
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
                httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('name'):
                self.name = urllib.unquote(
                        base64.b64decode(self.jsonObj['name']))
            if self.jsonObj.hasTag('SnatSetType'):
                snatSet = self.jsonObj['SnatSetType']
                if 'name' in snatSet:
                    self.name = urllib.unquote(
                        base64.b64decode(snatSet['name']))
                if 'ip_range' in snatSet:
                    ipList = snatSet['ip_range']
                    if isinstance(ipList, list):
                        for addr in ipList:
                            addrType = None
                            info = None
                            if 'type' in addr:
                                addrType = addr['type']
                            if 'info' in addr:
                                info = addr['info']
                            self.ipRange.append(AddrElement(info, 0, addrType))
                    else:
                        addrType = None
                        info = None
                        if 'type' in ipList:
                            addrType = ipList['type']
                        if 'info' in ipList:
                            info = ipList['info']
                        self.ipRange.append(AddrElement(info, 0, addrType))
        except jsono.JSONObjException as e:
            raise APIException(3, e.reason)

    @classmethod
    def snatSetToDict(cls, snatSet):
        snatDict = {}
        if snatSet.name is not None:
            snatDict['name'] = snatSet.name
        if len(snatSet.ipRange) != 0:
            snatDict['ip_range'] = []
            for addr in snatSet.ipRange:
                item = {}
                if addr.type is not None:
                    item['type'] = addr.type
                if addr.ip is not None:
                    item['info'] = addr.ip
                snatDict['ip_range'].append(item)
        return snatDict

    @classmethod
    def generatingSnatSetList(cls, httpBody):
        return SnatSetList(httpBody)

    @classmethod
    def generatingSnatSet(cls, httpBody):
        return SnatSet(httpBody)


class SnatSetList(ParentList):
    '''
    '''
    def __init__(self, httpBody = None):
        ParentList.__init__(self, httpBody)
        if httpBody is None or httpBody is "":
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('SnatSetListType'):
                if self.jsonObj['SnatSetListType'] is None:
                    return
                snatList = self.jsonObj['SnatSetListType']
                if 'snat_set' in snatList:
                    snatSet = snatList['snat_set']
                    if isinstance(snatSet, list):
                        for snat in snatSet:
                            snatInfo = SnatSet(json.dumps(snat,
                                ensure_ascii=False))
                            self.elements.append(snatInfo)
                    else:
                        snatInfo = SnatSet(json.dumps(snatSet,
                                ensure_ascii=False))
                        self.elements.append(snatInfo)
        except jsono.JSONObjException as e:
            raise APIException(3, e.reason)
