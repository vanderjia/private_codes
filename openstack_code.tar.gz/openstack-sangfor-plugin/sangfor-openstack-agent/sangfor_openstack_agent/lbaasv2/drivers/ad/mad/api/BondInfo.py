# -*- coding: utf-8 -*-
# Copyright (c) 2008-2020, AD SANGFOR
# Filename: BondInfo.py
# 定义bond信息
from Configuration import Configuration
from APIException import APIException
from ErrorInfo import ErrInfo
from http.HttpClient import HttpClient
from ParentList import ParentList
from urllib2 import base64
import JSONObj as jsono
import urllib
import json
import codecs


class BondMethod:
    '''
    绑定策略
    '''
    NET_BOND_HASH = 1           # 哈希
    NET_BOND_RR = 2             # 轮询
    NET_BOND_8023AD = 3         # 802.3ad
    NET_BOND_ACTIVE_BACKUP = 4  # 冗余双网卡

    def __init__(self):
        None

    @classmethod
    def check(cls, val):
        if (BondMethod.NET_BOND_HASH != val and
            BondMethod.NET_BOND_RR != val and
            BondMethod.NET_BOND_8023AD != val and
            BondMethod.NET_BOND_ACTIVE_BACKUP != val):
            return False
        return True


class BondInfo(ErrInfo):
    def __init__(self, httpBody=None):
        ErrInfo.__init__(self, httpBody)
        self.name = None
        self.device = None                       # 生成的物理网口
        self.ifname = []                         # 引用的物理接口列表
        self.method = BondMethod.NET_BOND_HASH   # 绑定策略
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('name'):
                self.name = self.jsonObj['name']
            if self.jsonObj.hasTag('device'):
                self.device = self.jsonObj['device']
            if self.jsonObj.hasTag('ifname'):
                self.ifname = self.jsonObj['ifname'].split(',')
            if self.jsonObj.hasTag('method'):
                self.method = int(self.jsonObj['method'])
        except jsono.JSONObjException, e:
            raise APIException(3, e.reason)

    @classmethod
    def bondInfoToDict(cls, bondInfo):
        bondDict = {}
        bondDict['method'] = bondInfo.method
        if bondInfo.name is None:
            bondDict['name'] = ''
        else:
            bondDict['name'] = bondInfo.name
        if bondInfo.ifname:
            bondDict['ifname'] = ','.join(bondInfo.ifname)
        else:
            bondDict['ifname'] = ''
        return bondDict

    @classmethod
    def generatingBondInfo(cls, httpBody):
        return BondInfo(httpBody)

    @classmethod
    def generatingBondInfoList(cls, httpBody):
        return BondInfoList(httpBody)


class BondInfoList(ParentList):
    def __init__(self, httpBody=None):
        ParentList.__init__(self, httpBody)
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if not self.jsonObj.hasTag('data'):
                return
            for item in self.jsonObj['data']:
                bond = BondInfo(json.dumps(item, ensure_ascii=False))
                self.elements.append(bond)
        except jsono.JSONObjException, e:
            raise APIException(3, e.reason)
