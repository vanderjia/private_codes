# -*- coding: utf-8 -*-
# Copyright (c) 2008-2020, AD SANGFOR
# Filename: NetifIP.py
# 定义接口IP信息
from Configuration import Configuration
from APIException import APIException
from ErrorInfo import ErrInfo
from http.HttpClient import HttpClient
from ParentList import ParentList
from urllib2 import base64
import JSONObj as jsono
import urllib
import json
import codecs


class NetifIP(ErrInfo):
    '''
    接口IP配置
    {
        'id': ,
        'ifname': ,
        'ip_list': ,
    }
    '''
    def __init__(self, httpBody=None):
        ErrInfo.__init__(self, httpBody)
        self.ifname = None      # 网络接口
        self.ipList = []            # IP列表 ip/mask
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('ifname'):
                self.ifname = self.jsonObj['ifname']
            if self.jsonObj.hasTag('ip_list'):
                self.ipList = self.jsonObj['ip_list'].split(',')
        except jsono.JSONObjException, e:
            raise APIException(3, e.reason)

    @classmethod
    def netifIPToDict(cls, netifIP):
        ipDict = {}
        if netifIP.ifname is not None:
            ipDict['ifname'] = netifIP.ifname
        else:
            ipDict['ifname'] = ''
        ipDict['ip_list'] = ','.join(netifIP.ipList)
        return ipDict

    @classmethod
    def generatingNetifIPList(cls, httpBody):
        return NetifIPList(httpBody)


class NetifIPList(ParentList):
    '''
    接口列表IP
    {
        'data': [
            {'id': , .....}
        ]
    }
    '''
    def __init__(self, httpBody):
        ParentList.__init__(self, httpBody)
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if not self.jsonObj.hasTag('data'):
                return
            for item in self.jsonObj['data']:
                ip = NetifIP(json.dumps(item, ensure_ascii=False))
                self.elements.append(ip)
        except jsono.JSONObjException, e:
            raise APIException(3, e.reason)
