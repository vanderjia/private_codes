# -*- coding: utf-8 -*-
# Copyright (c) 2008-2020, AD SANGFOR
# Filename: VADInfo.py
# 定义VAD信息
from Configuration import Configuration
from APIException import APIException
from ErrorInfo import ErrInfo
from http.HttpClient import HttpClient
from ParentList import ParentList
from urllib2 import base64
import JSONObj as jsono
import urllib
import json
import codecs


class VADInfo(ErrInfo):
    def __init__(self, httpBody=None):
        ErrInfo.__init__(self, httpBody)
        self.uuid = None        # uuid
        self.name = None        # VAD名称
        self.adVersion = None   # 引用镜像uuid
        self.imageVer = None    # 镜像版本
        self.adVer = None       # vAD版本
        self.gateway = None     # VAD网关
        self.ip = None          # VAD管理ip
        self.mask = 0           # VAD管理ip掩码
        self.passwd = None      # VAD密码
        self.cpuCore = 0        # cpu逻辑个数
        self.mem = 0            # 内存大小
        self.cpuNum = 0         # 物理cpu个数(MAD2.0这个字段没用到，为了兼容)
        self.maxNewConn = 0     # 新建连接数
        self.maxConn = 0        # 并发连接数
        self.vlanSel = []       # VAD映射网口
        self.resType = 0        # 资源等级 0/1/2/3: 低配/中配/高配/自定义(sdk这个值为3)
        self.macAddr = []       # 网口映射对应的mac地址
        self.reportEnable = 0   # 是否开启报表，关闭：0，开启：1
        self.cpuRates = 0.0     # CPU占用率，单位：%
        self.memRates = 0.0     # 内存占用率，单位：%
        self.status = None      # vAD状态
        self.runTime = None     # vAD运行时间
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('vad_version'):
                self.adVersion = self.jsonObj['vad_version']
            if self.jsonObj.hasTag('image_version'):
                self.imageVer = self.jsonObj['image_version']
            if self.jsonObj.hasTag('vad_ver'):
                self.adVer = self.jsonObj['vad_ver']
            if self.jsonObj.hasTag('ad_name'):
                self.name = self.jsonObj['ad_name']
            if self.jsonObj.hasTag('vad_uuid'):
                self.uuid = self.jsonObj['vad_uuid']
            if self.jsonObj.hasTag('ad_gateway'):
                self.gateway = self.jsonObj['ad_gateway']
            if self.jsonObj.hasTag('ad_manage_ip'):
                self.ip = self.jsonObj['ad_manage_ip']
            if self.jsonObj.hasTag('ad_manage_mask'):
                self.mask = int(self.jsonObj['ad_manage_mask'])
            if self.jsonObj.hasTag('ad_user_passwd'):
                self.passwd = self.jsonObj['ad_user_passwd']
            if self.jsonObj.hasTag('cpu_core'):
                self.cpuCore = int(self.jsonObj['cpu_core'])
            if self.jsonObj.hasTag('ad_mem_num'):
                self.mem = int(self.jsonObj['ad_mem_num'])
            if self.jsonObj.hasTag('cpu_num'):
                self.cpuNum = int(self.jsonObj['cpu_num'])
            if self.jsonObj.hasTag('max_new_conn'):
                self.maxNewConn = int(self.jsonObj['max_new_conn'])
            if self.jsonObj.hasTag('max_conn'):
                self.maxConn = int(self.jsonObj['max_conn'])
            if self.jsonObj.hasTag('vlan_sel'):
                self.vlanSel = self.jsonObj['vlan_sel'].split(',')
            if self.jsonObj.hasTag('mac_addr'):
                self.macAddr = self.jsonObj['mac_addr'].split(',')
            if self.jsonObj.hasTag('res_type'):
                self.resType = int(self.jsonObj['res_type'])
            if self.jsonObj.hasTag('has_report'):
                self.reportEnable = int(self.jsonObj['has_report'])
            if self.jsonObj.hasTag('cpu_rates'):
                self.cpuRates = float(self.jsonObj['cpu_rates'])
            if self.jsonObj.hasTag('mem_rates'):
                self.memRates = float(self.jsonObj['mem_rates']) * 100
            if self.jsonObj.hasTag('status'):
                self.status = self.jsonObj['status']
            if self.jsonObj.hasTag('run_time'):
                self.runTime = self.jsonObj['run_time']
        except jsono.JSONObjException, e:
            raise APIException(3, e.reason)

    @classmethod
    def VADInfoToDict(cls, vadInfo):
        vadDict = {}
        if vadInfo.name is None:
            vadDict['ad_name'] = ''
        else:
            vadDict['ad_name'] = vadInfo.name
        if vadInfo.uuid is None:
            vadDict['vad_uuid'] = ''
        else:
            vadDict['vad_uuid'] = vadInfo.uuid
        if vadInfo.adVersion is None:
            vadDict['vad_version'] = ''
        else:
            vadDict['vad_version'] = vadInfo.adVersion
        if vadInfo.gateway is None:
            vadDict['ad_gateway'] = ''
        else:
            vadDict['ad_gateway'] = vadInfo.gateway
        if vadInfo.ip is None:
            vadDict['ad_manage_ip'] = ''
        else:
            vadDict['ad_manage_ip'] = vadInfo.ip
        vadDict['ad_manage_mask'] = vadInfo.mask
        if vadInfo.passwd is None:
            vadDict['ad_user_passwd'] = ''
        else:
            vadDict['ad_user_passwd'] = vadInfo.passwd
        vadDict['cpu_core'] = vadInfo.cpuCore
        vadDict['ad_mem_num'] = vadInfo.mem
        vadDict['max_new_conn'] = vadInfo.maxNewConn
        vadDict['max_conn'] = vadInfo.maxConn
        if vadInfo.vlanSel:
            vadDict['vlan_sel'] = ','.join(vadInfo.vlanSel)
        else:
            vadDict['vlan_sel'] = ''
        if vadInfo.macAddr:
            vadDict['mac_addr'] = ','.join(vadInfo.macAddr)
        else:
            vadDict['mac_addr'] = ''
        vadDict['has_report'] = vadInfo.reportEnable
        vadDict['res_type'] = 3
        return vadDict

    @classmethod
    def generatingVADInfo(cls, httpBody):
        return VADInfo(httpBody)

    @classmethod
    def generatingVADInfoList(cls, httpBody):
        return VADInfoList(httpBody)


class VADInfoList(ParentList):
    def __init__(self, httpBody=None):
        ParentList.__init__(self, httpBody)
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if not self.jsonObj.hasTag('data'):
                return
            for item in self.jsonObj['data']:
                vad = VADInfo(json.dumps(item, ensure_ascii=False))
                self.elements.append(vad)
        except jsono.JSONObjException, e:
            raise APIException(3, e.reason)
