# -*- coding: utf-8 -*-
# Copyright (c) 2008-2020, AD SANGFOR
# Filename: VlanInfo.py
# 定义vlan信息
from Configuration import Configuration
from APIException import APIException
from ErrorInfo import ErrInfo
from http.HttpClient import HttpClient
from ParentList import ParentList
from urllib2 import base64
import JSONObj as jsono
import urllib
import json


class VlanInfo(ErrInfo):
    def __init__(self, httpBody=None):
        ErrInfo.__init__(self, httpBody)
        self.name = None
        self.device = None      # 生成的Vlan网口
        self.ifname = None      # 引用物理网口
        self.vlanId = 0         # vlan id [1, 4094]
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('name'):
                self.name = self.jsonObj['name']
            if self.jsonObj.hasTag('ifname'):
                self.ifname = self.jsonObj['ifname']
            if self.jsonObj.hasTag('device'):
                self.device = self.jsonObj['device']
            if self.jsonObj.hasTag('vlan_id'):
                self.vlanId = int(self.jsonObj['vlan_id'])
        except jsono.JSONObjException, e:
            raise APIException(3, e.reason)

    @classmethod
    def vlanInfoToDict(cls, vlanInfo):
        vlanDict = {}
        vlanDict['vlan_id'] = vlanInfo.vlanId
        if vlanInfo.name is None:
            vlanDict['name'] = ''
        else:
            vlanDict['name'] = vlanInfo.name
        if vlanInfo.ifname is None:
            vlanDict['ifname'] = ''
        else:
            vlanDict['ifname'] = vlanInfo.ifname
        return vlanDict

    @classmethod
    def generatingVlanInfo(cls, httpBody):
        return VlanInfo(httpBody)

    @classmethod
    def generatingVlanInfoList(cls, httpBody):
        return VlanInfoList(httpBody)


class VlanInfoList(ParentList):
    def __init__(self, httpBody=None):
        ParentList.__init__(self, httpBody)
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if not self.jsonObj.hasTag('data'):
                return
            for item in self.jsonObj['data']:
                vlan = VlanInfo(json.dumps(item, ensure_ascii=False))
                self.elements.append(vlan)
        except jsono.JSONObjException, e:
            raise APIException(3, e.reason)
