# -*- coding: utf-8 -*-
# Copyright (c) 2008-2020, AD SANGFOR
# Filename: ServInfo.py
# 定义服务配置信息
from APIException import APIException
from ErrorInfo import ErrInfo
from ParentList import ParentList
from urllib2 import base64
import JSONObj as jsono
import urllib
import json
import codecs


class PortInfo (ErrInfo):
    '''
    服务端口类
    '''
    def __init__(self, httpBody=None):
        ErrInfo.__init__(self, httpBody)
        self.fromPort = -1
        self.toPort = -1
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('from'):
                self.fromPort = int(self.jsonObj['from'])
            if self.jsonObj.hasTag('to'):
                self.toPort = int(self.jsonObj['to'])
        except jsono.JSONObjException as e:
            raise APIException(3, e.reason)


class ServInfo(ErrInfo):
    '''
    服务类
    '''
    def __init__(self, httpBody=None):
        ErrInfo.__init__(self, httpBody)
        self.type = None
        self.name = None
        self.portInfo = []
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
                httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('name'):
                self.name = base64.b64decode(self.jsonObj['name'])
            if self.jsonObj.hasTag('type'):
                self.type = self.jsonObj['type']
            if self.jsonObj.hasTag('PortListType'):
                port = self.jsonObj['PortListType']
                if isinstance(port['port'], list):
                    for portInfo in port['port']:
                        item = PortInfo(json.dumps(portInfo,
                            ensure_ascii=False))
                        self.portInfo.append(item)
                else:
                    item = PortInfo(json.dumps(port['port'],
                            ensure_ascii=False))
                    self.portInfo.append(item)
        except jsono.JSONObjException as e:
            raise APIException(3, e.reason)

    @classmethod
    def servInfoToDict(cls, servInfo):
        servDict = {}
        if servInfo.type is not None:
            servDict['type'] = servInfo.type
        if servInfo.name is not None:
            servDict['name'] = servInfo.name
        if len(servInfo.portInfo) != 0:
            servDict['port_scope'] = []
            for item in servInfo.portInfo:
                port = {}
                if item.fromPort != -1:
                    port['from'] = item.fromPort
                if item.toPort != -1:
                    port['to'] = item.toPort
                servDict['port_scope'].append(port)
        return servDict

    @classmethod
    def generatingServList(cls, httpBody):
        return ServInfoList(httpBody)

    @classmethod
    def generatingServInfo(cls, httpBody):
        return ServInfo(httpBody)


class ServInfoList(ParentList):
    '''
    从xml中获取节点列表
    '''
    def __init__(self, httpBody=None):
        ParentList.__init__(self, httpBody)
        if httpBody is None or httpBody == "":
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('ServiceInfoListType'):
                if self.jsonObj['ServiceInfoListType'] is None:
                    return
                objList = self.jsonObj['ServiceInfoListType']
                if 'service_info' in objList:
                    servList = objList['service_info']
                    if isinstance(servList, list):
                        for item in servList:
                            servInfo = ServInfo(json.dumps(item,
                                ensure_ascii=False))
                            self.elements.append(servInfo)
                    else:
                        servInfo = ServInfo(json.dumps(servList,
                            ensure_ascii=False))
                        self.elements.append(servInfo)
        except jsono.JSONObjException as e:
            raise APIException(3, e.reason)
