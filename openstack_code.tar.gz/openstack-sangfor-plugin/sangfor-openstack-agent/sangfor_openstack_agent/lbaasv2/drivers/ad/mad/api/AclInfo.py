# -*- coding: utf-8 -*-
# Copyright (c) 2008-2020, AD SANGFOR
# Filename: AclInfo.py
# 定义高级ACL配置信息
from APIException import APIException
from ErrorInfo import ErrInfo
from ParentList import ParentList
from AddrElement import AddrElement
from urllib2 import base64
import JSONObj as jsono
import urllib
import json
import codecs


class AclInfo(ErrInfo):
    def __init__(self, httpBody=None):
        ErrInfo.__init__(self, httpBody)
        self.name = None        # 名称
        self.enable = None      # 状态
        self.type = None        # 地址类型
        self.info = None        # 地址信息
        self.vsname = None      # 虚拟服务名称
        self.connectLimit = -1 # 并发连接限制
       
        if httpBody is "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
                httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('name'):
                self.name = urllib.unquote(
                    base64.b64decode(self.jsonObj['name']))
            if self.jsonObj.hasTag('enable'):
                    self.enable = self.jsonObj['enable']
            if self.jsonObj.hasTag('vsname'):
                self.vsname = urllib.unquote(
                    base64.b64decode(self.jsonObj['vsname']))
            if self.jsonObj.hasTag('type'):
                self.type = self.jsonObj['type']
            if self.jsonObj.hasTag('info'):
                self.type = self.jsonObj['info']
            if self.jsonObj.hasTag('connect_limit'):
                self.connectLimit = int(self.jsonObj['connect_limit'])
        except jsono.JSONObjException as e:
            raise APIException(3, e.reason)

    @classmethod
    def srcAddrToDict(cls, aclInfo):
        addrDict = {}
        if aclInfo.type is not None:
            addrDict['type'] = aclInfo.type
        if aclInfo.info is not None:
            addrDict['info'] = aclInfo.info
        return addrDict

    @classmethod
    def aclInfoToDict(cls, aclInfo):
        aclDict = {}
        if aclInfo.name is not None:
            aclDict['name'] = aclInfo.name
        if aclInfo.enable is not None:
            aclDict['enable'] = aclInfo.enable
        srcAddr = AclInfo.srcAddrToDict(aclInfo)
        if srcAddr:
            aclDict['src_addr'] = srcAddr
        if aclInfo.vsname is not None:
            aclDict['vsname'] = aclInfo.vsname
        if aclInfo.connectLimit != -1:
            aclDict['connect_limit'] = aclInfo.connectLimit
        return aclDict

    @classmethod
    def generatingAclList(cls, httpBody):
        return AclList(httpBody)

    @classmethod
    def generatingAclInfo(cls, httpBody):
        return AclInfo(httpBody)


class AclList (ParentList):
    '''
    获取高级ACL信息列表
    '''
    def __init__(self, httpBody=None):
        ParentList.__init__(self, httpBody)
        if httpBody is None or httpBody is "":
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode) :
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try :
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('AdvanceAclListType'):
                if self.jsonObj['AdvanceAclListType'] is None:
                    return
                aclList = self.jsonObj['AdvanceAclListType']
                if 'acl_info' in aclList:
                    aclInfo = aclList['acl_info']
                    if isinstance(aclInfo, list):
                        for acl in aclInfo:
                            item = AclInfo(json.dumps(acl,
                                ensure_ascii=False))
                            self.elements.append(item)
                    else:
                        item = AclInfo(json.dumps(aclInfo,
                            ensure_ascii=False))
                        self.elements.append(item)
        except jsono.JSONObjException as e:
            raise APIException(3, e.reason)
