# -*- coding: utf-8 -*-
# Copyright (c) 2008-2020, AD SANGFOR
# Filename: VxlanInfo.py
# 定义vxlan信息
from Configuration import Configuration
from APIException import APIException
from ErrorInfo import ErrInfo
from http.HttpClient import HttpClient
from ParentList import ParentList
from urllib2 import base64
import JSONObj as jsono
import urllib
import json
import codecs


class VxlanInfo(ErrInfo):
    '''
    vxlan信息
    {
        'id': ,
        'name': ,
        'vxlan_id': ,
        'is_group': ,
        'ifname': ,
        'local_addr': ,
        'local_port': ,
        'remote_addr': ,
        'remote_port': ,
    }
    '''
    def __init__(self, httpBody=None):
        ErrInfo.__init__(self, httpBody)
        self.name = None        # vxlan名称
        self.vxlanId = 0        # vxlan id
        self.device = None      # 设备名
        self.isGroup = 0        # 是否是组播, 0：单播，1：组播
        self.ifname = None      # 绑定出接口
        self.localAddr = None   # 本地IP地址
        self.localPort = 0      # 本地vxlan端口
        self.remoteAddr = []    # 远端vxlan IP
        self.remotePort = 0     # 远端vxlan端口
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if self.jsonObj.hasTag('name'):
                self.name = self.jsonObj['name']
            if self.jsonObj.hasTag('vxlan_id'):
                self.vxlanId = int(self.jsonObj['vxlan_id'])
            if self.jsonObj.hasTag('is_group'):
                self.isGroup = int(self.jsonObj['is_group'])
            if self.jsonObj.hasTag('device'):
                self.device = self.jsonObj['device']
            if self.jsonObj.hasTag('ifname'):
                self.ifname = self.jsonObj['ifname']
            if self.jsonObj.hasTag('local_addr'):
                self.localAddr = self.jsonObj['local_addr']
            if self.jsonObj.hasTag('local_port'):
                self.localPort = int(self.jsonObj['local_port'])
            if self.jsonObj.hasTag('remote_addr'):
                self.remoteAddr = self.jsonObj['remote_addr'].split(',')
            if self.jsonObj.hasTag('remote_port'):
                self.remotePort = int(self.jsonObj['remote_port'])
        except jsono.JSONObjException, e:
            raise APIException(3, e.reason)

    @classmethod
    def vxlanInfoToDict(cls, vxlanInfo):
        vxlanDict = {}
        if vxlanInfo.name is not None:
            vxlanDict['name'] = vxlanInfo.name
        else:
            vxlanDict['name'] = ''
        vxlanDict['vxlan_id'] = vxlanInfo.vxlanId
        vxlanDict['is_group'] = vxlanInfo.isGroup
        if vxlanInfo.localAddr is not None:
            vxlanDict['local_addr'] = vxlanInfo.localAddr
        else:
            vxlanDict['local_addr'] = ''
        if vxlanInfo.ifname is not None:
            vxlanDict['ifname'] = vxlanInfo.ifname
        else:
            vxlanDict['ifname'] = ''
        vxlanDict['local_port'] = vxlanInfo.localPort
        vxlanDict['remote_addr'] = ','.join(vxlanInfo.remoteAddr)
        vxlanDict['remote_port'] = vxlanInfo.remotePort
        return vxlanDict

    @classmethod
    def generatingVxlanInfo(cls, httpBody):
        return VxlanInfo(httpBody)

    @classmethod
    def generatingVxlanList(cls, httpBody):
        return VxlanList(httpBody)


class VxlanList(ParentList):
    '''
    vxlan信息列表
    {
        'data': [
            {
                'id': ,
                ......
            }
        ]
    }
    '''
    def __init__(self, httpBody):
        ParentList.__init__(self, httpBody)
        if httpBody == "" or httpBody is None:
            self.originStr = ""
            return
        if self.isFailed() or self.getErrCode() == 0:
            return
        if not isinstance(httpBody, unicode):
            httpBody = unicode(httpBody, "utf8")
        self.originStr = httpBody
        try:
            self.jsonObj = jsono.JSONObj(httpBody)
            if not self.jsonObj.hasTag('data'):
                return
            for item in self.jsonObj['data']:
                vxlan = VxlanInfo(json.dumps(item, ensure_ascii=False))
                self.elements.append(vxlan)
        except jsono.JSONObjException, e:
            raise APIException(3, e.reason)
