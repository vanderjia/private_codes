# -*- coding: utf-8 -*-
# Copyright (c) 2008-2020, AD SANGFOR
# Filename: VADAuthInfo.py
# 定义VAD账号信息信息
from urllib2 import base64


class VADAuthInfo:
    def __init__(self, vadName, ip, port, username, passwd):
        self.vadName = vadName
        self.ip = ip
        self.port = port
        self.username = username
        self.passwd = passwd

    @classmethod
    def base64encode(cls, src):
        if src is None:
            return None
        return base64.b64encode(src)

    @classmethod
    def base64decode(cls, src):
        if src is None:
            return None
        return base64.b64decode(src)
