#coding:utf-8
#from sangfor_openstack_agent.lbaasv2.drivers.ad.vad import MADHOST as MAD 
#from sangfor_openstack_agent.lbaasv2.drivers.ad.vad import VAD as VAD 
#from sangfor_openstack_agent.lbaasv2.drivers.ad.ad import ADHOST as AD 
from ad import ADHOST as AD
from sangfor_openstack_agent.lbaasv2.drivers.ad.utils import compareData as compare
from oslo_log import log as logging
LOG = logging.getLogger(__name__)

#__ALL__ = ['MADcache', 'VADcache']
__ALL__ = ['ADcache']

def _needUpdate(name, kargs, cache):
    if name not in cache:
        return True
    else:
        if not compare(kargs, cache[name]):
            return True
    return False

class ADcache(object):
    def __init__(self, username, password, host, port):
        #TODO:vlan ADAPI还未实现
        self.vlanCache = {}
        #TODO:vxlan AD那边还未实现
        self.vxlanCache = {}
        self.ipGroupCache={}
        self.ipCache = {}
        self.servCache = {}
        self.vsCache = {}
        self.poolCache = {}
        self.memberCache = {}
        self.poolMonitorCache ={}
        self.persistCache = {}
        self.wanCache = {}
        self.monitorCache ={}
        #self.name = name
        #kargs['mad'] = kargs['mad'].mad
        #self.vad = VAD(name, kargs)
        self.adapi = AD(username, password, host, port)

    #TODO:需要将vlan vxlan接口替换成对接ad api
    def createVlan(self, name, vlanid, interface=[]):
        '''
        @创建vlan口
        @param name vlan口名称
        @param vlanid vlan口tag id
        @interface 引用网口
        @return vlan的device名称
        '''
        if name in self.vlanCache:
            return

        device = self.ad.createVlan(name, vlanid, interface)
        self.vlanCache[name] = {
            'id': vlanid,
            'interface':interface
        }
        return

    def updateVlan(self, name, id, interface):
        '''
        TODO: 没人用这个接口，暂时保持原样
        @更新vlan口
        @param name
        '''
        args = dict(id=id, interface=interface)
        if _needUpdate(name, args, self.vlanCache):
            self.mad.updateVlan(name, vlanid, interface)
            self.vlanCache[name]['id']=vlanid
            self.vlanCache[name]['interface']=interface

    def deleteVlan(self, name):
        '''
        @删除vlan口
        @param name vlan名称
        @return None
        '''
        self.mad.deleteVlan(name)
        if name in self.vlanCache:
            del self.vlanCache[name]

    def createVxlan(self, name, vxlanid, remoteaddr=[], remoteport=4789):
        '''
        TODO:vxlan创建接口暂时未实现
        '''
        return 
        if name in self.vxlanCache:
            return
        self.mad.createVxlan(name, vxlanid, remoteaddr, remoteport)
        self.vxlanCache[name] = dict(vxlanid=vxlanid, remoteaddr=remoteaddr, remoteport=remoteport)
        pass

    def updateVxlan(self, name, vxlanid, remoteaddr, remoteport=4789):
        '''
        TODO:vxlan更新接口暂时未实现
        '''
        return
        args = dict(vxlanid=vxlanid, remoteaddr=remoteaddr,remoteport=remoteport)
        if _needUpdate(name, args, self.vxlanCache[name]):
            self.mad.updateVxlan(name, vxlanid, remoteaddr, remoteport)
            self.vxlanCache[name] = args

    def deleteVxlan(self, name):
        '''
        TODO:vxlan删除接口暂时未实现
        '''
        return 
        self.mad.deleteVxlan(name)
        if name in self.vxlanCache:
            del self.vxlanCache[name]

    #TODO:下面接口需要替换adapi api为ad api
    def createServ(self, name, Stype="SRV_HTTP", port=[]):
        if name in self.servCache:
            return
        self.adapi.createServ(name, Stype, port)
        self.servCache[name] = dict(type=Stype, port=port)
        pass

    def updateServ(self, name, Stype="SRV_HTTP", port=[]):
        args = dict(type=Stype, port=port)
        if _needUpdate(name, args, self.servCache):
            self.adapi.updateServ(name, Stype, port)
            self.servCache[name] = args
        pass

    def deleteServ(self, name):
        self.adapi.deleteServ(name)
        if name in self.servCache:
            del self.servCache[name]
        pass

    def createIPGroup(self, name, ip=[], args={}):
        if name in self.ipGroupCache:
            return 
        self.adapi.createIPGroup(name, ip, args)
        self.ipGroupCache[name] = dict(ip=ip)
        pass
    def updateIPGroup(self, name, ip=[]):
        args = dict(ip=ip)
        if _needUpdate(name, args, self.ipGroupCache):
            self.adapi.updateIPGroup(name, ip)
            self.ipGroupCache[name] = args
        pass
    def deleteIPGroup(self, name, args):
        self.adapi.deleteIPGroup(name, args)
        if name in self.ipGroupCache:
            del self.ipGroupCache[name]
        pass
    def IPGroupAddIP(self, ipgrpname="", ip=[]):
        newip = []
        if ipgrpname in self.ipCache:
            for single in ip:
                if single not in self.ipCache[ipgrpname]['ip']:
                    newip.append(single)
        else:
            self.adapi.IPGroupAddIP(ipgrpname, ip)
            self.ipCache[ipgrpnamer] = {'ip':ip}
            

        if len(newip):
            self.adapi.IPGroupAddIP(ipgrpname, newip)
        for single in newip:
            self.ipCache[ipgrpname]['ip'].append(single)

        pass
    def IPGroupDelIP(self, ipgrpname="", ip=[]):
        if ipgrpname in self.ipCache:
            self.adapi.IPGroupDelIP(ipgrpname, ip)
            for single in ip:
                if single in self.ipCache[ipgrpname]['ip']:
                    self.ipCache[ipgrpname]['ip'].remove(single)
        else:
            self.adapi.IPGroupDelIP(ipgrpname, ip)
        pass

    def createPersist(self, name, kargs={}):
        if name in self.persistCache:
            return
        self.adapi.createPersist(name, kargs)
        self.persistCache[name] = kargs
        pass
    def deletePersist(self, name):
        self.adapi.deletePersist(name)
        if name in self.persistCache:
            del self.persistCache[name]
        pass


    def updatePersist(self, name, kargs={}):
        if _needUpdate(name, kargs, self.persistCache):
            self.deletePersist(name)
            self.createPersist(name, kargs)
            self.persistCache[name] = kargs
    def createMonitor(self, name, type='MONITOR_CONNECT_TCP', kargs={}):
        if name in self.monitorCache:
            return
        self.adapi.createMonitor(name, type, kargs)
        self.monitorCache[name] = { 'type':type, 'kargs':kargs }
        pass
    def updateMonitor(self, name, type='MONITOR_CONNECT_TCP', kargs={}):
        args = dict(type=type, kargs=kargs)
        if _needUpdate(name, args, self.monitorCache):
            self.adapi.updateMonitor(name, type, kargs)
            self.monitorCache[name] = args
        pass
    def deleteMonitor(self, name):
        self.adapi.deleteMonitor(name)
        if name in self.monitorCache:
            del self.monitorCache[name]
        pass
    def createPool(self, name, kargs={}):
        if name in self.poolCache:
            return
        self.adapi.createPool(name, kargs)
        self.poolCache[name] = kargs
        pass
    def updatePool(self, name, kargs={}):
        if _needUpdate(name, kargs, self.poolCache):
            self.adapi.updatePool(name, kargs)
            self.poolCache[name]=kargs
        pass
    def deletePool(self, name):
        self.adapi.deletePool(name)
        if name in self.poolCache:
            del self.poolCache[name]
        pass
    def createMember(self, name, mid, ip="", port=80, kargs={}):

        if mid in self.memberCache:
            return
        self.adapi.createMember(name, ip, port, kargs)
        self.memberCache[mid] = {'name':name, 'ip':ip, 'port':port, 'kargs':kargs}

    def deleteMember(self, name, mid, ip, port, kargs={}):
        self.adapi.deleteMember(name, ip ,port, kargs)
        if name in self.memberCache:
            del self.memberCache[mid]

    def updateMember(self, name, mid, ip="", port=80, kargs={}):
        args = dict(name=name, ip=ip, port=port, kargs=kargs)
        if _needUpdate(mid, args, self.memberCache):
            self.deleteMember(name, mid, ip, port, kargs)
            self.createMember(name, mid, ip, port, kargs)
            self.memberCache[mid]=args

    def addPoolMonitor(self, poolname, monitorname):
        key = poolname+':'+monitorname
        if key in self.poolMonitorCache:
            return
        self.adapi.addPoolMonitor(poolname, monitorname)
        self.poolMonitorCache[key] = True

    def delPoolMonitor(self, poolname, monitorname):
        self.adapi.delPoolMonitor(poolname, monitorname)
        key = poolname+':'+monitorname
        if key in self.poolMonitorCache:
            del self.poolMonitorCache[key]

    def createVS(self, name,  kargs={}):
        if name in self.vsCache:
            return
        self.adapi.createVS(name, kargs)
        self.vsCache[name] = kargs
        pass
    def updateVS(self, name, kargs={}):
        if _needUpdate(name, kargs, self.vsCache):
            self.adapi.updateVS(name, kargs)
            self.vsCache[name] = kargs
        pass
    def deleteVS(self, name):
        self.adapi.deleteVS(name)
        if name in self.vsCache:
            del self.vsCache[name]
        pass

    def createWan(self, name, ifname, ips=[], args={}):
        if name in self.wanCache:
            return
        self.adapi.createWan(name, ifname, ips, args)

    def resetConfig(self):
        self.vad.resetConfig()

    def start(self):
        self.vad.start()

    def started(self):
        return self.vad.started()

    def stop(self):
        self.vad.stop()

    def delete(self):
        self.vad.delete()

    def getPoolList(self):
        return self.adapi.getPoolList()

    def getNetnsId(self, netns_name):
        #TODO:查询并返回netns_id
        self.adapi.getNetnsInfo
        return 1

    def getVlanDevice(self, vlan_name):
        #查询并返回vlan的device字段
        vlan_info = self.adapi.getVlanInfo(vlan_name)
        return vlan_info['device']

    def getMacvlanDevice(self, macvlan_name):
        #TODO:查询并返回macvlan的device字段
        return ''

if __name__ == '__main__':
    ad_cache = ADcache('admin', 'root1234', '200.200.147.193', '443')
    #ad_cache.createServ('test123', "SRV_HTTP", ['123'])
    print ad_cache.getPoolList();
