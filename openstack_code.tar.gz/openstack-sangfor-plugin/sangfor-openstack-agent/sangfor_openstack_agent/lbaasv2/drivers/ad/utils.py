#!/usr/bin/python
def compareData(srcData, dstData):

    if isinstance(srcData, dict) and isinstance(dstData, dict):
        if len(srcData) != len(dstData):
            return False
        for k in srcData:
            if k not in dstData:
                return False
            if not compareData(srcData[k], dstData[k]):
                return False
    elif isinstance(srcData, str) and isinstance(dstData, str):
        if srcData != dstData:
            return False
    elif isinstance(srcData, int) and isinstance(dstData, int):
        if int(srcData) != int(dstData):
            return False
    elif isinstance(srcData, float) and isinstance(dstData, float):
        if float(srcData) != float(dstData):
            return False
    elif isinstance(srcData, long) and isinstance(dstData, long):
        if long(srcData) != long(dstdata):
            return False
    elif isinstance(srcData, complex) and isinstance(dstData, complex):
        if complex(srcData) != complex(dstdata):
            return False
    elif isinstance(srcData, list) and isinstance(dstData, list):
        if len(srcData) != len(dstData):
            return False
        equalNumber = 0
        for k in srcData:
            match = False
            for k0 in dstData:
                if compareData(k, k0):
                    match = True
                    break
            if match:
                equalNumber = equalNumber + 1
        if equalNumber != len(srcData):
            return False

    elif isinstance(srcData, tuple) and isinstance(dstData, tuple):
        if len(srcData) != len(dstData):
            return False
        for index in range(len(srcData)):
            if not compareData(srcData[index], dstData[index]):
                return False
    else:
        return False
    return True

if __name__ == "__main__":
    T1= dict(a=[],b=3,c=4)
    T2=dict(b=3,c=4,a=[3,2,1])
    if compareData(T1, T2):
        print("eq")
    else:
        print("ne")
